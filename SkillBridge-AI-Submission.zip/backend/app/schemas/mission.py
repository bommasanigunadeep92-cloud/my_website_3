from typing import Optional, List, Dict, Any
from datetime import datetime
from pydantic import BaseModel
from app.models.enums import MissionDifficulty, SubmissionStatus

class MissionListResponse(BaseModel):
    id: str
    title: str
    description: str
    category: str
    difficulty: MissionDifficulty
    estimated_time_minutes: int
    required_skills: List[str]
    submission_type: str
    user_status: Optional[SubmissionStatus] = None
    user_best_score: Optional[float] = None

    class Config:
        from_attributes = True

class MissionDetailResponse(MissionListResponse):
    scenario_context: str
    instructions: str
    sample_data: Optional[Any] = None
    evaluation_rubric: List[Dict[str, Any]]
    submission_type: str

class MissionSubmitRequest(BaseModel):
    submission_content: str

class MissionSubmissionResponse(BaseModel):
    id: str
    mission_id: str
    user_id: str
    submission_content: str
    status: SubmissionStatus
    score: float
    feedback: Optional[str] = None
    rubric_breakdown: Optional[List[Dict[str, Any]]] = None
    test_results: Optional[List[Dict[str, Any]]] = None
    is_ai_generated: bool
    evaluation_engine: str
    submitted_at: datetime
    evaluated_at: Optional[datetime] = None

    class Config:
        from_attributes = True
