from typing import Optional, List, Dict, Any
from datetime import datetime
from pydantic import BaseModel

class ScenarioChoice(BaseModel):
    id: str
    choice_text: str
    consequences_narrative: str
    metrics_delta: Dict[str, int]  # e.g. {"trust": 15, "risk": -10}
    next_step_key: Optional[str] = None
    score_points: int
    rationale: str

class ScenarioStepResponse(BaseModel):
    step_key: str
    prompt: str
    situation_update: Optional[str] = None
    choices: List[ScenarioChoice]

class ScenarioListResponse(BaseModel):
    id: str
    title: str
    description: str
    category: str
    difficulty: str
    estimated_minutes: int
    learning_objectives: List[str]
    user_attempts_count: Optional[int] = 0
    user_best_score: Optional[float] = None

    class Config:
        from_attributes = True

class ScenarioDetailResponse(ScenarioListResponse):
    context_background: str
    initial_step_key: str
    rubric: List[Dict[str, Any]]
    steps: List[ScenarioStepResponse]

class ScenarioStepSubmit(BaseModel):
    scenario_id: str
    step_key: str
    choice_id: str
    current_metrics: Optional[Dict[str, int]] = None
    history: Optional[List[Dict[str, Any]]] = None

class ScenarioFinalizeRequest(BaseModel):
    scenario_id: str
    steps_history: List[Dict[str, Any]]
    final_metrics: Dict[str, int]
    total_score: float

class ScenarioAttemptResponse(BaseModel):
    id: str
    scenario_id: str
    scenario_title: Optional[str] = None
    total_score: float
    performance_rating: str
    debrief_notes: Optional[str] = None
    metrics_summary: Optional[Dict[str, Any]] = None
    steps_history: List[Dict[str, Any]]
    is_ai_generated: bool
    completed_at: datetime

    class Config:
        from_attributes = True
