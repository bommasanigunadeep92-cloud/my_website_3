from typing import Optional, List, Dict, Any
from datetime import datetime
from pydantic import BaseModel
from app.models.enums import QuestionType

class AssessmentQuestionResponse(BaseModel):
    id: str
    skill_id: str
    skill_name: Optional[str] = None
    question_text: str
    question_type: QuestionType
    options: Optional[List[str]] = None
    points: int
    difficulty_level: int
    # Note: correct_answer is excluded from client-facing diagnostic questions to prevent cheating

    class Config:
        from_attributes = True

class AssessmentListResponse(BaseModel):
    id: str
    title: str
    description: str
    category: str
    target_role: Optional[str] = None
    difficulty: str
    time_limit_minutes: int
    passing_score: float
    question_count: int

    class Config:
        from_attributes = True

class AssessmentDetailResponse(AssessmentListResponse):
    questions: List[AssessmentQuestionResponse]

class AssessmentSubmitRequest(BaseModel):
    answers: Dict[str, str]  # question_id -> answer

class AssessmentAttemptResponse(BaseModel):
    id: str
    assessment_id: str
    assessment_title: Optional[str] = None
    user_id: str
    score: float
    passed: bool
    started_at: datetime
    completed_at: Optional[datetime] = None
    evaluation_detail: Optional[Dict[str, Any]] = None
    feedback_notes: Optional[str] = None
    is_ai_generated: bool
    skill_updates: Optional[List[Dict[str, Any]]] = None

    class Config:
        from_attributes = True
