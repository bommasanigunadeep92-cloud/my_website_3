from typing import Optional, List, Dict, Any
from datetime import datetime
from pydantic import BaseModel
from app.models.enums import InterventionStatus

class FailureReportCreate(BaseModel):
    skill_id: str
    topic: str
    description: str
    error_snippet: Optional[str] = None
    emotional_blocker: Optional[str] = None
    is_anonymous: bool = False

class FailureReportResponse(BaseModel):
    id: str
    user_id: Optional[str] = None
    user_name: Optional[str] = None  # Redacted if anonymous or if viewed by unauthorized manager
    skill_id: str
    skill_name: Optional[str] = None
    topic: str
    description: str
    error_snippet: Optional[str] = None
    emotional_blocker: Optional[str] = None
    is_anonymous: bool
    created_at: datetime

    class Config:
        from_attributes = True

class FailurePatternResponse(BaseModel):
    id: str
    skill_id: str
    skill_name: Optional[str] = None
    topic: str
    cluster_title: str
    report_count: int
    confidence_score: float
    status: str
    recommended_intervention_type: str
    intervention_details: Dict[str, Any]
    detected_at: datetime
    active_interventions_count: Optional[int] = 0
    resolved_at: Optional[datetime] = None

    class Config:
        from_attributes = True

class InterventionTrackingResponse(BaseModel):
    id: str
    failure_pattern_id: str
    failure_pattern_title: Optional[str] = None
    user_id: str
    status: InterventionStatus
    pre_intervention_score: Optional[float] = None
    post_intervention_score: Optional[float] = None
    score_delta: Optional[float] = None
    evidence_demonstrated: bool
    learner_feedback: Optional[str] = None
    intervention_details: Optional[Dict[str, Any]] = None
    completed_at: Optional[datetime] = None

    class Config:
        from_attributes = True

class InterventionCompleteRequest(BaseModel):
    post_intervention_score: float
    learner_feedback: Optional[str] = None
