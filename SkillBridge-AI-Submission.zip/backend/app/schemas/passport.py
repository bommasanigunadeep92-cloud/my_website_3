from typing import Optional, List, Dict, Any
from datetime import datetime
from pydantic import BaseModel
from app.models.enums import EvidenceType

class PassportEvidenceCreate(BaseModel):
    skill_id: str
    evidence_type: EvidenceType
    title: str
    description: str
    rubric_score: Optional[float] = None
    artifact_ref: Optional[str] = None
    tags: Optional[List[str]] = None

class PassportEvidenceResponse(BaseModel):
    id: str
    passport_id: str
    skill_id: str
    skill_name: Optional[str] = None
    skill_category: Optional[str] = None
    evidence_type: EvidenceType
    title: str
    description: str
    rubric_score: Optional[float] = None
    artifact_ref: Optional[str] = None
    verification_status: str
    verified_at: datetime
    tags: Optional[List[str]] = None
    created_at: datetime

    class Config:
        from_attributes = True

class SkillPassportResponse(BaseModel):
    id: str
    user_id: str
    user_name: str
    user_email: str
    organization_name: Optional[str] = None
    department: Optional[str] = None
    job_title: Optional[str] = None
    target_role: Optional[str] = None
    share_token: str
    is_public: bool
    headline: str
    summary_bio: Optional[str] = None
    verified_badge: bool
    verification_authority: str
    created_at: datetime
    updated_at: datetime
    evidence_items: List[PassportEvidenceResponse]
    assessed_skills_count: int
    projects_verified_count: int
    readiness_score: float

    class Config:
        from_attributes = True

class ShareSettingsUpdate(BaseModel):
    is_public: Optional[bool] = None
    headline: Optional[str] = None
    summary_bio: Optional[str] = None
    generate_new_token: Optional[bool] = False
