from datetime import datetime, timezone
import uuid
from sqlalchemy import Column, String, Float, Integer, ForeignKey, Text, Enum, DateTime, JSON, UniqueConstraint
from sqlalchemy.orm import relationship
from app.core.database import Base
from app.models.enums import SkillDemonstrationLevel

def generate_uuid():
    return str(uuid.uuid4())

class Skill(Base):
    __tablename__ = "skills"

    id = Column(String(36), primary_key=True, default=generate_uuid, index=True)
    name = Column(String(100), nullable=False, unique=True, index=True)
    category = Column(String(100), nullable=False, index=True)  # Software Engineering, Data & Analytics, Workplace Problem-Solving, Cloud & DevOps, Leadership & Communication
    description = Column(Text, nullable=False)
    created_at = Column(DateTime, default=lambda: datetime.now(timezone.utc))

    # Relationships
    user_scores = relationship("UserSkillScore", back_populates="skill")
    role_requirements = relationship("RoleRequirement", back_populates="skill")
    assessment_questions = relationship("AssessmentQuestion", back_populates="skill")
    knowledge_articles = relationship("KnowledgeArticle", back_populates="primary_skill")


class RoleRequirement(Base):
    __tablename__ = "role_requirements"

    id = Column(String(36), primary_key=True, default=generate_uuid)
    role_title = Column(String(150), nullable=False, index=True)
    skill_id = Column(String(36), ForeignKey("skills.id", ondelete="CASCADE"), nullable=False, index=True)
    required_level = Column(Float, nullable=False, default=3.0)  # 1.0 to 5.0
    importance_weight = Column(Float, nullable=False, default=1.0)  # 1.0 = normal, 1.5 = critical
    organization_id = Column(String(36), ForeignKey("organizations.id", ondelete="CASCADE"), nullable=True)

    skill = relationship("Skill", back_populates="role_requirements")

    __table_args__ = (
        UniqueConstraint('role_title', 'skill_id', 'organization_id', name='uq_role_skill_org'),
    )


class UserSkillScore(Base):
    __tablename__ = "user_skill_scores"

    id = Column(String(36), primary_key=True, default=generate_uuid)
    user_id = Column(String(36), ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True)
    skill_id = Column(String(36), ForeignKey("skills.id", ondelete="CASCADE"), nullable=False, index=True)
    demonstrated_level = Column(Float, nullable=False, default=0.0)  # 0.0 to 5.0
    status = Column(Enum(SkillDemonstrationLevel), default=SkillDemonstrationLevel.NOT_ASSESSED, nullable=False)
    evidence_count = Column(Integer, default=0)
    rubric_summary = Column(Text, nullable=True)
    last_assessed_at = Column(DateTime, default=lambda: datetime.now(timezone.utc))

    user = relationship("User", back_populates="skill_scores")
    skill = relationship("Skill", back_populates="user_scores")

    __table_args__ = (
        UniqueConstraint('user_id', 'skill_id', name='uq_user_skill'),
    )


class RoadmapMilestone(Base):
    __tablename__ = "roadmap_milestones"

    id = Column(String(36), primary_key=True, default=generate_uuid)
    user_id = Column(String(36), ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True)
    target_role = Column(String(150), nullable=False)
    milestone_order = Column(Integer, nullable=False, default=1)
    title = Column(String(255), nullable=False)
    description = Column(Text, nullable=False)
    target_skill_id = Column(String(36), ForeignKey("skills.id", ondelete="SET NULL"), nullable=True)
    target_level = Column(Float, default=3.0)
    status = Column(String(50), default="PENDING")  # PENDING, IN_PROGRESS, COMPLETED
    action_type = Column(String(50), nullable=False)  # ASSESSMENT, MISSION, SCENARIO, RESOURCE
    action_id = Column(String(100), nullable=True)
    completed_at = Column(DateTime, nullable=True)

    user = relationship("User", back_populates="roadmaps")


class LearningResource(Base):
    __tablename__ = "learning_resources"

    id = Column(String(36), primary_key=True, default=generate_uuid)
    skill_id = Column(String(36), ForeignKey("skills.id", ondelete="CASCADE"), nullable=False, index=True)
    title = Column(String(255), nullable=False)
    category = Column(String(100), nullable=True)
    resource_type = Column(String(50), default="INTERACTIVE_EXERCISE")  # GUIDE, LAB, VIDEO, DOCUMENTATION
    url = Column(String(500), nullable=True)
    summary = Column(Text, nullable=False)
    estimated_minutes = Column(Integer, default=20)
    created_at = Column(DateTime, default=lambda: datetime.now(timezone.utc))
