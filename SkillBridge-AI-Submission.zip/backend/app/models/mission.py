from datetime import datetime, timezone
import uuid
from sqlalchemy import Column, String, Float, Integer, Boolean, ForeignKey, Text, Enum, DateTime, JSON
from sqlalchemy.orm import relationship
from app.core.database import Base
from app.models.enums import MissionDifficulty, SubmissionStatus

def generate_uuid():
    return str(uuid.uuid4())

class Mission(Base):
    __tablename__ = "missions"

    id = Column(String(36), primary_key=True, default=generate_uuid, index=True)
    title = Column(String(255), nullable=False)
    description = Column(Text, nullable=False)
    category = Column(String(100), nullable=False, index=True)  # SQL & Databases, Data Analysis, Business Problem-Solving, Technical Troubleshooting, Communication
    difficulty = Column(Enum(MissionDifficulty), default=MissionDifficulty.INTERMEDIATE, nullable=False)
    estimated_time_minutes = Column(Integer, default=45)
    scenario_context = Column(Text, nullable=False)
    instructions = Column(Text, nullable=False)
    sample_data = Column(JSON, nullable=True)  # tables, schemas, mock data
    submission_type = Column(String(50), default="TEXT")  # SQL, CODE, TEXT, SPREADSHEET_ANALYSIS
    evaluation_rubric = Column(JSON, nullable=False)  # List of rubric items {criterion, max_points, description}
    test_cases = Column(JSON, nullable=True)  # Deterministic test inputs / expected patterns
    required_skills = Column(JSON, nullable=False, default=list)  # List of skill IDs or names
    created_at = Column(DateTime, default=lambda: datetime.now(timezone.utc))

    submissions = relationship("MissionSubmission", back_populates="mission", cascade="all, delete-orphan")


class MissionSubmission(Base):
    __tablename__ = "mission_submissions"

    id = Column(String(36), primary_key=True, default=generate_uuid, index=True)
    mission_id = Column(String(36), ForeignKey("missions.id", ondelete="CASCADE"), nullable=False, index=True)
    user_id = Column(String(36), ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True)
    submission_content = Column(Text, nullable=False)
    status = Column(Enum(SubmissionStatus), default=SubmissionStatus.SUBMITTED, nullable=False)
    score = Column(Float, nullable=False, default=0.0)  # 0 to 100
    feedback = Column(Text, nullable=True)
    rubric_breakdown = Column(JSON, nullable=True, default=list)  # [{criterion, points_awarded, max_points, notes}]
    test_results = Column(JSON, nullable=True, default=list)  # [{test_name, passed, output, message}]
    is_ai_generated = Column(Boolean, default=False)
    evaluation_engine = Column(String(100), default="deterministic_rubric")
    submitted_at = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    evaluated_at = Column(DateTime, nullable=True)

    mission = relationship("Mission", back_populates="submissions")
    user = relationship("User", back_populates="mission_submissions")
