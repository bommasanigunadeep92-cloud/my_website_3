import enum

class UserRole(str, enum.Enum):
    LEARNER = "LEARNER"
    MANAGER = "MANAGER"
    ADMIN = "ADMIN"

class SkillDemonstrationLevel(str, enum.Enum):
    NOT_ASSESSED = "NOT_ASSESSED"
    INSUFFICIENT_EVIDENCE = "INSUFFICIENT_EVIDENCE"
    DEVELOPING = "DEVELOPING"
    PROFICIENT = "PROFICIENT"

class MissionDifficulty(str, enum.Enum):
    BEGINNER = "BEGINNER"
    INTERMEDIATE = "INTERMEDIATE"
    ADVANCED = "ADVANCED"

class SubmissionStatus(str, enum.Enum):
    SUBMITTED = "SUBMITTED"
    EVALUATED = "EVALUATED"
    PASSED = "PASSED"
    NEEDS_REVISION = "NEEDS_REVISION"

class EvidenceType(str, enum.Enum):
    SELF_REPORTED = "SELF_REPORTED"
    PLATFORM_ASSESSED = "PLATFORM_ASSESSED"
    PROJECT_DEMONSTRATED = "PROJECT_DEMONSTRATED"
    EXTERNALLY_VERIFIED = "EXTERNALLY_VERIFIED"

class SpofRiskLevel(str, enum.Enum):
    LOW = "LOW"
    MEDIUM = "MEDIUM"
    HIGH = "HIGH"
    CRITICAL = "CRITICAL"

class InterventionStatus(str, enum.Enum):
    ASSIGNED = "ASSIGNED"
    IN_PROGRESS = "IN_PROGRESS"
    COMPLETED = "COMPLETED"

class CrossTrainingStatus(str, enum.Enum):
    ASSIGNED = "ASSIGNED"
    IN_PROGRESS = "IN_PROGRESS"
    VERIFIED = "VERIFIED"

class QuestionType(str, enum.Enum):
    MCQ = "MCQ"
    SHORT_ANSWER = "SHORT_ANSWER"
    PRACTICAL_SQL = "PRACTICAL_SQL"
    PRACTICAL_CODE = "PRACTICAL_CODE"
