from typing import List, Dict, Any, Optional
from datetime import datetime, timezone, timedelta
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session

from app.core.database import get_db
from app.routers.auth import get_current_user
from app.models.user import User, AuditLog
from app.models.knowledge import KnowledgeArticle, CrossTrainingAssignment
from app.models.skill import Skill
from app.models.enums import SpofRiskLevel, CrossTrainingStatus, UserRole
from app.schemas.knowledge import (
    KnowledgeArticleCreate,
    KnowledgeArticleUpdate,
    KnowledgeArticleResponse,
    CrossTrainingCreate,
    CrossTrainingResponse,
    KnowledgeRadarAnalyticsResponse
)

router = APIRouter(prefix="/knowledge", tags=["Organizational Knowledge Continuity Radar"])

def calculate_spof_risk(article: KnowledgeArticle) -> SpofRiskLevel:
    """
    Evaluates Single Point of Failure (SPOF) risk:
    - CRITICAL: No backup owner AND review is overdue (> cadence days)
    - HIGH: No backup owner OR overdue by > 30 days
    - MEDIUM: Backup owner assigned but not yet verified
    - LOW: Multiple verified backups and active regular reviews
    """
    now = datetime.now(timezone.utc)
    is_overdue = False
    if article.last_reviewed_at:
        days_since_review = (now - article.last_reviewed_at.replace(tzinfo=timezone.utc)).days
        is_overdue = days_since_review > (article.review_cadence_days or 90)

    has_backup = article.backup_owner_id is not None

    if not has_backup and is_overdue:
        return SpofRiskLevel.CRITICAL
    elif not has_backup or is_overdue:
        return SpofRiskLevel.HIGH
    elif article.cross_trainings and any(ct.status != CrossTrainingStatus.VERIFIED for ct in article.cross_trainings):
        return SpofRiskLevel.MEDIUM
    return SpofRiskLevel.LOW

@router.get("/articles", response_model=List[KnowledgeArticleResponse])
def list_articles(
    category: Optional[str] = None,
    spof_risk: Optional[SpofRiskLevel] = None,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    query = db.query(KnowledgeArticle).filter(
        KnowledgeArticle.organization_id == current_user.organization_id,
        KnowledgeArticle.status == "ACTIVE"
    )
    if category:
        query = query.filter(KnowledgeArticle.category == category)
    if spof_risk:
        query = query.filter(KnowledgeArticle.spof_risk_level == spof_risk)

    articles = query.order_by(KnowledgeArticle.spof_risk_level.desc(), KnowledgeArticle.title).all()

    results = []
    for a in articles:
        # Dynamically verify / refresh spof risk
        calculated_risk = calculate_spof_risk(a)
        if a.spof_risk_level != calculated_risk:
            a.spof_risk_level = calculated_risk
            db.commit()

        results.append(KnowledgeArticleResponse(
            id=a.id,
            organization_id=a.organization_id,
            title=a.title,
            category=a.category,
            summary=a.summary,
            content=a.content,
            owner_id=a.owner_id,
            owner_name=a.owner.full_name if a.owner else "Unassigned",
            backup_owner_id=a.backup_owner_id,
            backup_owner_name=a.backup_owner.full_name if a.backup_owner else None,
            primary_skill_id=a.primary_skill_id,
            primary_skill_name=a.primary_skill.name if a.primary_skill else None,
            related_skills=a.related_skills or [],
            review_cadence_days=a.review_cadence_days,
            last_reviewed_at=a.last_reviewed_at,
            next_review_at=a.next_review_at or (a.last_reviewed_at + timedelta(days=a.review_cadence_days)),
            spof_risk_level=a.spof_risk_level,
            is_verified_procedure=a.is_verified_procedure,
            status=a.status,
            views_count=a.views_count,
            created_at=a.created_at
        ))
    return results

@router.get("/articles/{article_id}", response_model=KnowledgeArticleResponse)
def get_article(
    article_id: str,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    a = db.query(KnowledgeArticle).filter(
        KnowledgeArticle.id == article_id,
        KnowledgeArticle.organization_id == current_user.organization_id
    ).first()
    if not a:
        raise HTTPException(status_code=404, detail="Knowledge article not found")

    a.views_count = (a.views_count or 0) + 1
    db.commit()

    return KnowledgeArticleResponse(
        id=a.id,
        organization_id=a.organization_id,
        title=a.title,
        category=a.category,
        summary=a.summary,
        content=a.content,
        owner_id=a.owner_id,
        owner_name=a.owner.full_name if a.owner else "Unassigned",
        backup_owner_id=a.backup_owner_id,
        backup_owner_name=a.backup_owner.full_name if a.backup_owner else None,
        primary_skill_id=a.primary_skill_id,
        primary_skill_name=a.primary_skill.name if a.primary_skill else None,
        related_skills=a.related_skills or [],
        review_cadence_days=a.review_cadence_days,
        last_reviewed_at=a.last_reviewed_at,
        next_review_at=a.next_review_at or (a.last_reviewed_at + timedelta(days=a.review_cadence_days)),
        spof_risk_level=a.spof_risk_level,
        is_verified_procedure=a.is_verified_procedure,
        status=a.status,
        views_count=a.views_count,
        created_at=a.created_at
    )

@router.post("/articles", response_model=KnowledgeArticleResponse)
def create_article(
    payload: KnowledgeArticleCreate,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    now = datetime.now(timezone.utc)
    cadence = payload.review_cadence_days or 90

    article = KnowledgeArticle(
        organization_id=current_user.organization_id,
        title=payload.title,
        category=payload.category,
        summary=payload.summary,
        content=payload.content,
        owner_id=payload.owner_id or current_user.id,
        backup_owner_id=payload.backup_owner_id,
        primary_skill_id=payload.primary_skill_id,
        related_skills=payload.related_skills or [],
        review_cadence_days=cadence,
        last_reviewed_at=now,
        next_review_at=now + timedelta(days=cadence),
        spof_risk_level=SpofRiskLevel.HIGH if not payload.backup_owner_id else SpofRiskLevel.MEDIUM,
        is_verified_procedure=True,
        status="ACTIVE",
        views_count=1
    )
    db.add(article)
    db.flush()

    # If backup assigned, automatically register cross training assignment
    if payload.backup_owner_id:
        ct = CrossTrainingAssignment(
            organization_id=current_user.organization_id,
            knowledge_article_id=article.id,
            primary_expert_id=article.owner_id,
            backup_learner_id=payload.backup_owner_id,
            target_completion_date=now + timedelta(days=30),
            status=CrossTrainingStatus.ASSIGNED
        )
        db.add(ct)

    audit = AuditLog(
        organization_id=current_user.organization_id,
        user_id=current_user.id,
        action="KNOWLEDGE_ARTICLE_CREATED",
        resource_type="KNOWLEDGE_ARTICLE",
        resource_id=article.id,
        details={"title": article.title, "category": article.category}
    )
    db.add(audit)
    db.commit()
    db.refresh(article)

    return KnowledgeArticleResponse(
        id=article.id,
        organization_id=article.organization_id,
        title=article.title,
        category=article.category,
        summary=article.summary,
        content=article.content,
        owner_id=article.owner_id,
        owner_name=article.owner.full_name if article.owner else "Unassigned",
        backup_owner_id=article.backup_owner_id,
        backup_owner_name=article.backup_owner.full_name if article.backup_owner else None,
        primary_skill_id=article.primary_skill_id,
        primary_skill_name=article.primary_skill.name if article.primary_skill else None,
        related_skills=article.related_skills or [],
        review_cadence_days=article.review_cadence_days,
        last_reviewed_at=article.last_reviewed_at,
        next_review_at=article.next_review_at,
        spof_risk_level=article.spof_risk_level,
        is_verified_procedure=article.is_verified_procedure,
        status=article.status,
        views_count=article.views_count,
        created_at=article.created_at
    )

@router.get("/radar/analytics", response_model=KnowledgeRadarAnalyticsResponse)
def get_radar_analytics(
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    org_id = current_user.organization_id
    articles = db.query(KnowledgeArticle).filter(
        KnowledgeArticle.organization_id == org_id,
        KnowledgeArticle.status == "ACTIVE"
    ).all()

    total = len(articles)
    critical_count = sum(1 for a in articles if a.spof_risk_level == SpofRiskLevel.CRITICAL)
    high_count = sum(1 for a in articles if a.spof_risk_level == SpofRiskLevel.HIGH)
    medium_count = sum(1 for a in articles if a.spof_risk_level == SpofRiskLevel.MEDIUM)
    low_count = sum(1 for a in articles if a.spof_risk_level == SpofRiskLevel.LOW)

    now = datetime.now(timezone.utc)
    outdated_count = 0
    for a in articles:
        if a.last_reviewed_at:
            if (now - a.last_reviewed_at.replace(tzinfo=timezone.utc)).days > (a.review_cadence_days or 90):
                outdated_count += 1

    active_cts = db.query(CrossTrainingAssignment).filter(
        CrossTrainingAssignment.organization_id == org_id,
        CrossTrainingAssignment.status != CrossTrainingStatus.VERIFIED
    ).count()

    # Category distribution
    cat_counts = {}
    for a in articles:
        cat_counts[a.category] = cat_counts.get(a.category, 0) + 1
    category_distribution = [{"category": k, "count": v} for k, v in cat_counts.items()]

    # High / Critical alerts
    spof_alerts = []
    for a in articles:
        if a.spof_risk_level in [SpofRiskLevel.CRITICAL, SpofRiskLevel.HIGH]:
            action = "Designate backup learner immediately" if not a.backup_owner_id else "Perform scheduled procedure review"
            spof_alerts.append({
                "article_id": a.id,
                "title": a.title,
                "category": a.category,
                "risk_level": a.spof_risk_level.value,
                "primary_owner": a.owner.full_name if a.owner else "Unassigned",
                "backup_owner": a.backup_owner.full_name if a.backup_owner else "None (Single Point of Failure)",
                "recommended_action": action
            })

    # Overall health calculation
    health_pct = 100.0
    if total > 0:
        penalty = (critical_count * 25.0 + high_count * 15.0 + medium_count * 5.0) / total
        health_pct = max(10.0, round(100.0 - penalty, 1))

    recommendations = [
        {
            "priority": "Critical" if critical_count > 0 else "Medium",
            "title": "Cross-Train Critical Knowledge Hotspots",
            "description": f"Found {critical_count + high_count} articles with single point of failure risk. Assign secondary learners to avoid institutional memory loss."
        },
        {
            "priority": "High" if outdated_count > 0 else "Low",
            "title": "Refresh Outdated Runbooks & SOPs",
            "description": f"{outdated_count} procedures have not been reviewed within their designated cadence window."
        }
    ]

    return KnowledgeRadarAnalyticsResponse(
        total_articles=total,
        overall_coverage_health_pct=health_pct,
        critical_spof_count=critical_count,
        high_spof_count=high_count,
        medium_spof_count=medium_count,
        low_spof_count=low_count,
        outdated_review_count=outdated_count,
        active_cross_trainings_count=active_cts,
        spof_alerts=spof_alerts,
        category_distribution=category_distribution,
        recommendations=recommendations
    )

@router.post("/cross-training", response_model=CrossTrainingResponse)
def create_cross_training(
    payload: CrossTrainingCreate,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    article = db.query(KnowledgeArticle).filter(
        KnowledgeArticle.id == payload.knowledge_article_id,
        KnowledgeArticle.organization_id == current_user.organization_id
    ).first()
    if not article:
        raise HTTPException(status_code=404, detail="Knowledge article not found")

    target_date = payload.target_completion_date or (datetime.now(timezone.utc) + timedelta(days=30))

    ct = CrossTrainingAssignment(
        organization_id=current_user.organization_id,
        knowledge_article_id=article.id,
        primary_expert_id=article.owner_id or current_user.id,
        backup_learner_id=payload.backup_learner_id,
        target_completion_date=target_date,
        status=CrossTrainingStatus.ASSIGNED
    )
    db.add(ct)

    # Set backup owner on article if not set
    if not article.backup_owner_id:
        article.backup_owner_id = payload.backup_learner_id
        article.spof_risk_level = SpofRiskLevel.MEDIUM

    db.commit()
    db.refresh(ct)

    return CrossTrainingResponse(
        id=ct.id,
        organization_id=ct.organization_id,
        knowledge_article_id=ct.knowledge_article_id,
        knowledge_article_title=article.title,
        primary_expert_id=ct.primary_expert_id,
        primary_expert_name=ct.primary_expert.full_name if ct.primary_expert else "Expert",
        backup_learner_id=ct.backup_learner_id,
        backup_learner_name=ct.backup_learner.full_name if ct.backup_learner else "Learner",
        target_completion_date=ct.target_completion_date,
        status=ct.status,
        verification_notes=ct.verification_notes,
        verified_at=ct.verified_at,
        created_at=ct.created_at
    )

@router.put("/cross-training/{assignment_id}/verify", response_model=CrossTrainingResponse)
def verify_cross_training(
    assignment_id: str,
    notes: Optional[str] = "Shadow rotation completed successfully. Verification confirmed.",
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    ct = db.query(CrossTrainingAssignment).filter(
        CrossTrainingAssignment.id == assignment_id,
        CrossTrainingAssignment.organization_id == current_user.organization_id
    ).first()
    if not ct:
        raise HTTPException(status_code=404, detail="Cross-training assignment not found")

    ct.status = CrossTrainingStatus.VERIFIED
    ct.verification_notes = notes
    ct.verified_at = datetime.now(timezone.utc)

    # Recalculate article risk
    article = ct.knowledge_article
    if article:
        article.spof_risk_level = SpofRiskLevel.LOW

    db.commit()
    db.refresh(ct)

    return CrossTrainingResponse(
        id=ct.id,
        organization_id=ct.organization_id,
        knowledge_article_id=ct.knowledge_article_id,
        knowledge_article_title=article.title if article else "Procedure",
        primary_expert_id=ct.primary_expert_id,
        primary_expert_name=ct.primary_expert.full_name if ct.primary_expert else "Expert",
        backup_learner_id=ct.backup_learner_id,
        backup_learner_name=ct.backup_learner.full_name if ct.backup_learner else "Learner",
        target_completion_date=ct.target_completion_date,
        status=ct.status,
        verification_notes=ct.verification_notes,
        verified_at=ct.verified_at,
        created_at=ct.created_at
    )
