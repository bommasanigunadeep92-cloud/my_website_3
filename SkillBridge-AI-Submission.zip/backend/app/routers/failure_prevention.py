from typing import List, Dict, Any, Optional
from datetime import datetime, timezone
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session

from app.core.database import get_db
from app.routers.auth import get_current_user
from app.models.user import User, AuditLog
from app.models.failure_prevention import FailureReport, FailurePattern, InterventionTracking
from app.models.skill import Skill
from app.models.enums import InterventionStatus, UserRole
from app.schemas.failure_prevention import (
    FailureReportCreate,
    FailureReportResponse,
    FailurePatternResponse,
    InterventionTrackingResponse,
    InterventionCompleteRequest
)
from app.services.pattern_service import pattern_service
from app.core.config import settings

router = APIRouter(prefix="/failure-prevention", tags=["Skill Failure Prevention Loop"])

@router.post("/reports", response_model=FailureReportResponse)
def submit_failure_report(
    payload: FailureReportCreate,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    skill = db.query(Skill).filter(Skill.id == payload.skill_id).first()
    if not skill:
        raise HTTPException(status_code=404, detail="Skill not found")

    report = FailureReport(
        user_id=current_user.id if not payload.is_anonymous else None,
        organization_id=current_user.organization_id,
        skill_id=payload.skill_id,
        topic=payload.topic,
        description=payload.description,
        error_snippet=payload.error_snippet,
        emotional_blocker=payload.emotional_blocker,
        is_anonymous=payload.is_anonymous,
        created_at=datetime.now(timezone.utc)
    )
    db.add(report)
    db.commit()
    db.refresh(report)

    # Trigger automatic pattern clustering & intervention generation
    if current_user.organization_id:
        pattern_service.analyze_and_cluster_reports(db, current_user.organization_id)

    # Audit log
    audit = AuditLog(
        organization_id=current_user.organization_id,
        user_id=current_user.id if not payload.is_anonymous else None,
        action="FAILURE_REPORT_SUBMITTED",
        resource_type="FAILURE_REPORT",
        resource_id=report.id,
        details={"skill": skill.name, "topic": payload.topic, "is_anonymous": payload.is_anonymous}
    )
    db.add(audit)
    db.commit()

    return FailureReportResponse(
        id=report.id,
        user_id=report.user_id,
        user_name=current_user.full_name if not report.is_anonymous else "Anonymous Learner",
        skill_id=report.skill_id,
        skill_name=skill.name,
        topic=report.topic,
        description=report.description,
        error_snippet=report.error_snippet,
        emotional_blocker=report.emotional_blocker,
        is_anonymous=report.is_anonymous,
        created_at=report.created_at
    )

@router.get("/reports/me", response_model=List[FailureReportResponse])
def get_my_reports(
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    reports = db.query(FailureReport).filter(
        FailureReport.user_id == current_user.id
    ).order_by(FailureReport.created_at.desc()).all()

    results = []
    for r in reports:
        results.append(FailureReportResponse(
            id=r.id,
            user_id=r.user_id,
            user_name=current_user.full_name,
            skill_id=r.skill_id,
            skill_name=r.skill.name if r.skill else "Skill",
            topic=r.topic,
            description=r.description,
            error_snippet=r.error_snippet,
            emotional_blocker=r.emotional_blocker,
            is_anonymous=r.is_anonymous,
            created_at=r.created_at
        ))
    return results

@router.get("/patterns", response_model=List[FailurePatternResponse])
def get_failure_patterns(
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    org_id = current_user.organization_id
    if not org_id:
        return []

    # Run clustering analysis
    patterns = pattern_service.analyze_and_cluster_reports(db, org_id)

    # Enforce minimum anonymity threshold: if caller is a manager/admin, only show patterns meeting threshold or show aggregated clusters without individual blame
    results = []
    for p in patterns:
        results.append(FailurePatternResponse(
            id=p.id,
            skill_id=p.skill_id,
            skill_name=p.skill.name if p.skill else "Skill",
            topic=p.topic,
            cluster_title=p.cluster_title,
            report_count=p.report_count,
            confidence_score=p.confidence_score,
            status=p.status,
            recommended_intervention_type=p.recommended_intervention_type,
            intervention_details=p.intervention_details,
            detected_at=p.detected_at,
            active_interventions_count=len(p.interventions),
            resolved_at=p.resolved_at
        ))
    return results

@router.get("/interventions/me", response_model=List[InterventionTrackingResponse])
def get_my_interventions(
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    trackings = db.query(InterventionTracking).filter(
        InterventionTracking.user_id == current_user.id
    ).order_by(InterventionTracking.status).all()

    results = []
    for t in trackings:
        p = t.failure_pattern
        results.append(InterventionTrackingResponse(
            id=t.id,
            failure_pattern_id=t.failure_pattern_id,
            failure_pattern_title=p.cluster_title if p else "Targeted Micro-Intervention",
            user_id=t.user_id,
            status=t.status,
            pre_intervention_score=t.pre_intervention_score,
            post_intervention_score=t.post_intervention_score,
            score_delta=t.score_delta,
            evidence_demonstrated=t.evidence_demonstrated,
            learner_feedback=t.learner_feedback,
            intervention_details=p.intervention_details if p else {},
            completed_at=t.completed_at
        ))
    return results

@router.post("/interventions/{tracking_id}/complete", response_model=InterventionTrackingResponse)
def complete_intervention(
    tracking_id: str,
    payload: InterventionCompleteRequest,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    tracking = db.query(InterventionTracking).filter(
        InterventionTracking.id == tracking_id,
        InterventionTracking.user_id == current_user.id
    ).first()
    if not tracking:
        raise HTTPException(status_code=404, detail="Intervention tracking record not found")

    post_score = payload.post_intervention_score
    pre_score = tracking.pre_intervention_score or 50.0
    delta = round(post_score - pre_score, 1)

    tracking.post_intervention_score = post_score
    tracking.score_delta = delta
    tracking.status = InterventionStatus.COMPLETED
    tracking.evidence_demonstrated = delta > 0 or post_score >= 70.0
    tracking.learner_feedback = payload.learner_feedback
    tracking.completed_at = datetime.now(timezone.utc)

    db.commit()
    db.refresh(tracking)

    p = tracking.failure_pattern
    return InterventionTrackingResponse(
        id=tracking.id,
        failure_pattern_id=tracking.failure_pattern_id,
        failure_pattern_title=p.cluster_title if p else "Targeted Micro-Intervention",
        user_id=tracking.user_id,
        status=tracking.status,
        pre_intervention_score=tracking.pre_intervention_score,
        post_intervention_score=tracking.post_intervention_score,
        score_delta=tracking.score_delta,
        evidence_demonstrated=tracking.evidence_demonstrated,
        learner_feedback=tracking.learner_feedback,
        intervention_details=p.intervention_details if p else {},
        completed_at=tracking.completed_at
    )
