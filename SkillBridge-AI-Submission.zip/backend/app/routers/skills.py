from typing import List, Dict, Any, Optional
from datetime import datetime, timezone
from fastapi import APIRouter, Depends, HTTPException, status, Query
from sqlalchemy.orm import Session
from pydantic import BaseModel

from app.core.database import get_db
from app.routers.auth import get_current_user
from app.models.user import User
from app.models.skill import Skill, RoleRequirement, UserSkillScore, RoadmapMilestone, LearningResource
from app.models.enums import SkillDemonstrationLevel
from app.schemas.skill import (
    SkillResponse,
    RoleRequirementResponse,
    SkillGapAnalysisResponse,
    RoadmapMilestoneResponse,
    LearningResourceResponse
)
from app.services.scoring_service import scoring_service

router = APIRouter(prefix="/skills", tags=["Skills & Gap Detection"])

class TargetRoleUpdate(BaseModel):
    target_role: str

@router.get("", response_model=List[SkillResponse])
def get_all_skills(category: Optional[str] = None, db: Session = Depends(get_db)):
    query = db.query(Skill)
    if category:
        query = query.filter(Skill.category == category)
    return query.order_by(Skill.category, Skill.name).all()

@router.get("/roles")
def get_target_roles(db: Session = Depends(get_db)):
    # Distinct role titles
    roles = db.query(RoleRequirement.role_title).distinct().all()
    role_list = [r[0] for r in roles]
    if not role_list:
        role_list = [
            "Senior Full-Stack Engineer",
            "Cloud Data & Analytics Specialist",
            "DevOps & Reliability Engineer",
            "Strategic Product Manager",
            "Enterprise Solutions Consultant"
        ]
    return {"roles": role_list}

@router.get("/gap-analysis", response_model=SkillGapAnalysisResponse)
def get_gap_analysis(
    role: Optional[str] = None,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    target_role = role or current_user.target_role or "Senior Full-Stack Engineer"
    analysis = scoring_service.calculate_skill_gap_analysis(
        db=db,
        user_id=current_user.id,
        target_role=target_role,
        org_id=current_user.organization_id
    )
    return analysis

@router.post("/target-role")
def set_target_role(
    payload: TargetRoleUpdate,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    current_user.target_role = payload.target_role
    db.commit()
    db.refresh(current_user)
    return {"message": "Target role updated successfully", "target_role": current_user.target_role}

@router.get("/roadmap", response_model=List[RoadmapMilestoneResponse])
def get_user_roadmap(
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    milestones = db.query(RoadmapMilestone).filter(
        RoadmapMilestone.user_id == current_user.id
    ).order_by(RoadmapMilestone.milestone_order).all()

    # If no milestones exist for this user, dynamically seed a customized roadmap
    if not milestones:
        target_role = current_user.target_role or "Senior Full-Stack Engineer"
        # Find requirements
        reqs = db.query(RoleRequirement).filter(RoleRequirement.role_title == target_role).all()
        created = []
        for idx, r in enumerate(reqs[:4], start=1):
            ms = RoadmapMilestone(
                user_id=current_user.id,
                target_role=target_role,
                milestone_order=idx,
                title=f"Master {r.skill.name} Core Competencies",
                description=f"Demonstrate practical benchmark proficiency of {r.required_level:.1f}/5.0 via diagnostic labs and missions.",
                target_skill_id=r.skill_id,
                target_level=r.required_level,
                status="IN_PROGRESS" if idx == 1 else "PENDING",
                action_type="MISSION" if idx % 2 == 0 else "ASSESSMENT",
                action_id=r.skill_id
            )
            db.add(ms)
            created.append(ms)
        db.commit()
        for m in created:
            db.refresh(m)
        milestones = created

    res = []
    for m in milestones:
        skill_name = None
        if m.target_skill_id:
            sk = db.query(Skill).filter(Skill.id == m.target_skill_id).first()
            skill_name = sk.name if sk else None
        res.append(RoadmapMilestoneResponse(
            id=m.id,
            target_role=m.target_role,
            milestone_order=m.milestone_order,
            title=m.title,
            description=m.description,
            target_skill_id=m.target_skill_id,
            target_skill_name=skill_name,
            target_level=m.target_level,
            status=m.status,
            action_type=m.action_type,
            action_id=m.action_id,
            completed_at=m.completed_at
        ))
    return res

@router.post("/roadmap/milestones/{milestone_id}/toggle")
def toggle_milestone(
    milestone_id: str,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    ms = db.query(RoadmapMilestone).filter(
        RoadmapMilestone.id == milestone_id,
        RoadmapMilestone.user_id == current_user.id
    ).first()
    if not ms:
        raise HTTPException(status_code=404, detail="Milestone not found")

    if ms.status == "COMPLETED":
        ms.status = "IN_PROGRESS"
        ms.completed_at = None
    else:
        ms.status = "COMPLETED"
        ms.completed_at = datetime.now(timezone.utc)

    db.commit()
    db.refresh(ms)
    return {"message": "Milestone updated", "status": ms.status, "completed_at": ms.completed_at}

@router.get("/resources", response_model=List[LearningResourceResponse])
def get_learning_resources(
    skill_id: Optional[str] = None,
    db: Session = Depends(get_db)
):
    query = db.query(LearningResource)
    if skill_id:
        query = query.filter(LearningResource.skill_id == skill_id)
    return query.limit(20).all()
