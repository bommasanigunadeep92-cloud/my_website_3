from typing import List, Dict, Any, Optional
from datetime import datetime, timezone
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session

from app.core.database import get_db
from app.routers.auth import get_current_user
from app.models.user import User, AuditLog
from app.models.scenario import Scenario, ScenarioStep, ScenarioAttempt
from app.models.passport import SkillPassport, PassportEvidence
from app.models.skill import Skill
from app.models.enums import EvidenceType
from app.schemas.scenario import (
    ScenarioListResponse,
    ScenarioDetailResponse,
    ScenarioStepResponse,
    ScenarioChoice,
    ScenarioFinalizeRequest,
    ScenarioAttemptResponse
)
from app.services.ai_service import ai_service

router = APIRouter(prefix="/scenarios", tags=["Consequence-Based Learning Simulator"])

@router.get("", response_model=List[ScenarioListResponse])
def list_scenarios(
    category: Optional[str] = None,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    query = db.query(Scenario).filter(Scenario.is_active == True)
    if category:
        query = query.filter(Scenario.category == category)
    scenarios = query.all()

    # User attempts
    attempts = db.query(ScenarioAttempt).filter(ScenarioAttempt.user_id == current_user.id).all()
    user_stats = {}
    for a in attempts:
        if a.scenario_id not in user_stats:
            user_stats[a.scenario_id] = {"count": 0, "best": 0.0}
        user_stats[a.scenario_id]["count"] += 1
        if a.total_score > user_stats[a.scenario_id]["best"]:
            user_stats[a.scenario_id]["best"] = a.total_score

    results = []
    for s in scenarios:
        stats = user_stats.get(s.id, {"count": 0, "best": None})
        results.append(ScenarioListResponse(
            id=s.id,
            title=s.title,
            description=s.description,
            category=s.category,
            difficulty=s.difficulty,
            estimated_minutes=s.estimated_minutes,
            learning_objectives=s.learning_objectives or [],
            user_attempts_count=stats["count"],
            user_best_score=stats["best"]
        ))
    return results

@router.get("/{scenario_id}", response_model=ScenarioDetailResponse)
def get_scenario(
    scenario_id: str,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    s = db.query(Scenario).filter(Scenario.id == scenario_id).first()
    if not s:
        raise HTTPException(status_code=404, detail="Scenario not found")

    steps_resp = []
    for step in s.steps:
        choices_list = []
        for ch in step.choices:
            choices_list.append(ScenarioChoice(
                id=ch["id"],
                choice_text=ch["choice_text"],
                consequences_narrative=ch["consequences_narrative"],
                metrics_delta=ch.get("metrics_delta", {}),
                next_step_key=ch.get("next_step_key"),
                score_points=ch.get("score_points", 20),
                rationale=ch.get("rationale", "")
            ))
        steps_resp.append(ScenarioStepResponse(
            step_key=step.step_key,
            prompt=step.prompt,
            situation_update=step.situation_update,
            choices=choices_list
        ))

    # User best attempt
    best_attempt = db.query(ScenarioAttempt).filter(
        ScenarioAttempt.scenario_id == scenario_id,
        ScenarioAttempt.user_id == current_user.id
    ).order_by(ScenarioAttempt.total_score.desc()).first()

    return ScenarioDetailResponse(
        id=s.id,
        title=s.title,
        description=s.description,
        category=s.category,
        difficulty=s.difficulty,
        estimated_minutes=s.estimated_minutes,
        learning_objectives=s.learning_objectives or [],
        context_background=s.context_background,
        initial_step_key=s.initial_step_key,
        rubric=s.rubric or [],
        steps=steps_resp,
        user_attempts_count=1 if best_attempt else 0,
        user_best_score=best_attempt.total_score if best_attempt else None
    )

@router.post("/{scenario_id}/attempt", response_model=ScenarioAttemptResponse)
def record_scenario_attempt(
    scenario_id: str,
    payload: ScenarioFinalizeRequest,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    s = db.query(Scenario).filter(Scenario.id == scenario_id).first()
    if not s:
        raise HTTPException(status_code=404, detail="Scenario not found")

    # Generate debrief analysis
    debrief = ai_service.generate_scenario_debrief(
        scenario_title=s.title,
        steps_history=payload.steps_history,
        final_metrics=payload.final_metrics,
        total_score=payload.total_score
    )

    attempt = ScenarioAttempt(
        scenario_id=s.id,
        user_id=current_user.id,
        steps_history=payload.steps_history,
        total_score=payload.total_score,
        performance_rating=debrief["performance_rating"],
        debrief_notes=debrief["debrief_notes"],
        metrics_summary=payload.final_metrics,
        is_ai_generated=debrief["is_ai_generated"],
        completed_at=datetime.now(timezone.utc)
    )
    db.add(attempt)

    # If score >= 70, register in Skill Passport evidence
    if payload.total_score >= 70.0:
        passport = db.query(SkillPassport).filter(SkillPassport.user_id == current_user.id).first()
        if passport:
            # Find relevant soft/leadership skill
            leadership_skill = db.query(Skill).filter(
                (Skill.category.ilike("%Management%")) | 
                (Skill.category.ilike("%Communication%")) |
                (Skill.name.ilike("%Crisis%")) |
                (Skill.name.ilike("%Decision%"))
            ).first()
            if leadership_skill:
                ev = PassportEvidence(
                    passport_id=passport.id,
                    skill_id=leadership_skill.id,
                    evidence_type=EvidenceType.PROJECT_DEMONSTRATED,
                    title=f"Workplace Simulator: {s.title}",
                    description=f"Demonstrated consequence-based decision-making with score {payload.total_score}%. Rating: {debrief['performance_rating']}.",
                    rubric_score=payload.total_score,
                    artifact_ref=attempt.id,
                    verification_status="VERIFIED",
                    tags=["Simulator", s.category]
                )
                db.add(ev)

    # Audit log
    audit = AuditLog(
        organization_id=current_user.organization_id,
        user_id=current_user.id,
        action="SCENARIO_ATTEMPT_COMPLETED",
        resource_type="SCENARIO",
        resource_id=s.id,
        details={"score": payload.total_score, "rating": debrief["performance_rating"]}
    )
    db.add(audit)
    db.commit()
    db.refresh(attempt)

    return ScenarioAttemptResponse(
        id=attempt.id,
        scenario_id=attempt.scenario_id,
        scenario_title=s.title,
        total_score=attempt.total_score,
        performance_rating=attempt.performance_rating,
        debrief_notes=attempt.debrief_notes,
        metrics_summary=attempt.metrics_summary,
        steps_history=attempt.steps_history,
        is_ai_generated=attempt.is_ai_generated,
        completed_at=attempt.completed_at
    )

@router.get("/history/me", response_model=List[ScenarioAttemptResponse])
def get_user_scenario_history(
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    attempts = db.query(ScenarioAttempt).filter(
        ScenarioAttempt.user_id == current_user.id
    ).order_by(ScenarioAttempt.completed_at.desc()).all()

    res = []
    for a in attempts:
        res.append(ScenarioAttemptResponse(
            id=a.id,
            scenario_id=a.scenario_id,
            scenario_title=a.scenario.title if a.scenario else "Workplace Scenario",
            total_score=a.total_score,
            performance_rating=a.performance_rating,
            debrief_notes=a.debrief_notes,
            metrics_summary=a.metrics_summary,
            steps_history=a.steps_history,
            is_ai_generated=a.is_ai_generated,
            completed_at=a.completed_at
        ))
    return res
