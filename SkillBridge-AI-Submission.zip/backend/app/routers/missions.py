from typing import List, Dict, Any, Optional
from datetime import datetime, timezone
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session

from app.core.database import get_db
from app.routers.auth import get_current_user
from app.models.user import User, AuditLog
from app.models.mission import Mission, MissionSubmission
from app.models.passport import SkillPassport, PassportEvidence
from app.models.skill import Skill
from app.models.enums import SubmissionStatus, EvidenceType
from app.schemas.mission import (
    MissionListResponse,
    MissionDetailResponse,
    MissionSubmitRequest,
    MissionSubmissionResponse
)
from app.services.ai_service import ai_service
from app.services.scoring_service import scoring_service

router = APIRouter(prefix="/missions", tags=["Real-World Mission Lab"])

@router.get("", response_model=List[MissionListResponse])
def list_missions(
    category: Optional[str] = None,
    current_user: Optional[User] = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    query = db.query(Mission)
    if category:
        query = query.filter(Mission.category == category)
    missions = query.order_by(Mission.category, Mission.title).all()

    # Get user's submissions
    user_subs = {}
    if current_user:
        subs = db.query(MissionSubmission).filter(MissionSubmission.user_id == current_user.id).all()
        for s in subs:
            if s.mission_id not in user_subs or s.score > user_subs[s.mission_id]["score"]:
                user_subs[s.mission_id] = {"status": s.status, "score": s.score}

    results = []
    for m in missions:
        user_info = user_subs.get(m.id)
        results.append(MissionListResponse(
            id=m.id,
            title=m.title,
            description=m.description,
            category=m.category,
            difficulty=m.difficulty,
            estimated_time_minutes=m.estimated_time_minutes,
            required_skills=m.required_skills or [],
            submission_type=m.submission_type,
            user_status=user_info["status"] if user_info else None,
            user_best_score=user_info["score"] if user_info else None
        ))
    return results

@router.get("/{mission_id}", response_model=MissionDetailResponse)
def get_mission(mission_id: str, current_user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    m = db.query(Mission).filter(Mission.id == mission_id).first()
    if not m:
        raise HTTPException(status_code=404, detail="Mission not found")

    user_sub = db.query(MissionSubmission).filter(
        MissionSubmission.mission_id == mission_id,
        MissionSubmission.user_id == current_user.id
    ).order_by(MissionSubmission.score.desc()).first()

    return MissionDetailResponse(
        id=m.id,
        title=m.title,
        description=m.description,
        category=m.category,
        difficulty=m.difficulty,
        estimated_time_minutes=m.estimated_time_minutes,
        scenario_context=m.scenario_context,
        instructions=m.instructions,
        sample_data=m.sample_data,
        evaluation_rubric=m.evaluation_rubric,
        submission_type=m.submission_type,
        required_skills=m.required_skills or [],
        user_status=user_sub.status if user_sub else None,
        user_best_score=user_sub.score if user_sub else None
    )

@router.post("/{mission_id}/submit", response_model=MissionSubmissionResponse)
async def submit_mission(
    mission_id: str,
    payload: MissionSubmitRequest,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    m = db.query(Mission).filter(Mission.id == mission_id).first()
    if not m:
        raise HTTPException(status_code=404, detail="Mission not found")

    if not payload.submission_content.strip():
        raise HTTPException(status_code=400, detail="Submission content cannot be empty")

    # Evaluate submission via AI Service (with deterministic fallback)
    eval_result = await ai_service.evaluate_mission_submission(
        mission_title=m.title,
        category=m.category,
        scenario_context=m.scenario_context,
        submission_content=payload.submission_content,
        rubric=m.evaluation_rubric,
        test_cases=m.test_cases
    )

    score = eval_result["score"]
    status_enum = SubmissionStatus.PASSED if score >= 70.0 else SubmissionStatus.NEEDS_REVISION

    submission = MissionSubmission(
        mission_id=m.id,
        user_id=current_user.id,
        submission_content=payload.submission_content,
        status=status_enum,
        score=score,
        feedback=eval_result["feedback"],
        rubric_breakdown=eval_result["rubric_breakdown"],
        test_results=eval_result["test_results"],
        is_ai_generated=eval_result["is_ai_generated"],
        evaluation_engine=eval_result["evaluation_engine"],
        submitted_at=datetime.now(timezone.utc),
        evaluated_at=datetime.now(timezone.utc)
    )
    db.add(submission)

    # If passed, register in UserSkillScore and SkillPassport
    if score >= 70.0:
        # Update user's skill scores for skills touched by this mission
        for sk_name in (m.required_skills or []):
            skill_obj = db.query(Skill).filter(Skill.name.ilike(f"%{sk_name}%")).first()
            if skill_obj:
                scoring_service.update_user_skill_from_assessment(
                    db=db,
                    user_id=current_user.id,
                    skill_id=skill_obj.id,
                    assessment_score_pct=score,
                    rubric_note=f"Mission Lab '{m.title}'"
                )

        # Register in Skill Passport evidence
        passport = db.query(SkillPassport).filter(SkillPassport.user_id == current_user.id).first()
        if passport and m.required_skills:
            first_skill = db.query(Skill).filter(Skill.name.ilike(f"%{m.required_skills[0]}%")).first()
            if first_skill:
                ev = PassportEvidence(
                    passport_id=passport.id,
                    skill_id=first_skill.id,
                    evidence_type=EvidenceType.PROJECT_DEMONSTRATED,
                    title=f"Practical Mission Lab: {m.title}",
                    description=f"Demonstrated practical capability with score {score}%. Verified test criteria & rubric rubrics passed.",
                    rubric_score=score,
                    artifact_ref=submission.id,
                    verification_status="VERIFIED",
                    tags=[m.category, m.difficulty.value]
                )
                db.add(ev)

    # Audit log
    audit = AuditLog(
        organization_id=current_user.organization_id,
        user_id=current_user.id,
        action="MISSION_SUBMISSION",
        resource_type="MISSION",
        resource_id=m.id,
        details={"score": score, "status": status_enum.value}
    )
    db.add(audit)
    db.commit()
    db.refresh(submission)

    return MissionSubmissionResponse(
        id=submission.id,
        mission_id=submission.mission_id,
        user_id=submission.user_id,
        submission_content=submission.submission_content,
        status=submission.status,
        score=submission.score,
        feedback=submission.feedback,
        rubric_breakdown=submission.rubric_breakdown,
        test_results=submission.test_results,
        is_ai_generated=submission.is_ai_generated,
        evaluation_engine=submission.evaluation_engine,
        submitted_at=submission.submitted_at,
        evaluated_at=submission.evaluated_at
    )

@router.get("/submissions/me", response_model=List[MissionSubmissionResponse])
def get_user_submissions(
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    subs = db.query(MissionSubmission).filter(
        MissionSubmission.user_id == current_user.id
    ).order_by(MissionSubmission.submitted_at.desc()).all()
    return subs
