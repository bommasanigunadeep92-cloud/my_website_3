from typing import List, Dict, Any, Tuple
from sqlalchemy.orm import Session
from datetime import datetime, timezone

from app.models.skill import Skill, RoleRequirement, UserSkillScore, RoadmapMilestone
from app.models.enums import SkillDemonstrationLevel
from app.services.ai_service import ai_service

class ScoringService:
    @staticmethod
    def get_skill_status(demonstrated_level: float, evidence_count: int) -> SkillDemonstrationLevel:
        if evidence_count == 0 or demonstrated_level == 0.0:
            return SkillDemonstrationLevel.NOT_ASSESSED
        if evidence_count < 2 or demonstrated_level < 2.5:
            return SkillDemonstrationLevel.INSUFFICIENT_EVIDENCE
        if demonstrated_level < 4.0:
            return SkillDemonstrationLevel.DEVELOPING
        return SkillDemonstrationLevel.PROFICIENT

    @staticmethod
    def update_user_skill_from_assessment(
        db: Session,
        user_id: str,
        skill_id: str,
        assessment_score_pct: float,
        rubric_note: str = "Diagnostic assessment result"
    ) -> UserSkillScore:
        score_obj = db.query(UserSkillScore).filter(
            UserSkillScore.user_id == user_id,
            UserSkillScore.skill_id == skill_id
        ).first()

        # Convert 0-100% to 1.0 - 5.0 scale
        new_level = round(max(1.0, min(5.0, (assessment_score_pct / 100.0) * 5.0)), 1)

        if not score_obj:
            score_obj = UserSkillScore(
                user_id=user_id,
                skill_id=skill_id,
                demonstrated_level=new_level,
                evidence_count=1,
                status=ScoringService.get_skill_status(new_level, 1),
                rubric_summary=f"{rubric_note}: {assessment_score_pct}% ({new_level}/5.0)",
                last_assessed_at=datetime.now(timezone.utc)
            )
            db.add(score_obj)
        else:
            # Running weighted average with new evidence
            updated_count = score_obj.evidence_count + 1
            blended_level = round(((score_obj.demonstrated_level * score_obj.evidence_count) + new_level) / updated_count, 1)
            score_obj.demonstrated_level = blended_level
            score_obj.evidence_count = updated_count
            score_obj.status = ScoringService.get_skill_status(blended_level, updated_count)
            score_obj.rubric_summary = f"{rubric_note}: {assessment_score_pct}% (Blended: {blended_level}/5.0 across {updated_count} assessments)"
            score_obj.last_assessed_at = datetime.now(timezone.utc)

        db.commit()
        db.refresh(score_obj)
        return score_obj

    @staticmethod
    def calculate_skill_gap_analysis(
        db: Session,
        user_id: str,
        target_role: str,
        org_id: str = None
    ) -> Dict[str, Any]:
        """
        Calculates gap between current demonstrated skills and target role requirements.
        """
        # Fetch requirements for the target role
        req_query = db.query(RoleRequirement).filter(RoleRequirement.role_title == target_role)
        if org_id:
            req_query = req_query.filter(
                (RoleRequirement.organization_id == org_id) | (RoleRequirement.organization_id.is_(None))
            )
        requirements = req_query.all()

        # If no role requirements found, fallback to all role requirements or standard benchmark
        if not requirements:
            requirements = db.query(RoleRequirement).filter(
                RoleRequirement.role_title.ilike(f"%{target_role.split()[0]}%")
            ).all()

        # Fetch user skill scores
        user_scores = {
            s.skill_id: s for s in db.query(UserSkillScore).filter(UserSkillScore.user_id == user_id).all()
        }

        strengths = []
        improvement_areas = []
        radar_data = []
        comparison_bars = []
        recommendations = []

        total_req_points = 0.0
        total_demonstrated_points = 0.0
        proficient_count = 0
        developing_count = 0
        missing_count = 0

        for req in requirements:
            skill = req.skill
            score_record = user_scores.get(req.skill_id)
            demonstrated = score_record.demonstrated_level if score_record else 0.0
            evidence_count = score_record.evidence_count if score_record else 0
            status = score_record.status if score_record else SkillDemonstrationLevel.NOT_ASSESSED

            gap = max(0.0, round(req.required_level - demonstrated, 1))
            total_req_points += (req.required_level * req.importance_weight)
            total_demonstrated_points += (min(req.required_level, demonstrated) * req.importance_weight)

            if status == SkillDemonstrationLevel.PROFICIENT and gap == 0:
                proficient_count += 1
            elif status == SkillDemonstrationLevel.DEVELOPING:
                developing_count += 1
            else:
                missing_count += 1

            reason = ai_service.explain_skill_gap(target_role, skill.name, demonstrated, req.required_level)
            recommended_action = "Maintain mastery via advanced mission labs" if gap == 0 else f"Complete diagnostic & practical mission for {skill.name}"

            item = {
                "skill_id": skill.id,
                "skill_name": skill.name,
                "category": skill.category,
                "demonstrated_level": demonstrated,
                "required_level": req.required_level,
                "gap": gap,
                "status": status,
                "evidence_count": evidence_count,
                "importance_weight": req.importance_weight,
                "reason": reason,
                "recommended_action": recommended_action
            }

            if gap == 0 and demonstrated > 0:
                strengths.append(item)
            else:
                improvement_areas.append(item)

            radar_data.append({
                "skill": skill.name,
                "demonstrated": demonstrated,
                "required": req.required_level,
                "full_mark": 5.0
            })

            comparison_bars.append({
                "skill": skill.name,
                "current": demonstrated,
                "target": req.required_level,
                "gap": gap
            })

            if gap > 0:
                recommendations.append({
                    "skill_name": skill.name,
                    "target_role": target_role,
                    "gap": gap,
                    "priority": "High" if req.importance_weight > 1.2 or gap >= 2.0 else "Medium",
                    "action": f"Prioritize practical practice in {skill.name} to close the {gap:.1f} point gap."
                })

        # Calculate overall readiness percentage
        readiness_pct = round((total_demonstrated_points / total_req_points * 100), 1) if total_req_points > 0 else 0.0

        return {
            "target_role": target_role,
            "overall_readiness_pct": readiness_pct,
            "total_skills_required": len(requirements),
            "proficient_skills_count": proficient_count,
            "developing_skills_count": developing_count,
            "missing_evidence_count": missing_count,
            "strengths": strengths,
            "improvement_areas": improvement_areas,
            "radar_data": radar_data,
            "comparison_bars": comparison_bars,
            "recommendations": recommendations
        }

scoring_service = ScoringService()
