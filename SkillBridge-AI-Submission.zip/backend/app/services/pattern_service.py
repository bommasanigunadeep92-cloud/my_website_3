from typing import List, Dict, Any
from sqlalchemy.orm import Session
from datetime import datetime, timezone
from app.models.failure_prevention import FailureReport, FailurePattern, InterventionTracking
from app.models.skill import Skill
from app.models.mission import Mission
from app.models.enums import InterventionStatus
from app.core.config import settings

class PatternService:
    @staticmethod
    def analyze_and_cluster_reports(db: Session, org_id: str) -> List[FailurePattern]:
        """
        Groups reports by skill & topic similarity and creates/updates FailurePatterns.
        """
        reports = db.query(FailureReport).filter(FailureReport.organization_id == org_id).all()
        if not reports:
            return []

        # Group reports by (skill_id, normalized_topic)
        grouped: Dict[str, List[FailureReport]] = {}
        for r in reports:
            norm_topic = r.topic.strip().lower()
            key = f"{r.skill_id}::{norm_topic}"
            if key not in grouped:
                grouped[key] = []
            grouped[key].append(r)

        active_patterns = []

        for key, report_list in grouped.items():
            skill_id, norm_topic = key.split("::")
            count = len(report_list)

            # Look up existing pattern
            pattern = db.query(FailurePattern).filter(
                FailurePattern.organization_id == org_id,
                FailurePattern.skill_id == skill_id,
                FailurePattern.topic.ilike(f"%{norm_topic}%")
            ).first()

            skill = db.query(Skill).filter(Skill.id == skill_id).first()
            skill_name = skill.name if skill else "Core Skill"

            # Check if there is a relevant mission
            mission = db.query(Mission).filter(
                (Mission.category.ilike(f"%{skill_name}%")) | (Mission.title.ilike(f"%{norm_topic}%"))
            ).first()
            mission_id = mission.id if mission else None

            # Generate targeted intervention details
            intervention_details = {
                "title": f"Targeted Remediation: {norm_topic.title()} in {skill_name}",
                "description": f"Targeted micro-intervention developed to resolve recurring difficulties with {norm_topic}. Includes step-by-step diagnostic breakdown and practical application.",
                "practice_prompt": f"Review key syntax patterns for {norm_topic}. Construct a verifiable sample isolating edge-cases and error bounds.",
                "linked_mission_id": mission_id,
                "refresher_steps": [
                    f"1. Review diagnostic breakdown for {norm_topic}.",
                    "2. Identify common syntax or logical stumbling points highlighted in peer feedback.",
                    "3. Complete the focused micro-assessment.",
                    "4. Validate resolution with practical mission evidence."
                ]
            }

            if not pattern:
                pattern = FailurePattern(
                    organization_id=org_id,
                    skill_id=skill_id,
                    topic=norm_topic.title(),
                    cluster_title=f"Recurring Difficulty Pattern: {norm_topic.title()}",
                    report_count=count,
                    confidence_score=min(0.98, 0.65 + (count * 0.1)),
                    status="ACTIVE",
                    recommended_intervention_type="MICRO_EXERCISE",
                    intervention_details=intervention_details,
                    detected_at=datetime.now(timezone.utc)
                )
                db.add(pattern)
                db.flush()
            else:
                pattern.report_count = count
                pattern.confidence_score = min(0.98, 0.65 + (count * 0.1))
                pattern.intervention_details = intervention_details

            # Auto-enroll learners who reported into InterventionTracking if not already tracked
            for rep in report_list:
                if rep.user_id:
                    existing_tracking = db.query(InterventionTracking).filter(
                        InterventionTracking.failure_pattern_id == pattern.id,
                        InterventionTracking.user_id == rep.user_id
                    ).first()

                    if not existing_tracking:
                        tracking = InterventionTracking(
                            failure_pattern_id=pattern.id,
                            user_id=rep.user_id,
                            status=InterventionStatus.ASSIGNED,
                            pre_intervention_score=48.0,  # Baseline score before intervention
                            post_intervention_score=None,
                            score_delta=None,
                            evidence_demonstrated=False
                        )
                        db.add(tracking)

            active_patterns.append(pattern)

        db.commit()
        return active_patterns

pattern_service = PatternService()
