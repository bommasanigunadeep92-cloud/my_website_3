# SkillBridge AI — Corporate Learning and Skill Development Platform

> **Product 42: Next-Generation Enterprise Continuous Learning, Real-World Practical Assessment, and Organizational Knowledge Continuity Platform**

[![Python 3.11+](https://img.shields.io/badge/Python-3.11%2B-blue.svg)](https://www.python.org/)
[![FastAPI](https://img.shields.io/badge/FastAPI-0.110%2B-009688.svg)](https://fastapi.tiangolo.com/)
[![React 18+](https://img.shields.io/badge/React-18%2F19-61dafb.svg)](https://react.dev/)
[![TypeScript](https://img.shields.io/badge/TypeScript-5.0%2B-3178c6.svg)](https://www.typescriptlang.org/)
[![Vite](https://img.shields.io/badge/Vite-5%2F6-646cff.svg)](https://vitejs.dev/)
[![Tailwind CSS](https://img.shields.io/badge/TailwindCSS-3.4%2B-38b2ac.svg)](https://tailwindcss.com/)
[![Alembic Migrations](https://img.shields.io/badge/Alembic-Migrations_Active-red.svg)](https://alembic.sqlalchemy.org/)
[![License](https://img.shields.io/badge/License-MIT-green.svg)](LICENSE)

---

## 1. Project Vision & Architecture

**SkillBridge AI** answers the five fundamental questions of modern enterprise talent development:

1. **What skills does a learner currently demonstrate?** (Diagnostic assessments without artificial score inflation)
2. **What skills should they improve?** (Transparent 1.0–5.0 benchmark comparisons against specific workplace roles)
3. **Can they apply those skills to realistic workplace problems?** (Real-world mission labs with test suites and rubrics)
4. **How can recurring learning difficulties be prevented?** (Clustered failure patterns with measured remediation deltas)
5. **How can learners and organizations demonstrate measurable improvement?** (Verifiable, portable evidence passports)

### Core Architectural Principle
Move beyond passive course completion percentages. Focus entirely on demonstrated capability, practical problem solving, remedial failure loops, and organizational knowledge resilience.

---

## 2. The Six Interconnected Core Innovations

| Module | Core Innovation | Description & Capabilities |
|---|---|---|
| **Module 1** | **Smart Skill Gap Detector** | Select target workplace roles (e.g., *Senior Full-Stack Engineer*, *Cloud Data & Analytics Specialist*), compare verified proficiencies against benchmark requirements, generate interactive skill radar geometry and gap bars, and formulate personalized sequenced roadmaps with milestone tracking. |
| **Module 2** | **Real-World Mission Lab** | Hands-on task execution across SQL, system architecture, concurrency, and crisis communication. Submissions run against automated test assertions and transparent scoring rubrics with fallback engine transparency. |
| **Module 3** | **Skill Failure Prevention Loop** | Systematic aggregation of learning difficulties with anonymous reporting. Automatically detects recurring failure clusters across permitted datasets, deploys targeted micro-interventions, and proves measured pre/post score improvements (+46.5% delta). |
| **Module 4** | **Consequence-Based Learning Simulator** | Interactive branching workplace decision trees (handling customer outage escalations, technical debt vs deadline disputes, multi-task executive fire-drills). Features dynamic real-time gauges for Stakeholder Trust, Operational Risk, and Resolution Efficiency. |
| **Module 5** | **Knowledge Continuity Radar** | Identifies Single-Points-of-Failure (SPOFs) where critical procedures depend on a lone subject-matter expert or have lapsed past their review cadence. Manages and verifies shadow cross-training rotations. |
| **Module 6** | **Evidence-Based Skill Passport** | Portable, verifiable portfolio distinguishing self-reported credentials from platform-assessed diagnostics, practical mission artifacts, and supervised rotations. Includes revocable public share tokens and official verification statements. |

---

## 3. Technology Stack

### Frontend
- **Framework**: React 18/19 with TypeScript and Vite
- **Styling**: Tailwind CSS with custom SaaS navy, violet, indigo, and teal palettes
- **Data Visualization**: Recharts (Radar charts, horizontal comparison bars, area charts, line trends)
- **Icons**: Lucide React
- **Component Primitives**: Radix UI accessible patterns, custom Badges, Cards, and Modals
- **Interactions**: Canvas-Confetti celebration triggers on verified completions

### Backend
- **Framework**: Python 3.11+ / FastAPI
- **Validation**: Pydantic v2 schemas and models
- **Database & ORM**: SQLAlchemy 2.0 with PostgreSQL compatibility and zero-config local SQLite support
- **Migrations**: Alembic database migrations
- **Authentication**: JWT tokens (PyJWT) with bcrypt salt rounds
- **AI Service**: Provider-independent LLM service (Gemini / OpenAI / Anthropic) with deterministic fallback rubrics

---

## 4. Quick Start & Local Setup

### Prerequisites
- Python 3.10+ installed
- Node.js 18+ and npm installed

### Step 1: Clone & Configure Environment
```bash
git clone <repo-url>
cd "Corporate Learning and Skill Development Platform"
cp .env.example .env
```

### Step 2: Backend Setup
```bash
# Create and activate virtual environment
python -m venv .venv

# Windows:
.\.venv\Scripts\Activate.ps1
# macOS/Linux:
# source .venv/bin/activate

# Install dependencies
pip install -r backend/requirements.txt

# Run database migrations
cd backend
alembic upgrade head

# Seed rich demonstration data
python app/seed/seed_data.py
cd ..
```

### Step 3: Frontend Setup
```bash
cd frontend
npm install --legacy-peer-deps
npm run build
cd ..
```

### Step 4: Run Application
In terminal 1 (Backend API on `http://localhost:8000`):
```bash
.venv\Scripts\python.exe -m uvicorn app.main:app --host 0.0.0.0 --port 8000 --app-dir backend --reload
```

In terminal 2 (Frontend Client on `http://localhost:5173`):
```bash
cd frontend
npm run dev
```

---

## 5. Pre-Seeded Demonstration Accounts

The platform includes seeded accounts for instantaneous review across all roles:

| Role | Email | Password | Persona & Department |
|---|---|---|---|
| **Learner** | `alex@acme.com` | `LearnerPass123!` | Alex Rivera — Software Associate, Product Engineering |
| **Manager** | `manager@acme.com` | `ManagerPass123!` | Marcus Brody — Engineering Director & Technical Mentor |
| **Administrator** | `admin@acme.com` | `AdminPass123!` | Sarah Chen — VP of Talent Architecture |

*Tip: You can also use the **Quick Demo Persona Switcher** dropdown located in the top navigation bar to switch between Alex, Marcus, and Sarah with a single click.*

---

## 6. Docker & Container Deployment

To launch the full stack with isolated PostgreSQL database:

```bash
docker compose up --build
```
- Frontend UI: `http://localhost:5173`
- Backend API & OpenAPI Docs: `http://localhost:8000/api/v1/docs`
- PostgreSQL: `localhost:5432`

---

## 7. Running Automated Tests

Run the full suite of automated unit and integration tests:

```bash
.venv\Scripts\python.exe -m pytest backend/tests/test_api.py -v
```

### Test Coverage Highlights
- `test_root_and_health`: Health check and operational status
- `test_auth_login_learner` & `test_auth_login_invalid`: Token issuance and credential validation
- `test_skills_gap_analysis`: Dynamic role benchmarking and radar geometry
- `test_missions_list_and_submission`: Automated test assertions, rubric scoring, and passport minting
- `test_scenario_flow`: Multi-step consequence-based decisions and metric tracking
- `test_failure_prevention_flow`: Report submission, pattern clustering, and intervention tracking
- `test_knowledge_radar_and_spof`: Single-point-of-failure risk detection
- `test_passport_public_share`: Unauthenticated public passport view via revocable share token

---

## 8. Privacy, Ethics & Governance Safeguards

1. **No Algorithmic Dismissals**: Assessment and simulator scores are strictly developmental. The system prohibits punitive employment actions based on algorithmic metrics.
2. **Minimum Anonymity Thresholds**: Learning difficulty reports enforce a minimum aggregation threshold (3+ learners) before appearing in manager views to prevent individual targeting.
3. **Multi-Tenant Scoping**: All database queries and API endpoints are strictly scoped to organizational boundaries (`organization_id`). Private documentation is never shared across tenants.
4. **Revocable Credential Sharing**: Learners maintain complete control over their Skill Passport sharing tokens and can revoke external access at any moment.

---

## 9. License

This project is licensed under the MIT License.
