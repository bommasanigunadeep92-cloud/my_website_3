import React, { useState } from "react";
import { NavLink } from "react-router-dom";
import {
  LayoutDashboard,
  Target,
  Briefcase,
  AlertTriangle,
  PlayCircle,
  BookOpen,
  Award,
  BarChart3,
  CheckSquare,
  ChevronLeft,
  ChevronRight,
  Shield,
  Layers,
  Sparkles
} from "lucide-react";
import { useAuth } from "../../context/AuthContext";
import { cn } from "../../lib/utils";

export const Sidebar: React.FC = () => {
  const { user } = useAuth();
  const [collapsed, setCollapsed] = useState(false);

  const mainLinks = [
    {
      to: "/dashboard",
      label: "Learner Dashboard",
      icon: LayoutDashboard,
      badge: null,
    },
    ...(user?.role === "MANAGER" || user?.role === "ADMIN"
      ? [
          {
            to: "/corporate",
            label: "Corporate Hub",
            icon: BarChart3,
            badge: "Team",
          },
        ]
      : []),
  ];

  const innovationLinks = [
    {
      to: "/skills",
      label: "Smart Skill Gap Detector",
      icon: Target,
      tag: "Mod 1",
      badge: "Core",
    },
    {
      to: "/missions",
      label: "Real-World Mission Lab",
      icon: Briefcase,
      tag: "Mod 2",
      badge: "Hands-on",
    },
    {
      to: "/failure-prevention",
      label: "Failure Prevention Loop",
      icon: AlertTriangle,
      tag: "Mod 3",
      badge: "Remedy",
    },
    {
      to: "/simulator",
      label: "Consequence Simulator",
      icon: PlayCircle,
      tag: "Mod 4",
      badge: "Decisions",
    },
    {
      to: "/knowledge",
      label: "Knowledge Continuity Radar",
      icon: BookOpen,
      tag: "Mod 5",
      badge: "SPOF",
    },
    {
      to: "/passport",
      label: "Evidence Skill Passport",
      icon: Award,
      tag: "Mod 6",
      badge: "Verified",
    },
  ];

  const auxiliaryLinks = [
    {
      to: "/assessments",
      label: "Diagnostic Assessments",
      icon: CheckSquare,
      badge: null,
    },
    ...(user?.role === "ADMIN" || user?.role === "MANAGER"
      ? [
          {
            to: "/corporate/audit",
            label: "Security Audit Logs",
            icon: Shield,
            badge: "Admin",
          },
        ]
      : []),
  ];

  return (
    <aside
      className={cn(
        "hidden md:flex flex-col border-r border-slate-200/80 dark:border-slate-800 bg-white dark:bg-navy-950 transition-all duration-300 relative select-none",
        collapsed ? "w-18" : "w-64"
      )}
    >
      {/* Toggle button */}
      <button
        onClick={() => setCollapsed(!collapsed)}
        className="absolute -right-3 top-20 z-30 h-6 w-6 rounded-full border border-slate-200 dark:border-slate-700 bg-white dark:bg-navy-900 text-slate-500 hover:text-slate-900 dark:hover:text-white flex items-center justify-center shadow-sm transition-transform active:scale-95"
        title={collapsed ? "Expand sidebar" : "Collapse sidebar"}
      >
        {collapsed ? <ChevronRight className="h-3.5 w-3.5" /> : <ChevronLeft className="h-3.5 w-3.5" />}
      </button>

      {/* Nav Content */}
      <div className="flex-1 overflow-y-auto px-3 py-4 space-y-6">
        {/* Main Section */}
        <div>
          {!collapsed && (
            <div className="px-3 mb-2 text-[11px] font-semibold tracking-wider text-slate-400 dark:text-slate-500 uppercase">
              Navigation
            </div>
          )}
          <div className="space-y-1">
            {mainLinks.map((item) => (
              <NavLink
                key={item.to}
                to={item.to}
                className={({ isActive }) =>
                  cn(
                    "flex items-center gap-3 px-3 py-2 rounded-lg text-xs font-medium transition-colors",
                    isActive
                      ? "bg-brand-500/10 text-brand-600 dark:text-brand-300 font-semibold"
                      : "text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-900 hover:text-slate-900 dark:hover:text-white",
                    collapsed && "justify-center px-2"
                  )
                }
                title={collapsed ? item.label : undefined}
              >
                <item.icon className="h-4 w-4 shrink-0" />
                {!collapsed && (
                  <div className="flex-1 flex items-center justify-between">
                    <span>{item.label}</span>
                    {item.badge && (
                      <span className="text-[10px] px-1.5 py-0.2 rounded bg-indigo-100 dark:bg-indigo-900/60 text-indigo-700 dark:text-indigo-300">
                        {item.badge}
                      </span>
                    )}
                  </div>
                )}
              </NavLink>
            ))}
          </div>
        </div>

        {/* 6 Innovations */}
        <div>
          {!collapsed && (
            <div className="px-3 mb-2 flex items-center justify-between">
              <span className="text-[11px] font-semibold tracking-wider text-brand-500 dark:text-brand-400 uppercase flex items-center gap-1.5">
                <Sparkles className="h-3 w-3" /> 6 Core Innovations
              </span>
            </div>
          )}
          <div className="space-y-1">
            {innovationLinks.map((item) => (
              <NavLink
                key={item.to}
                to={item.to}
                className={({ isActive }) =>
                  cn(
                    "flex items-center gap-3 px-3 py-2 rounded-lg text-xs font-medium transition-colors group",
                    isActive
                      ? "bg-brand-600 text-white shadow-sm shadow-brand-500/20 font-semibold"
                      : "text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-900 hover:text-slate-900 dark:hover:text-white",
                    collapsed && "justify-center px-2"
                  )
                }
                title={collapsed ? `${item.tag}: ${item.label}` : undefined}
              >
                <item.icon className="h-4 w-4 shrink-0" />
                {!collapsed && (
                  <div className="flex-1 flex items-center justify-between overflow-hidden">
                    <span className="truncate">{item.label}</span>
                    <span
                      className={cn(
                        "text-[9px] px-1 py-0.2 rounded font-mono shrink-0",
                        "bg-slate-200/80 dark:bg-slate-800 text-slate-700 dark:text-slate-300 group-hover:bg-brand-100 dark:group-hover:bg-brand-900/40"
                      )}
                    >
                      {item.tag}
                    </span>
                  </div>
                )}
              </NavLink>
            ))}
          </div>
        </div>

        {/* Diagnostic Labs & System */}
        <div>
          {!collapsed && (
            <div className="px-3 mb-2 text-[11px] font-semibold tracking-wider text-slate-400 dark:text-slate-500 uppercase">
              Assessments & Audit
            </div>
          )}
          <div className="space-y-1">
            {auxiliaryLinks.map((item) => (
              <NavLink
                key={item.to}
                to={item.to}
                className={({ isActive }) =>
                  cn(
                    "flex items-center gap-3 px-3 py-2 rounded-lg text-xs font-medium transition-colors",
                    isActive
                      ? "bg-slate-200 dark:bg-slate-800 text-slate-900 dark:text-white font-semibold"
                      : "text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-900 hover:text-slate-900 dark:hover:text-white",
                    collapsed && "justify-center px-2"
                  )
                }
                title={collapsed ? item.label : undefined}
              >
                <item.icon className="h-4 w-4 shrink-0" />
                {!collapsed && <span>{item.label}</span>}
              </NavLink>
            ))}
          </div>
        </div>
      </div>

      {/* Footer Info Card */}
      {!collapsed && (
        <div className="p-3 border-t border-slate-200/80 dark:border-slate-800 bg-slate-50/50 dark:bg-navy-900/40">
          <div className="flex items-center gap-2 p-2 rounded-lg bg-white dark:bg-navy-950 border border-slate-200/80 dark:border-slate-800 text-xs">
            <div className="h-2 w-2 rounded-full bg-emerald-500 animate-pulse" />
            <div className="flex-1 truncate">
              <span className="font-medium text-slate-800 dark:text-slate-200 text-[11px] block">
                Evidence Engine Live
              </span>
              <span className="text-[10px] text-slate-400 block truncate">Deterministic + Gemini Fallback</span>
            </div>
          </div>
        </div>
      )}
    </aside>
  );
};
