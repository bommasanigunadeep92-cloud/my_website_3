import {
  User,
  Skill,
  SkillGapAnalysis,
  RoadmapMilestone,
  Assessment,
  AssessmentAttempt,
  Mission,
  MissionSubmission,
  FailureReport,
  FailurePattern,
  InterventionTracking,
  Scenario,
  ScenarioAttempt,
  KnowledgeArticle,
  KnowledgeRadarAnalytics,
  CrossTrainingAssignment,
  SkillPassport,
  PassportEvidence
} from "./types";

import {
  MOCK_USERS,
  MOCK_SKILLS,
  MOCK_ROLES,
  MOCK_GAP_ANALYSIS,
  MOCK_ROADMAP,
  MOCK_ASSESSMENTS,
  MOCK_MISSIONS,
  MOCK_SUBMISSIONS,
  MOCK_FAILURE_REPORTS,
  MOCK_FAILURE_PATTERNS,
  MOCK_INTERVENTIONS,
  MOCK_SCENARIOS,
  MOCK_SCENARIO_ATTEMPTS,
  MOCK_KNOWLEDGE_ARTICLES,
  MOCK_KNOWLEDGE_ANALYTICS,
  MOCK_CROSS_TRAINING,
  MOCK_PASSPORT,
  MOCK_CORPORATE_OVERVIEW,
  MOCK_CORPORATE_AUDIT_LOGS
} from "./mockData";

const API_BASE = "http://localhost:8000/api/v1";

class ApiClient {
  private isOfflineMode = false;

  private getToken(): string | null {
    return localStorage.getItem("skillbridge_token");
  }

  private getCurrentUserEmail(): string {
    return localStorage.getItem("skillbridge_user_email") || "alex@acme.com";
  }

  private async request<T>(endpoint: string, options: RequestInit = {}): Promise<T> {
    // If running in browser and already detected offline or remote host with no backend:
    const isLocal = typeof window !== "undefined" && (window.location.hostname === "localhost" || window.location.hostname === "127.0.0.1");

    if (this.isOfflineMode || (!isLocal && !this.getToken()?.startsWith("real_"))) {
      return this.handleMockFallback<T>(endpoint, options);
    }

    try {
      const token = this.getToken();
      const headers: Record<string, string> = {
        "Content-Type": "application/json",
        ...(options.headers as Record<string, string>),
      };

      if (token) {
        headers["Authorization"] = `Bearer ${token}`;
      }

      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 3500);

      const response = await fetch(`${API_BASE}${endpoint}`, {
        ...options,
        headers,
        signal: controller.signal,
      });

      clearTimeout(timeoutId);

      if (!response.ok) {
        let errorMessage = "An unexpected server error occurred";
        try {
          const errorData = await response.json();
          errorMessage = errorData.detail || errorData.message || errorMessage;
        } catch {
          errorMessage = response.statusText || errorMessage;
        }
        throw new Error(errorMessage);
      }

      return response.json();
    } catch (err: any) {
      // Backend not running locally or deployed on static host (e.g. Vercel)
      console.warn(`[SkillBridge API] Live backend unavailable at ${endpoint}. Activating responsive mock engine:`, err.message);
      this.isOfflineMode = true;
      return this.handleMockFallback<T>(endpoint, options);
    }
  }

  // Robust Mock Fallback Handler for static / Vercel cloud deployments
  private async handleMockFallback<T>(endpoint: string, options: RequestInit = {}): Promise<T> {
    const method = options.method || "GET";
    const body = options.body ? JSON.parse(options.body as string) : {};

    // Small realistic latency simulation
    await new Promise((resolve) => setTimeout(resolve, 80));

    // Auth
    if (endpoint === "/auth/login" && method === "POST") {
      const email = body.email || "alex@acme.com";
      const user = MOCK_USERS[email] || {
        id: `usr-${Date.now()}`,
        email,
        full_name: email.split("@")[0].replace(".", " ").replace(/\b\w/g, (c: string) => c.toUpperCase()),
        role: "LEARNER",
        organization_id: "org-acme-001",
        organization_name: "Acme Global Technologies",
        department: "Engineering",
        job_title: "Software Engineer",
        target_role: "Senior Full-Stack Engineer",
        is_active: true,
        created_at: new Date().toISOString()
      };
      localStorage.setItem("skillbridge_user_email", email);
      return { access_token: `mock_jwt_${Date.now()}`, user } as T;
    }

    if (endpoint === "/auth/register" && method === "POST") {
      const user: User = {
        id: `usr-${Date.now()}`,
        email: body.email,
        full_name: body.full_name,
        role: (body.role as any) || "LEARNER",
        organization_id: "org-acme-001",
        organization_name: "Acme Global Technologies",
        department: body.department || "Engineering",
        job_title: body.job_title || "Associate",
        target_role: body.target_role || "Senior Full-Stack Engineer",
        is_active: true,
        created_at: new Date().toISOString()
      };
      localStorage.setItem("skillbridge_user_email", body.email);
      MOCK_USERS[body.email] = user;
      return { access_token: `mock_jwt_${Date.now()}`, user } as T;
    }

    if (endpoint === "/auth/me") {
      const email = this.getCurrentUserEmail();
      const user = MOCK_USERS[email] || MOCK_USERS["alex@acme.com"];
      return user as T;
    }

    // Skills & Gap Detector
    if (endpoint.startsWith("/skills/roles")) {
      return { roles: MOCK_ROLES } as T;
    }

    if (endpoint.startsWith("/skills/gap-analysis")) {
      return MOCK_GAP_ANALYSIS as T;
    }

    if (endpoint === "/skills/target-role" && method === "POST") {
      return { target_role: body.target_role } as T;
    }

    if (endpoint === "/skills/roadmap") {
      return MOCK_ROADMAP as T;
    }

    if (endpoint.includes("/skills/roadmap/milestones/") && endpoint.endsWith("/toggle")) {
      return { success: true, message: "Milestone status updated" } as T;
    }

    if (endpoint.startsWith("/skills")) {
      return MOCK_SKILLS as T;
    }

    // Diagnostic Assessments
    if (endpoint.startsWith("/assessments/history/me")) {
      return [] as T;
    }

    if (endpoint === "/assessments" || endpoint.startsWith("/assessments?")) {
      return MOCK_ASSESSMENTS as T;
    }

    if (endpoint.startsWith("/assessments/") && !endpoint.includes("/submit")) {
      return MOCK_ASSESSMENTS[0] as T;
    }

    if (endpoint.includes("/assessments/") && endpoint.endsWith("/submit")) {
      const attempt: AssessmentAttempt = {
        id: `att-${Date.now()}`,
        assessment_id: "ass-01",
        assessment_title: "Cloud Native Architecture Diagnostic",
        user_id: "usr-alex-001",
        score: 85,
        passed: true,
        started_at: new Date(Date.now() - 900000).toISOString(),
        completed_at: new Date().toISOString(),
        feedback_notes: "Strong demonstrated understanding of asynchronous task concurrency and isolation levels.",
        is_ai_generated: false
      };
      return attempt as T;
    }

    // Real-World Mission Lab
    if (endpoint.startsWith("/missions/submissions/me")) {
      return MOCK_SUBMISSIONS as T;
    }

    if (endpoint === "/missions" || endpoint.startsWith("/missions?")) {
      return MOCK_MISSIONS as T;
    }

    if (endpoint.startsWith("/missions/") && !endpoint.includes("/submit")) {
      const id = endpoint.split("/")[2]?.split("?")[0];
      const mission = MOCK_MISSIONS.find((m) => m.id === id) || MOCK_MISSIONS[0];
      return mission as T;
    }

    if (endpoint.includes("/missions/") && endpoint.endsWith("/submit")) {
      const submission: MissionSubmission = {
        id: `sub-${Date.now()}`,
        mission_id: "mis-01",
        user_id: "usr-alex-001",
        submission_content: body.submission_content || "",
        status: "PASSED",
        score: 94,
        feedback: "Excellent solution! The submitted query correctly imposes deterministic sorting on locked rows, resolving circular wait contention under high concurrency.",
        rubric_breakdown: [
          { criterion: "Root Cause Identification", points_awarded: 30, max_points: 30, notes: "Correctly diagnosed cyclic lock dependency." },
          { criterion: "Deterministic Query Solution", points_awarded: 38, max_points: 40, notes: "Monotonic ORDER BY sku applied with FOR UPDATE." },
          { criterion: "Error Handling & Idempotency", points_awarded: 26, max_points: 30, notes: "Backoff retry logic clearly outlined." }
        ],
        test_results: [
          { test_name: "Deterministic Lock Ordering", passed: true, requirement: "Rows locked in consistent order", feedback: "PASSED" },
          { test_name: "Deadlock Prevention Suite", passed: true, requirement: "100 concurrent workers run without lock deadlock", feedback: "0 deadlocks observed" },
          { test_name: "Atomicity Verification", passed: true, requirement: "All inventory items update atomically or rollback", feedback: "PASSED" }
        ],
        is_ai_generated: false,
        evaluation_engine: "DETERMINISTIC_ASSERTION_SUITE",
        submitted_at: new Date().toISOString(),
        evaluated_at: new Date().toISOString()
      };
      MOCK_SUBMISSIONS.unshift(submission);
      return submission as T;
    }

    // Skill Failure Prevention Loop
    if (endpoint === "/failure-prevention/reports" && method === "POST") {
      const report: FailureReport = {
        id: `rep-${Date.now()}`,
        user_id: "usr-alex-001",
        user_name: "Alex Rivera",
        skill_id: body.skill_id,
        skill_name: "PostgreSQL Optimization & Deadlocks",
        topic: body.topic,
        description: body.description,
        error_snippet: body.error_snippet,
        emotional_blocker: body.emotional_blocker,
        is_anonymous: !!body.is_anonymous,
        created_at: new Date().toISOString()
      };
      MOCK_FAILURE_REPORTS.unshift(report);
      return report as T;
    }

    if (endpoint.startsWith("/failure-prevention/reports/me")) {
      return MOCK_FAILURE_REPORTS as T;
    }

    if (endpoint.startsWith("/failure-prevention/patterns")) {
      return MOCK_FAILURE_PATTERNS as T;
    }

    if (endpoint.startsWith("/failure-prevention/interventions/me")) {
      return MOCK_INTERVENTIONS as T;
    }

    if (endpoint.includes("/failure-prevention/interventions/") && endpoint.endsWith("/complete")) {
      return {
        id: "int-01",
        failure_pattern_id: "pat-01",
        user_id: "usr-alex-001",
        status: "COMPLETED",
        pre_intervention_score: 55,
        post_intervention_score: body.post_intervention_score || 92,
        score_delta: (body.post_intervention_score || 92) - 55,
        evidence_demonstrated: true,
        learner_feedback: body.learner_feedback,
        completed_at: new Date().toISOString()
      } as T;
    }

    // Consequence-Based Learning Simulator
    if (endpoint === "/scenarios" || endpoint.startsWith("/scenarios?")) {
      return MOCK_SCENARIOS as T;
    }

    if (endpoint.startsWith("/scenarios/") && !endpoint.includes("/attempt")) {
      const id = endpoint.split("/")[2]?.split("?")[0];
      const scenario = MOCK_SCENARIOS.find((s) => s.id === id) || MOCK_SCENARIOS[0];
      return scenario as T;
    }

    if (endpoint.includes("/scenarios/") && endpoint.endsWith("/attempt")) {
      const attempt: ScenarioAttempt = {
        id: `att-${Date.now()}`,
        scenario_id: "scen-01",
        scenario_title: "Live Incident Commander: Critical Payment Gateway Outage",
        total_score: body.total_score || 90,
        performance_rating: (body.total_score || 90) >= 80 ? "DISTINGUISHED_COMMANDER" : "CAPABLE_RESPONDER",
        debrief_notes: "Strong operational clarity under pressure. Preserved customer cart completion and avoided database starvation.",
        metrics_summary: body.final_metrics || { uptime: 95, trust: 92, sla: 98 },
        steps_history: body.steps_history || [],
        is_ai_generated: false,
        completed_at: new Date().toISOString()
      };
      MOCK_SCENARIO_ATTEMPTS.unshift(attempt);
      return attempt as T;
    }

    if (endpoint.startsWith("/scenarios/history/me")) {
      return MOCK_SCENARIO_ATTEMPTS as T;
    }

    // Knowledge Continuity Radar
    if (endpoint.startsWith("/knowledge/radar/analytics")) {
      return MOCK_KNOWLEDGE_ANALYTICS as T;
    }

    if (endpoint === "/knowledge/articles" || endpoint.startsWith("/knowledge/articles?")) {
      return MOCK_KNOWLEDGE_ARTICLES as T;
    }

    if (endpoint.startsWith("/knowledge/articles/") && !endpoint.includes("/cross-training")) {
      const id = endpoint.split("/")[3]?.split("?")[0];
      const article = MOCK_KNOWLEDGE_ARTICLES.find((a) => a.id === id) || MOCK_KNOWLEDGE_ARTICLES[0];
      return article as T;
    }

    if (endpoint === "/knowledge/cross-training" && method === "POST") {
      const assignment: CrossTrainingAssignment = {
        id: `ct-${Date.now()}`,
        organization_id: "org-acme-001",
        knowledge_article_id: body.knowledge_article_id,
        knowledge_article_title: "Core Payment Ledger Daily Reconciliation & Idempotency Audit",
        primary_expert_id: "usr-marcus-002",
        primary_expert_name: "Marcus Brody",
        backup_learner_id: body.backup_learner_id || "usr-alex-001",
        backup_learner_name: "Alex Rivera",
        target_completion_date: new Date(Date.now() + 14 * 86400000).toISOString(),
        status: "IN_PROGRESS",
        created_at: new Date().toISOString()
      };
      MOCK_CROSS_TRAINING.unshift(assignment);
      return assignment as T;
    }

    if (endpoint.includes("/knowledge/cross-training/") && endpoint.endsWith("/verify")) {
      return {
        id: "ct-01",
        status: "VERIFIED",
        verified_at: new Date().toISOString(),
        verification_notes: body.notes || "Verified procedure mastery."
      } as T;
    }

    // Evidence-Based Skill Passport
    if (endpoint === "/passport/me") {
      return MOCK_PASSPORT as T;
    }

    if (endpoint === "/passport/settings" && method === "PUT") {
      if (body.is_public !== undefined) MOCK_PASSPORT.is_public = body.is_public;
      if (body.headline) MOCK_PASSPORT.headline = body.headline;
      if (body.summary_bio) MOCK_PASSPORT.summary_bio = body.summary_bio;
      return MOCK_PASSPORT as T;
    }

    if (endpoint === "/passport/evidence" && method === "POST") {
      const ev: PassportEvidence = {
        id: `ev-${Date.now()}`,
        passport_id: MOCK_PASSPORT.id,
        skill_id: body.skill_id,
        skill_name: "PostgreSQL Optimization & Deadlocks",
        evidence_type: body.evidence_type || "PROJECT_DEMONSTRATED",
        title: body.title,
        description: body.description,
        rubric_score: body.rubric_score || 90,
        artifact_ref: `SHA256:${Math.random().toString(16).substring(2, 10)}...`,
        verification_status: "VERIFIED",
        verified_at: new Date().toISOString(),
        tags: body.tags || ["Practical Evidence"],
        created_at: new Date().toISOString()
      };
      MOCK_PASSPORT.evidence_items.unshift(ev);
      return ev as T;
    }

    if (endpoint.startsWith("/passport/public/")) {
      return MOCK_PASSPORT as T;
    }

    // Corporate & Manager Analytics
    if (endpoint === "/corporate/overview") {
      return MOCK_CORPORATE_OVERVIEW as T;
    }

    if (endpoint === "/corporate/team-skills") {
      return [
        { skill_name: "FastAPI & Microservices", proficient_pct: 82, developing_pct: 14, unassessed_pct: 4 },
        { skill_name: "TypeScript Clean Architecture", proficient_pct: 78, developing_pct: 18, unassessed_pct: 4 },
        { skill_name: "PostgreSQL Optimization", proficient_pct: 44, developing_pct: 38, unassessed_pct: 18 },
        { skill_name: "Distributed Systems Reliability", proficient_pct: 52, developing_pct: 34, unassessed_pct: 14 },
        { skill_name: "Threat Modeling & SecOps", proficient_pct: 38, developing_pct: 42, unassessed_pct: 20 }
      ] as T;
    }

    if (endpoint === "/corporate/learners") {
      return [
        { id: "usr-alex-001", full_name: "Alex Rivera", email: "alex@acme.com", department: "Product Engineering", job_title: "Software Associate", readiness_score: 78, missions_count: 3 },
        { id: "usr-maya-002", full_name: "Maya Patel", email: "maya@acme.com", department: "Data Analytics", job_title: "Junior Data Analyst", readiness_score: 84, missions_count: 5 },
        { id: "usr-david-003", full_name: "David Kim", email: "david@acme.com", department: "Platform Engineering", job_title: "DevOps Engineer", readiness_score: 91, missions_count: 6 }
      ] as T;
    }

    if (endpoint === "/corporate/audit-logs") {
      return MOCK_CORPORATE_AUDIT_LOGS as T;
    }

    return {} as T;
  }

  // Auth
  async login(email: string, password: string): Promise<{ access_token: string; user: User }> {
    return this.request("/auth/login", {
      method: "POST",
      body: JSON.stringify({ email, password }),
    });
  }

  async register(data: {
    email: string;
    password: string;
    full_name: string;
    role?: string;
    department?: string;
    job_title?: string;
    target_role?: string;
  }): Promise<{ access_token: string; user: User }> {
    return this.request("/auth/register", {
      method: "POST",
      body: JSON.stringify(data),
    });
  }

  async getMe(): Promise<User> {
    return this.request("/auth/me");
  }

  async updateMe(data: Partial<User>): Promise<User> {
    return this.request("/auth/me", {
      method: "PUT",
      body: JSON.stringify(data),
    });
  }

  // Module 1: Skills & Gap Detection
  async getSkills(category?: string): Promise<Skill[]> {
    return this.request(`/skills${category ? `?category=${encodeURIComponent(category)}` : ""}`);
  }

  async getTargetRoles(): Promise<{ roles: string[] }> {
    return this.request("/skills/roles");
  }

  async getSkillGapAnalysis(role?: string): Promise<SkillGapAnalysis> {
    return this.request(`/skills/gap-analysis${role ? `?role=${encodeURIComponent(role)}` : ""}`);
  }

  async setTargetRole(target_role: string): Promise<{ target_role: string }> {
    return this.request("/skills/target-role", {
      method: "POST",
      body: JSON.stringify({ target_role }),
    });
  }

  async getRoadmap(): Promise<RoadmapMilestone[]> {
    return this.request("/skills/roadmap");
  }

  async toggleMilestone(milestoneId: string): Promise<any> {
    return this.request(`/skills/roadmap/milestones/${milestoneId}/toggle`, {
      method: "POST",
    });
  }

  // Diagnostic Assessments
  async getAssessments(category?: string): Promise<Assessment[]> {
    return this.request(`/assessments${category ? `?category=${encodeURIComponent(category)}` : ""}`);
  }

  async getAssessment(id: string): Promise<Assessment> {
    return this.request(`/assessments/${id}`);
  }

  async submitAssessment(id: string, answers: Record<string, string>): Promise<AssessmentAttempt> {
    return this.request(`/assessments/${id}/submit`, {
      method: "POST",
      body: JSON.stringify({ answers }),
    });
  }

  async getAssessmentHistory(): Promise<AssessmentAttempt[]> {
    return this.request("/assessments/history/me");
  }

  // Module 2: Real-World Mission Lab
  async getMissions(category?: string): Promise<Mission[]> {
    return this.request(`/missions${category ? `?category=${encodeURIComponent(category)}` : ""}`);
  }

  async getMission(id: string): Promise<Mission> {
    return this.request(`/missions/${id}`);
  }

  async submitMission(id: string, submission_content: string): Promise<MissionSubmission> {
    return this.request(`/missions/${id}/submit`, {
      method: "POST",
      body: JSON.stringify({ submission_content }),
    });
  }

  async getMySubmissions(): Promise<MissionSubmission[]> {
    return this.request("/missions/submissions/me");
  }

  // Module 3: Skill Failure Prevention Loop
  async submitFailureReport(data: {
    skill_id: string;
    topic: string;
    description: string;
    error_snippet?: string;
    emotional_blocker?: string;
    is_anonymous?: boolean;
  }): Promise<FailureReport> {
    return this.request("/failure-prevention/reports", {
      method: "POST",
      body: JSON.stringify(data),
    });
  }

  async getMyFailureReports(): Promise<FailureReport[]> {
    return this.request("/failure-prevention/reports/me");
  }

  async getFailurePatterns(): Promise<FailurePattern[]> {
    return this.request("/failure-prevention/patterns");
  }

  async getMyInterventions(): Promise<InterventionTracking[]> {
    return this.request("/failure-prevention/interventions/me");
  }

  async completeIntervention(
    trackingId: string,
    data: { post_intervention_score: number; learner_feedback?: string }
  ): Promise<InterventionTracking> {
    return this.request(`/failure-prevention/interventions/${trackingId}/complete`, {
      method: "POST",
      body: JSON.stringify(data),
    });
  }

  // Module 4: Consequence-Based Learning Simulator
  async getScenarios(category?: string): Promise<Scenario[]> {
    return this.request(`/scenarios${category ? `?category=${encodeURIComponent(category)}` : ""}`);
  }

  async getScenario(id: string): Promise<Scenario> {
    return this.request(`/scenarios/${id}`);
  }

  async submitScenarioAttempt(
    id: string,
    data: { steps_history: any[]; final_metrics: Record<string, number>; total_score: number }
  ): Promise<ScenarioAttempt> {
    return this.request(`/scenarios/${id}/attempt`, {
      method: "POST",
      body: JSON.stringify({ scenario_id: id, ...data }),
    });
  }

  async getScenarioHistory(): Promise<ScenarioAttempt[]> {
    return this.request("/scenarios/history/me");
  }

  // Module 5: Organizational Knowledge Continuity Radar
  async getKnowledgeArticles(category?: string, spof_risk?: string): Promise<KnowledgeArticle[]> {
    const params = new URLSearchParams();
    if (category) params.append("category", category);
    if (spof_risk) params.append("spof_risk", spof_risk);
    return this.request(`/knowledge/articles?${params.toString()}`);
  }

  async getKnowledgeArticle(id: string): Promise<KnowledgeArticle> {
    return this.request(`/knowledge/articles/${id}`);
  }

  async createKnowledgeArticle(data: {
    title: string;
    category: string;
    summary: string;
    content: string;
    backup_owner_id?: string;
    primary_skill_id?: string;
    review_cadence_days?: number;
  }): Promise<KnowledgeArticle> {
    return this.request("/knowledge/articles", {
      method: "POST",
      body: JSON.stringify(data),
    });
  }

  async getKnowledgeRadarAnalytics(): Promise<KnowledgeRadarAnalytics> {
    return this.request("/knowledge/radar/analytics");
  }

  async createCrossTraining(data: {
    knowledge_article_id: string;
    backup_learner_id: string;
  }): Promise<CrossTrainingAssignment> {
    return this.request("/knowledge/cross-training", {
      method: "POST",
      body: JSON.stringify(data),
    });
  }

  async verifyCrossTraining(id: string, notes?: string): Promise<CrossTrainingAssignment> {
    return this.request(`/knowledge/cross-training/${id}/verify`, {
      method: "PUT",
      body: JSON.stringify({ notes }),
    });
  }

  // Module 6: Evidence-Based Skill Passport
  async getMyPassport(): Promise<SkillPassport> {
    return this.request("/passport/me");
  }

  async updatePassportSettings(data: {
    is_public?: boolean;
    headline?: string;
    summary_bio?: string;
    generate_new_token?: boolean;
  }): Promise<SkillPassport> {
    return this.request("/passport/settings", {
      method: "PUT",
      body: JSON.stringify(data),
    });
  }

  async addCustomEvidence(data: {
    skill_id: string;
    evidence_type: string;
    title: string;
    description: string;
    rubric_score?: number;
    artifact_ref?: string;
    tags?: string[];
  }): Promise<PassportEvidence> {
    return this.request("/passport/evidence", {
      method: "POST",
      body: JSON.stringify(data),
    });
  }

  async getPublicPassport(shareToken: string): Promise<SkillPassport> {
    return this.request(`/passport/public/${encodeURIComponent(shareToken)}`);
  }

  // Corporate & Manager Analytics
  async getCorporateOverview(): Promise<any> {
    return this.request("/corporate/overview");
  }

  async getCorporateTeamSkills(): Promise<any[]> {
    return this.request("/corporate/team-skills");
  }

  async getCorporateLearners(): Promise<any[]> {
    return this.request("/corporate/learners");
  }

  async getCorporateAuditLogs(): Promise<any[]> {
    return this.request("/corporate/audit-logs");
  }
}

export const api = new ApiClient();
