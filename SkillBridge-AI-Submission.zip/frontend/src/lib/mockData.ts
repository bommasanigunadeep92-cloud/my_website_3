import {
  User,
  Skill,
  SkillGapAnalysis,
  RoadmapMilestone,
  Assessment,
  AssessmentAttempt,
  Mission,
  MissionSubmission,
  FailureReport,
  FailurePattern,
  InterventionTracking,
  Scenario,
  ScenarioAttempt,
  KnowledgeArticle,
  KnowledgeRadarAnalytics,
  CrossTrainingAssignment,
  SkillPassport,
  PassportEvidence
} from "./types";

export const MOCK_USERS: Record<string, User> = {
  "alex@acme.com": {
    id: "usr-alex-001",
    email: "alex@acme.com",
    full_name: "Alex Rivera",
    role: "LEARNER",
    organization_id: "org-acme-001",
    organization_name: "Acme Global Technologies",
    department: "Product Engineering",
    job_title: "Software Associate",
    target_role: "Senior Full-Stack Engineer",
    is_active: true,
    created_at: new Date(Date.now() - 60 * 86400000).toISOString()
  },
  "manager@acme.com": {
    id: "usr-marcus-002",
    email: "manager@acme.com",
    full_name: "Marcus Brody",
    role: "MANAGER",
    organization_id: "org-acme-001",
    organization_name: "Acme Global Technologies",
    department: "Platform & Infrastructure",
    job_title: "Engineering Director",
    target_role: "VP of Systems Architecture",
    is_active: true,
    created_at: new Date(Date.now() - 120 * 86400000).toISOString()
  },
  "admin@acme.com": {
    id: "usr-sarah-003",
    email: "admin@acme.com",
    full_name: "Sarah Chen",
    role: "ADMIN",
    organization_id: "org-acme-001",
    organization_name: "Acme Global Technologies",
    department: "Executive & Talent Architecture",
    job_title: "VP Talent Architecture",
    target_role: "Chief Technology Officer",
    is_active: true,
    created_at: new Date(Date.now() - 180 * 86400000).toISOString()
  }
};

export const MOCK_SKILLS: Skill[] = [
  { id: "skl-01", name: "Distributed Systems Reliability", category: "Architecture & DevOps", description: "Design, fault isolation, bulkhead patterns, and high availability consensus.", created_at: "2026-01-15T00:00:00Z" },
  { id: "skl-02", name: "Incident Response & Runbooks", category: "Operations", description: "Production incident command, postmortems, SLO/SLA management, and runbook orchestration.", created_at: "2026-01-15T00:00:00Z" },
  { id: "skl-03", name: "PostgreSQL Optimization & Deadlocks", category: "Database Engineering", description: "EXPLAIN ANALYZE query plans, transaction isolation, lock contention, and connection pooling.", created_at: "2026-01-15T00:00:00Z" },
  { id: "skl-04", name: "FastAPI & Microservices Architecture", category: "Backend Engineering", description: "Asynchronous Python, Pydantic schemas, dependency injection, and contract testing.", created_at: "2026-01-15T00:00:00Z" },
  { id: "skl-05", name: "TypeScript Clean Architecture", category: "Frontend Engineering", description: "Strict typing, domain-driven design, state machines, and composable UI design.", created_at: "2026-01-15T00:00:00Z" },
  { id: "skl-06", name: "Threat Modeling & SecOps", category: "Security", description: "STRIDE framework, JWT security, CSRF protection, OWASP Top 10 mitigation.", created_at: "2026-01-15T00:00:00Z" },
  { id: "skl-07", name: "React Performance Profiling", category: "Frontend Engineering", description: "Virtual DOM diffing, memoization strategies, bundle splitting, and Web Vitals.", created_at: "2026-01-15T00:00:00Z" },
  { id: "skl-08", name: "CI/CD & Kubernetes Pipeline", category: "Architecture & DevOps", description: "Automated test stages, semantic releases, canary deployments, and Helm charts.", created_at: "2026-01-15T00:00:00Z" }
];

export const MOCK_ROLES = [
  "Senior Full-Stack Engineer",
  "Site Reliability Engineer",
  "Data Platform Architect",
  "Cloud Security Specialist"
];

export const MOCK_GAP_ANALYSIS: SkillGapAnalysis = {
  target_role: "Senior Full-Stack Engineer",
  overall_readiness_pct: 78,
  total_skills_required: 6,
  proficient_skills_count: 3,
  developing_skills_count: 2,
  missing_evidence_count: 1,
  strengths: [
    {
      skill_id: "skl-04",
      skill_name: "FastAPI & Microservices Architecture",
      category: "Backend Engineering",
      demonstrated_level: 4,
      required_level: 4,
      gap: 0,
      status: "PROFICIENT",
      evidence_count: 4,
      importance_weight: 1.0,
      reason: "Demonstrated production-grade async API implementation and schema validation.",
      recommended_action: "Serve as a peer reviewer and mentor junior associates on FastAPI patterns."
    },
    {
      skill_id: "skl-05",
      skill_name: "TypeScript Clean Architecture",
      category: "Frontend Engineering",
      demonstrated_level: 4,
      required_level: 4,
      gap: 0,
      status: "PROFICIENT",
      evidence_count: 3,
      importance_weight: 0.9,
      reason: "Consistently writes type-safe interfaces and modular UI architectures.",
      recommended_action: "Publish an internal design token guide for component reusability."
    },
    {
      skill_id: "skl-07",
      skill_name: "React Performance Profiling",
      category: "Frontend Engineering",
      demonstrated_level: 3,
      required_level: 3,
      gap: 0,
      status: "PROFICIENT",
      evidence_count: 2,
      importance_weight: 0.8,
      reason: "Successfully resolved hydration bottle-necks and optimized render cycles.",
      recommended_action: "Maintain current profiler instrumentation across core user journeys."
    }
  ],
  improvement_areas: [
    {
      skill_id: "skl-03",
      skill_name: "PostgreSQL Optimization & Deadlocks",
      category: "Database Engineering",
      demonstrated_level: 2,
      required_level: 4,
      gap: 2,
      status: "DEVELOPING",
      evidence_count: 1,
      importance_weight: 1.0,
      reason: "Needs practical experience isolating lock contention during high concurrency transactions.",
      recommended_action: "Complete Mission LAB-01: 'Production Database Deadlock Triage'."
    },
    {
      skill_id: "skl-01",
      skill_name: "Distributed Systems Reliability",
      category: "Architecture & DevOps",
      demonstrated_level: 2,
      required_level: 4,
      gap: 2,
      status: "DEVELOPING",
      evidence_count: 1,
      importance_weight: 0.9,
      reason: "Familiar with circuit breakers in theory, but lacks documented chaos testing evidence.",
      recommended_action: "Complete Simulator: 'Live Incident Commander - Payment Gateway Outage'."
    },
    {
      skill_id: "skl-06",
      skill_name: "Threat Modeling & SecOps",
      category: "Security",
      demonstrated_level: 1,
      required_level: 3,
      gap: 2,
      status: "INSUFFICIENT_EVIDENCE",
      evidence_count: 0,
      importance_weight: 0.9,
      reason: "No formal diagnostic or lab submissions logged for STRIDE threat modeling.",
      recommended_action: "Take the SecOps Diagnostic Assessment and submit Mission LAB-02."
    }
  ],
  radar_data: [
    { skill: "Backend Architecture", demonstrated: 88, required: 90, full_mark: 100 },
    { skill: "Frontend Architecture", demonstrated: 92, required: 85, full_mark: 100 },
    { skill: "Database Optimization", demonstrated: 55, required: 85, full_mark: 100 },
    { skill: "Distributed Reliability", demonstrated: 60, required: 85, full_mark: 100 },
    { skill: "SecOps & Auth", demonstrated: 40, required: 80, full_mark: 100 },
    { skill: "Incident Command", demonstrated: 75, required: 80, full_mark: 100 }
  ],
  comparison_bars: [
    { skill: "FastAPI Microservices", current: 88, target: 90, gap: 2 },
    { skill: "TypeScript Clean Code", current: 92, target: 85, gap: 0 },
    { skill: "Postgres Optimization", current: 55, target: 85, gap: 30 },
    { skill: "Distributed Systems", current: 60, target: 85, gap: 25 },
    { skill: "Threat Modeling", current: 40, target: 80, gap: 40 },
    { skill: "Incident Runbooks", current: 75, target: 80, gap: 5 }
  ],
  recommendations: [
    {
      skill_name: "PostgreSQL Optimization & Deadlocks",
      target_role: "Senior Full-Stack Engineer",
      gap: 30,
      priority: "HIGH",
      action: "Execute Mission LAB-01 to resolve deadlock triggers and inspect query plans."
    },
    {
      skill_name: "Threat Modeling & SecOps",
      target_role: "Senior Full-Stack Engineer",
      gap: 40,
      priority: "HIGH",
      action: "Complete the OWASP API Security Diagnostic and review the JWT Token Hardening Runbook."
    },
    {
      skill_name: "Distributed Systems Reliability",
      target_role: "Senior Full-Stack Engineer",
      gap: 25,
      priority: "MEDIUM",
      action: "Run through the Incident Commander Simulator under high error rates."
    }
  ]
};

export const MOCK_ROADMAP: RoadmapMilestone[] = [
  {
    id: "ms-01",
    target_role: "Senior Full-Stack Engineer",
    milestone_order: 1,
    title: "SQL Concurrency & Deadlock Remediation",
    description: "Analyze postgres lock graphs and refactor blocking queries into atomic idempotent batches.",
    target_skill_id: "skl-03",
    target_skill_name: "PostgreSQL Optimization & Deadlocks",
    target_level: 4,
    status: "IN_PROGRESS",
    action_type: "MISSION",
    action_id: "mis-01"
  },
  {
    id: "ms-02",
    target_role: "Senior Full-Stack Engineer",
    milestone_order: 2,
    title: "Live Incident Commander Simulation",
    description: "Successfully lead the mitigation of a catastrophic payment microservice outage within 15 minutes.",
    target_skill_id: "skl-01",
    target_skill_name: "Distributed Systems Reliability",
    target_level: 4,
    status: "PENDING",
    action_type: "SCENARIO",
    action_id: "scen-01"
  },
  {
    id: "ms-03",
    target_role: "Senior Full-Stack Engineer",
    milestone_order: 3,
    title: "Secure Token Auth & Rate Limiting Defense",
    description: "Implement RFC 6749 refresh rotation and IP token-bucket rate limiters in FastAPI.",
    target_skill_id: "skl-06",
    target_skill_name: "Threat Modeling & SecOps",
    target_level: 3,
    status: "PENDING",
    action_type: "MISSION",
    action_id: "mis-02"
  },
  {
    id: "ms-04",
    target_role: "Senior Full-Stack Engineer",
    milestone_order: 4,
    title: "Knowledge Continuity Runbook Authorship",
    description: "Document and cross-train a backup peer on critical Kubernetes Ingress TLS certificate rotators.",
    target_skill_id: "skl-02",
    target_skill_name: "Incident Response & Runbooks",
    target_level: 4,
    status: "COMPLETED",
    action_type: "KNOWLEDGE",
    completed_at: "2026-03-10T14:22:00Z"
  }
];

export const MOCK_ASSESSMENTS: Assessment[] = [
  {
    id: "ass-01",
    title: "Cloud Native Architecture & Reliability Diagnostic",
    description: "Comprehensive benchmark measuring readiness across distributed resilience, microservice fault tolerance, and data isolation.",
    category: "Architecture & DevOps",
    target_role: "Senior Full-Stack Engineer",
    difficulty: "INTERMEDIATE",
    time_limit_minutes: 20,
    passing_score: 75,
    question_count: 4,
    questions: [
      {
        id: "q-01",
        skill_id: "skl-01",
        skill_name: "Distributed Systems Reliability",
        question_text: "Under the Circuit Breaker pattern, what transitions a breaker from the OPEN state to the HALF-OPEN state?",
        question_type: "MULTIPLE_CHOICE",
        options: [
          "A manual administrator override via dashboard.",
          "An elapsed timeout duration allowing a limited trial batch of test traffic.",
          "Immediate receipt of an HTTP 200 OK from any downstream service.",
          "Automatic scaling of container replicas exceeding 80% CPU."
        ],
        points: 25,
        difficulty_level: 3
      },
      {
        id: "q-02",
        skill_id: "skl-03",
        skill_name: "PostgreSQL Optimization & Deadlocks",
        question_text: "Which SQL clause prevents read anomalies and ensures exclusive write locks on fetched rows until transaction commit?",
        question_type: "MULTIPLE_CHOICE",
        options: [
          "SELECT ... FOR UPDATE",
          "SELECT ... LOCK FREEZE",
          "SET TRANSACTION READ ONLY",
          "EXPLAIN ANALYZE BUFFER"
        ],
        points: 25,
        difficulty_level: 3
      },
      {
        id: "q-03",
        skill_id: "skl-06",
        skill_name: "Threat Modeling & SecOps",
        question_text: "Explain why storing sensitive JWT refresh tokens in browser localStorage presents a critical security vulnerability, and name the secure alternative.",
        question_type: "SHORT_ANSWER",
        points: 25,
        difficulty_level: 3
      },
      {
        id: "q-04",
        skill_id: "skl-04",
        skill_name: "FastAPI & Microservices Architecture",
        question_text: "In asynchronous FastAPI route handlers (`async def`), what happens if a blocking CPU-bound or synchronous I/O function like `time.sleep()` is invoked without `run_in_threadpool`?",
        question_type: "SHORT_ANSWER",
        points: 25,
        difficulty_level: 4
      }
    ]
  }
];

export const MOCK_MISSIONS: Mission[] = [
  {
    id: "mis-01",
    title: "Production Database Deadlock Triage",
    description: "Identify the root cause of cyclic lock deadlocks in an enterprise order processing pipeline and submit the optimized SQL query.",
    category: "Database Engineering",
    difficulty: "INTERMEDIATE",
    estimated_time_minutes: 35,
    required_skills: ["PostgreSQL Optimization & Deadlocks", "Distributed Systems Reliability"],
    scenario_context: "During Black Friday load peaks, the customer order table suffered 48 deadlocks per minute across `order_items` and `inventory_balances` due to out-of-order row acquisitions.",
    instructions: "1. Inspect the provided concurrent transaction trace.\n2. Identify which table locks were acquired in conflicting order.\n3. Write the refactored SQL statement using deterministic sorting or `FOR UPDATE NOWAIT`.\n4. Provide your triage justification and performance rationale.",
    sample_data: {
      trace_log: "ERROR: deadlock detected. Process 14022 waits for ExclusiveLock on tuple (48, 12) of relation 'inventory'; blocked by Process 14035.\nProcess 14035 waits for ShareLock on transaction 98411; blocked by Process 14022.",
      table_schema: "CREATE TABLE inventory (id UUID PRIMARY KEY, sku VARCHAR(50), available_qty INT, reserved_qty INT);"
    },
    submission_type: "SQL_AND_NARRATIVE",
    evaluation_rubric: [
      { criterion: "Root Cause Identification", max_points: 30, description: "Correctly identifies cyclic transaction ordering across inventory row locks." },
      { criterion: "Deterministic Query Solution", max_points: 40, description: "Applies ordered row sorting (e.g., ORDER BY sku FOR UPDATE) to eliminate circular dependencies." },
      { criterion: "Error Handling & Idempotency", max_points: 30, description: "Considers retries with exponential backoff and isolation level safeguards." }
    ],
    user_status: "PASSED",
    user_best_score: 92
  },
  {
    id: "mis-02",
    title: "FastAPI Rate Limiting & Auth Bypass Mitigation",
    description: "Harden a vulnerable FastAPI authentication endpoint against credential stuffing and brute-force token enumeration.",
    category: "Security",
    difficulty: "ADVANCED",
    estimated_time_minutes: 45,
    required_skills: ["FastAPI & Microservices Architecture", "Threat Modeling & SecOps"],
    scenario_context: "SecOps alerted that `/api/v1/auth/login` received 24,000 requests in 2 minutes from distributed IPs without triggering any rate limit or IP throttling.",
    instructions: "1. Review the unthrottled route definition.\n2. Implement a sliding window token-bucket rate limiter middleware using Redis or memory cache.\n3. Return RFC 7807 compliant HTTP 429 responses with `Retry-After` headers.\n4. Include timing-safe password hash verification.",
    submission_type: "PYTHON_CODE",
    evaluation_rubric: [
      { criterion: "Token Bucket Logic", max_points: 35, description: "Correct sliding window or leaky bucket implementation." },
      { criterion: "HTTP Standard Compliance", max_points: 35, description: "Returns status 429 with Retry-After header and detailed reason." },
      { criterion: "Constant Time Verification", max_points: 30, description: "Prevents timing attacks on credentials and token lookups." }
    ],
    user_status: "SUBMITTED",
    user_best_score: 85
  },
  {
    id: "mis-03",
    title: "Distributed Cache Invalidation & Race Condition Fix",
    description: "Eliminate cache stampede (thundering herd) and stale dirty-read race conditions on high-frequency product pricing APIs.",
    category: "Architecture & DevOps",
    difficulty: "ADVANCED",
    estimated_time_minutes: 40,
    required_skills: ["Distributed Systems Reliability", "FastAPI & Microservices Architecture"],
    scenario_context: "When cache keys expire on product prices, 1,200 concurrent requests hit the downstream database simultaneously, causing latency spikes from 8ms to 4,200ms.",
    instructions: "1. Implement a probabilistic early expiration algorithm (XFetch) or mutex lock (single-flight).\n2. Write code to ensure only one worker recomputes the cache while other requests receive stale-while-revalidate data.\n3. Document the performance benchmark.",
    submission_type: "CODE_AND_ANALYSIS",
    evaluation_rubric: [
      { criterion: "Single-Flight Mutex / XFetch", max_points: 40, description: "Accurate suppression of duplicate downstream cache regeneration." },
      { criterion: "Stale-While-Revalidate Strategy", max_points: 30, description: "Graceful delivery of slightly older data during synchronous recomputation." },
      { criterion: "Fallback Gracefulness", max_points: 30, description: "Handles Redis disconnection without dropping API availability." }
    ],
    user_status: "NEEDS_REVISION"
  }
];

export const MOCK_SUBMISSIONS: MissionSubmission[] = [
  {
    id: "sub-01",
    mission_id: "mis-01",
    user_id: "usr-alex-001",
    submission_content: `-- Remediated Query: Deterministic Sort Ordering to Prevent Deadlocks\nBEGIN;\n-- Acquire locks in strict alphabetical SKU order to guarantee monotonic locking graph\nSELECT id, sku, available_qty \nFROM inventory \nWHERE sku IN ('SKU-ALPHA', 'SKU-BETA', 'SKU-GAMMA') \nORDER BY sku ASC \nFOR UPDATE;\n\nUPDATE inventory \nSET available_qty = available_qty - 1 \nWHERE sku = 'SKU-ALPHA';\n\nCOMMIT;`,
    status: "PASSED",
    score: 92,
    feedback: "Exceptional submission. The deterministic sorting of row locks prior to updates completely breaks the Coffman circular wait condition.",
    rubric_breakdown: [
      { criterion: "Root Cause Identification", points_awarded: 28, max_points: 30, notes: "Accurately spotted the conflicting transaction order across concurrent worker processes." },
      { criterion: "Deterministic Query Solution", points_awarded: 38, max_points: 40, notes: "Applied ORDER BY sku ASC FOR UPDATE cleanly." },
      { criterion: "Error Handling & Idempotency", points_awarded: 26, max_points: 30, notes: "Good mention of connection backoffs." }
    ],
    test_results: [
      { test_name: "Monotonic Lock Order Assertion", passed: true, requirement: "Acquires row locks in invariant order", feedback: "PASSED" },
      { test_name: "Deadlock Cycle Reproduction", passed: true, requirement: "100 concurrent workers run without lock deadlock", feedback: "0 deadlocks observed" },
      { test_name: "Transaction Atomicity", passed: true, requirement: "All inventory items update atomically or rollback", feedback: "PASSED" }
    ],
    is_ai_generated: false,
    evaluation_engine: "DETERMINISTIC_ASSERTION_SUITE",
    submitted_at: "2026-03-12T10:30:00Z",
    evaluated_at: "2026-03-12T10:31:00Z"
  }
];

export const MOCK_FAILURE_REPORTS: FailureReport[] = [
  {
    id: "rep-01",
    user_id: "usr-alex-001",
    user_name: "Alex Rivera",
    skill_id: "skl-03",
    skill_name: "PostgreSQL Optimization & Deadlocks",
    topic: "Transaction Lock Ordering in High-Concurrency Loops",
    description: "I repeatedly encounter deadlock errors when multiple async celery tasks update batch records in random order. I struggle to debug which query holds the exclusive lock using pg_stat_activity.",
    error_snippet: "psycopg2.errors.DeadlockDetected: deadlock detected\nDETAIL: Process 2891 waits for ExclusiveLock on tuple (12, 4); blocked by Process 2893.",
    emotional_blocker: "Anxiety during production deployments because local sqlite tests never reproduce lock contention.",
    is_anonymous: false,
    created_at: "2026-03-08T09:15:00Z"
  },
  {
    id: "rep-02",
    user_id: "usr-alex-001",
    user_name: "Alex Rivera",
    skill_id: "skl-01",
    skill_name: "Distributed Systems Reliability",
    topic: "Configuring Circuit Breaker Thresholds in Resilient Services",
    description: "Unclear on mathematical formulas for setting failure rate thresholds before tripping breakers, resulting in flapping states during temporary packet drops.",
    is_anonymous: false,
    created_at: "2026-03-14T11:45:00Z"
  }
];

export const MOCK_FAILURE_PATTERNS: FailurePattern[] = [
  {
    id: "pat-01",
    skill_id: "skl-03",
    skill_name: "PostgreSQL Optimization & Deadlocks",
    topic: "Non-Deterministic Row Locking in Batch Processing",
    cluster_title: "Cyclic Lock Contention in Concurrent Bulk Operations",
    report_count: 7,
    confidence_score: 94,
    status: "ACTIVE_INTERVENTION",
    recommended_intervention_type: "PRACTICE_MICRO_MISSION",
    intervention_details: {
      title: "Targeted Micro-Drill: Deterministic Lock Sorter",
      description: "A focused 10-minute exercise providing a repeatable formula for sorting IDs before batch locking to guarantee 0 deadlocks.",
      practice_prompt: "Take an un-ordered list of UUIDs and write the Python SQLAlchemy query that wraps them in `sorted()` before issuing `with_for_update()`.",
      linked_mission_id: "mis-01",
      refresher_steps: [
        "Always enforce a deterministic sort key (e.g. ID or SKU) before acquiring multiple row locks.",
        "Use SELECT ... FOR UPDATE NOWAIT or SKIP LOCKED for queue consumer patterns.",
        "Keep lock acquisition transactions as short as humanly possible."
      ]
    },
    detected_at: "2026-03-09T18:00:00Z",
    active_interventions_count: 5
  },
  {
    id: "pat-02",
    skill_id: "skl-01",
    skill_name: "Distributed Systems Reliability",
    topic: "Circuit Breaker Flapping Under High Latency",
    cluster_title: "Premature Tripping Due to Insufficient Sample Window",
    report_count: 5,
    confidence_score: 89,
    status: "ACTIVE_INTERVENTION",
    recommended_intervention_type: "INTERACTIVE_SIMULATION",
    intervention_details: {
      title: "Interactive Sandbox: Sliding Window Sizing",
      description: "Visual simulator tuning minimum sample size (ring buffer) versus failure percentage threshold.",
      practice_prompt: "Configure the resilient decorator with a 100-request sliding window and a 40% error rate threshold.",
      refresher_steps: [
        "Never trip a breaker on fewer than 20 recorded requests.",
        "Distinguish between client 4xx errors and upstream 5xx faults."
      ]
    },
    detected_at: "2026-03-11T12:00:00Z",
    active_interventions_count: 3
  }
];

export const MOCK_INTERVENTIONS: InterventionTracking[] = [
  {
    id: "int-01",
    failure_pattern_id: "pat-01",
    failure_pattern_title: "Cyclic Lock Contention in Concurrent Bulk Operations",
    user_id: "usr-alex-001",
    status: "COMPLETED",
    pre_intervention_score: 55,
    post_intervention_score: 92,
    score_delta: 37,
    evidence_demonstrated: true,
    learner_feedback: "The deterministic sort pattern clicked immediately once I visualized the circular wait graph. My mission score increased by 37 points!",
    intervention_details: {
      drill_name: "Deterministic Lock Sorter",
      time_spent_minutes: 14
    },
    completed_at: "2026-03-12T10:35:00Z"
  }
];

export const MOCK_SCENARIOS: Scenario[] = [
  {
    id: "scen-01",
    title: "Live Incident Commander: Critical Payment Gateway Outage",
    description: "Assume the role of Incident Commander during peak checkout traffic when Stripe webhooks fail and payment latency surges 800%.",
    category: "Operations & Incident Command",
    difficulty: "ADVANCED",
    estimated_minutes: 25,
    learning_objectives: [
      "Establish rapid incident communication protocols without panicking stakeholders.",
      "Execute safe traffic shifting and asynchronous fallback queues.",
      "Diagnose cascading connection pool exhaustion under high concurrency."
    ],
    context_background: "It is Friday 18:00 UTC. The platform is processing $120,000/min in checkout volume. Alert P1-CRITICAL triggers: 'Payment Service HTTP 504 Timeout rate > 32%'. You are paged as Incident Commander.",
    initial_step_key: "step_01",
    user_attempts_count: 1,
    user_best_score: 88,
    steps: [
      {
        step_key: "step_01",
        prompt: "You join the emergency bridge. The Support Director is frantic, executives are asking for updates in #all-hands, and engineers are debating whether to restart all payment pods. What is your immediate first action?",
        situation_update: "SLA Error Rate: 34% | Checkout Latency: 4,100ms | Downstream DB Connections: 98% Full",
        choices: [
          {
            id: "c-01-a",
            choice_text: "Immediately reboot the entire payment microservice cluster simultaneously.",
            consequences_narrative: "Rebooting the cluster caused a massive cold-start cache stampede. All 1,400 incoming transactions hit PostgreSQL at once, taking down the entire database cluster. Outage escalated to SEV-0.",
            metrics_delta: { uptime: -40, trust: -30, sla: -35, budget: -15000 },
            next_step_key: "step_dead_end",
            score_points: 10,
            rationale: "Never mass-restart stateful or DB-connected services during peak load without traffic sheds."
          },
          {
            id: "c-01-b",
            choice_text: "Assume formal Incident Commander command: designate a Communications Lead to brief executives, freeze non-essential Slack chatter, and inspect telemetry dashboards.",
            consequences_narrative: "Command structure established in 90 seconds. Stakeholders received a structured status page update, while engineering focused on isolation without distractions.",
            metrics_delta: { uptime: 0, trust: +20, sla: -5, budget: 0 },
            next_step_key: "step_02",
            score_points: 40,
            rationale: "Standard ICS protocol: establish command, assign comms, prevent panic."
          },
          {
            id: "c-01-c",
            choice_text: "Directly open production database consoles and start terminating active backend queries.",
            consequences_narrative: "Terminated critical settlement transactions halfway through, leaving payment states out of sync and causing $35,000 in unverified chargebacks.",
            metrics_delta: { uptime: -15, trust: -20, sla: -20, budget: -35000 },
            next_step_key: "step_02",
            score_points: 20,
            rationale: "Blindly killing queries without knowing dependencies corrupts two-phase commits."
          }
        ]
      },
      {
        step_key: "step_02",
        prompt: "Telemetry indicates the primary payment gateway API is experiencing degraded third-party latency (6,500ms response time), holding open your backend HTTP connection pools. How do you mitigate the bottleneck?",
        situation_update: "SLA Error Rate: 41% | Customer Cart Abandonment: 28% | Secondary Gateway: Healthy (0.1% errors)",
        choices: [
          {
            id: "c-02-a",
            choice_text: "Flip the feature flag to divert 100% of checkout traffic to the secondary failover gateway and engage Circuit Breaker fallback on the primary provider.",
            consequences_narrative: "Traffic routed successfully. Checkout latency dropped from 4,100ms to 240ms within 45 seconds. Error rate plummeted to 0.4%. Cart completions restored.",
            metrics_delta: { uptime: +35, trust: +30, sla: +30, budget: -2000 },
            next_step_key: "step_03",
            score_points: 50,
            rationale: "Multi-provider resilience with automatic failover avoids reliance on a single vendor."
          },
          {
            id: "c-02-b",
            choice_text: "Increase HTTP client timeout from 5 seconds to 30 seconds to allow slow transactions to complete.",
            consequences_narrative: "Increasing timeouts worsened the connection pool starvation. Every worker thread became trapped waiting 30 seconds, bringing the entire checkout application to a complete freeze.",
            metrics_delta: { uptime: -30, trust: -25, sla: -30, budget: -10000 },
            next_step_key: "step_dead_end",
            score_points: 15,
            rationale: "Increasing timeouts during upstream latency spikes guarantees catastrophic thread pool exhaustion."
          }
        ]
      },
      {
        step_key: "step_03",
        prompt: "The incident is stabilized. Traffic is flowing through the secondary gateway. What is your concluding protocol as Incident Commander?",
        situation_update: "SLA Restored: 99.8% | All Queues Drained | Zero Transaction Loss",
        choices: [
          {
            id: "c-03-a",
            choice_text: "Declare incident resolved, publish the final stakeholder debrief, and schedule a blameless post-mortem within 48 hours to update runbooks.",
            consequences_narrative: "Post-mortem executed flawlessly. Identified root cause in gateway webhook retries. Team morale preserved with blameless culture.",
            metrics_delta: { uptime: +15, trust: +25, sla: +15, budget: 0 },
            next_step_key: null,
            score_points: 50,
            rationale: "Exemplary incident closure: transparency, documentation, and continuous organizational learning."
          }
        ]
      },
      {
        step_key: "step_dead_end",
        prompt: "The outage escalated significantly due to that decision. The engineering VP stepped in to take over the bridge. Review your performance rating below.",
        situation_update: "Post-Mortem Review Required",
        choices: [
          {
            id: "c-retry",
            choice_text: "Review the ICS runbook and retry the simulation with updated strategies.",
            consequences_narrative: "Restarting simulation with fresh telemetry state.",
            metrics_delta: { uptime: 0, trust: 0, sla: 0, budget: 0 },
            next_step_key: "step_01",
            score_points: 0,
            rationale: "Learn from consequence-driven feedback."
          }
        ]
      }
    ]
  }
];

export const MOCK_SCENARIO_ATTEMPTS: ScenarioAttempt[] = [
  {
    id: "att-01",
    scenario_id: "scen-01",
    scenario_title: "Live Incident Commander: Critical Payment Gateway Outage",
    total_score: 88,
    performance_rating: "DISTINGUISHED_COMMANDER",
    debrief_notes: "Superb decision-making. Quickly isolated panicking communication and shifted gateway traffic without thread exhaustion.",
    metrics_summary: {
      uptime_score: 95,
      team_trust: 90,
      sla_preservation: 88,
      financial_impact_prevented: "$240,000"
    },
    steps_history: [
      { step: "step_01", choice: "c-01-b", points: 40 },
      { step: "step_02", choice: "c-02-a", points: 50 },
      { step: "step_03", choice: "c-03-a", points: 50 }
    ],
    is_ai_generated: false,
    completed_at: "2026-03-10T16:45:00Z"
  }
];

export const MOCK_KNOWLEDGE_ARTICLES: KnowledgeArticle[] = [
  {
    id: "kb-01",
    organization_id: "org-acme-001",
    title: "Kubernetes Cluster Ingress TLS Key Rotation Runbook",
    category: "Infrastructure & Security",
    summary: "Mandatory zero-downtime rotation protocol for wildcard SSL/TLS certificates and Let's Encrypt ACME renewal failures.",
    content: "# TLS Certificate Renewal Runbook\n\n## 1. Overview\nOur external API gateways (`api.acmeglobal.com`) terminate TLS at the Envoy Ingress. Certificates auto-renew via cert-manager, but manual intervention is required if OCSP stapling or DNS01 challenges stall.\n\n## 2. Emergency Rotation Steps\n1. Verify current cert expiration:\n   `kubectl get certificate -n ingress-nginx`\n2. Trigger forced renewal:\n   `cmctl renew api-wildcard-cert -n ingress-nginx`\n3. If ACME challenge fails, import offline emergency wildcard cert stored in Vault secret `secret/pki/wildcard-backup-2026`.\n4. Gracefully restart Envoy pods with 0 dropped sockets:\n   `kubectl rollout restart deployment/envoy-gateway -n ingress-nginx`",
    owner_id: "usr-marcus-002",
    owner_name: "Marcus Brody",
    backup_owner_id: "usr-alex-001",
    backup_owner_name: "Alex Rivera",
    primary_skill_id: "skl-01",
    primary_skill_name: "Distributed Systems Reliability",
    related_skills: ["Threat Modeling & SecOps", "CI/CD & Kubernetes Pipeline"],
    review_cadence_days: 90,
    last_reviewed_at: "2026-02-01T00:00:00Z",
    next_review_at: "2026-05-01T00:00:00Z",
    spof_risk_level: "LOW",
    is_verified_procedure: true,
    status: "ACTIVE",
    views_count: 312,
    created_at: "2026-01-10T00:00:00Z"
  },
  {
    id: "kb-02",
    organization_id: "org-acme-001",
    title: "Core Payment Ledger Daily Reconciliation & Idempotency Audit",
    category: "Finance & Data Engineering",
    summary: "CRITICAL SPOF: Explains how asynchronous stripe clearing accounts are balanced against the double-entry PostgreSQL ledger.",
    content: "# Core Payment Ledger Settlement Runbook\n\n## 1. Context & Risk\nOnly 1 engineer currently understands the double-entry accounting reconciliation SQL pipeline. If this job fails, merchant settlements freeze.",
    owner_id: "usr-marcus-002",
    owner_name: "Marcus Brody",
    backup_owner_id: undefined,
    backup_owner_name: undefined,
    primary_skill_id: "skl-03",
    primary_skill_name: "PostgreSQL Optimization & Deadlocks",
    related_skills: ["Distributed Systems Reliability"],
    review_cadence_days: 30,
    last_reviewed_at: "2025-11-15T00:00:00Z",
    next_review_at: "2025-12-15T00:00:00Z",
    spof_risk_level: "CRITICAL",
    is_verified_procedure: false,
    status: "ACTIVE",
    views_count: 88,
    created_at: "2025-08-20T00:00:00Z"
  },
  {
    id: "kb-03",
    organization_id: "org-acme-001",
    title: "PostgreSQL High-Availability Failover & WAL Archiving",
    category: "Database Engineering",
    summary: "Step-by-step failover execution from Primary to Read-Replica using Patroni consensus during node hardware degradation.",
    content: "# Patroni HA Failover Runbook\n\nExecute switchover via `patronictl -c /etc/patroni/pg.yml switchover` after confirming replication lag < 100kb.",
    owner_id: "usr-marcus-002",
    owner_name: "Marcus Brody",
    backup_owner_id: "usr-alex-001",
    backup_owner_name: "Alex Rivera",
    primary_skill_id: "skl-03",
    primary_skill_name: "PostgreSQL Optimization & Deadlocks",
    review_cadence_days: 60,
    last_reviewed_at: "2026-02-15T00:00:00Z",
    next_review_at: "2026-04-15T00:00:00Z",
    spof_risk_level: "MEDIUM",
    is_verified_procedure: true,
    status: "ACTIVE",
    views_count: 145,
    created_at: "2026-01-05T00:00:00Z"
  }
];

export const MOCK_KNOWLEDGE_ANALYTICS: KnowledgeRadarAnalytics = {
  total_articles: 18,
  overall_coverage_health_pct: 84,
  critical_spof_count: 1,
  high_spof_count: 2,
  medium_spof_count: 4,
  low_spof_count: 11,
  outdated_review_count: 2,
  active_cross_trainings_count: 3,
  spof_alerts: [
    {
      article_id: "kb-02",
      title: "Core Payment Ledger Daily Reconciliation & Idempotency Audit",
      category: "Finance & Data Engineering",
      risk_level: "CRITICAL",
      primary_owner: "Marcus Brody",
      backup_owner: "None Assigned (Single Point of Failure)",
      recommended_action: "Assign Alex Rivera as Backup Owner and schedule shadowing sessions."
    },
    {
      article_id: "kb-03",
      title: "PostgreSQL High-Availability Failover & WAL Archiving",
      category: "Database Engineering",
      risk_level: "MEDIUM",
      primary_owner: "Marcus Brody",
      backup_owner: "Alex Rivera",
      recommended_action: "Conduct simulated dry-run drill to complete formal verification."
    }
  ],
  category_distribution: [
    { category: "Infrastructure & Security", count: 6 },
    { category: "Database Engineering", count: 4 },
    { category: "Finance & Data Engineering", count: 3 },
    { category: "Backend Architecture", count: 5 }
  ],
  recommendations: [
    { priority: "CRITICAL", title: "Eliminate Payment Ledger SPOF", description: "Designate a co-owner for the settlement ledger runbook immediately." },
    { priority: "HIGH", title: "Automate Recertification Drills", description: "2 runbooks have passed their review cadence date and need recertification." }
  ]
};

export const MOCK_CROSS_TRAINING: CrossTrainingAssignment[] = [
  {
    id: "ct-01",
    organization_id: "org-acme-001",
    knowledge_article_id: "kb-01",
    knowledge_article_title: "Kubernetes Cluster Ingress TLS Key Rotation Runbook",
    primary_expert_id: "usr-marcus-002",
    primary_expert_name: "Marcus Brody",
    backup_learner_id: "usr-alex-001",
    backup_learner_name: "Alex Rivera",
    target_completion_date: "2026-03-30T00:00:00Z",
    status: "VERIFIED",
    verification_notes: "Alex successfully performed a simulated cert renewal drill on the staging cluster with 0 downtime.",
    verified_at: "2026-03-10T14:22:00Z",
    created_at: "2026-02-10T00:00:00Z"
  },
  {
    id: "ct-02",
    organization_id: "org-acme-001",
    knowledge_article_id: "kb-02",
    knowledge_article_title: "Core Payment Ledger Daily Reconciliation & Idempotency Audit",
    primary_expert_id: "usr-marcus-002",
    primary_expert_name: "Marcus Brody",
    backup_learner_id: "usr-alex-001",
    backup_learner_name: "Alex Rivera",
    target_completion_date: "2026-04-15T00:00:00Z",
    status: "IN_PROGRESS",
    created_at: "2026-03-12T00:00:00Z"
  }
];

export const MOCK_PASSPORT_EVIDENCE: PassportEvidence[] = [
  {
    id: "ev-01",
    passport_id: "pass-alex-001",
    skill_id: "skl-03",
    skill_name: "PostgreSQL Optimization & Deadlocks",
    skill_category: "Database Engineering",
    evidence_type: "PROJECT_DEMONSTRATED",
    title: "Mission LAB-01: Production Database Deadlock Triage",
    description: "Evaluated by deterministic test suite. Implemented monotonic lock acquisition ordering that stopped deadlock cycles in high-throughput concurrent transactions.",
    rubric_score: 92,
    artifact_ref: "SHA256:4a8b79e190f845d0b98762aefcd784e9",
    verification_status: "VERIFIED",
    verified_at: "2026-03-12T10:31:00Z",
    tags: ["PostgreSQL", "Concurrency", "Locking", "Deterministic Tests"],
    created_at: "2026-03-12T10:31:00Z"
  },
  {
    id: "ev-02",
    passport_id: "pass-alex-001",
    skill_id: "skl-01",
    skill_name: "Distributed Systems Reliability",
    skill_category: "Architecture & DevOps",
    evidence_type: "PLATFORM_ASSESSED",
    title: "Scenario SIM-01: Live Incident Commander - Payment Gateway Outage",
    description: "Successfully commanded a SEV-1 payment outage with zero data loss. Switched gateway traffic under 45s and kept SLA at 99.8%.",
    rubric_score: 88,
    artifact_ref: "SHA256:7b91e0a23c4d5f6a8b7c9e0f1a2b3c4d",
    verification_status: "VERIFIED",
    verified_at: "2026-03-10T16:45:00Z",
    tags: ["Incident Command", "Circuit Breakers", "Failover", "ICS Protocols"],
    created_at: "2026-03-10T16:45:00Z"
  },
  {
    id: "ev-03",
    passport_id: "pass-alex-001",
    skill_id: "skl-02",
    skill_name: "Incident Response & Runbooks",
    skill_category: "Operations",
    evidence_type: "EXTERNALLY_VERIFIED",
    title: "Organizational Runbook Cross-Training: TLS Ingress Key Rotation",
    description: "Demonstrated certified backup ownership for mission-critical infrastructure runbook kb-01. Verified by Engineering Director Marcus Brody.",
    rubric_score: 95,
    artifact_ref: "SIGNATURE:ed25519-brody-marcus-dir-2026",
    verification_status: "VERIFIED",
    verified_at: "2026-03-10T14:22:00Z",
    tags: ["Runbook SOP", "SPOF Mitigation", "Kubernetes Ingress"],
    created_at: "2026-03-10T14:22:00Z"
  }
];

export const MOCK_PASSPORT: SkillPassport = {
  id: "pass-alex-001",
  user_id: "usr-alex-001",
  user_name: "Alex Rivera",
  user_email: "alex@acme.com",
  organization_name: "Acme Global Technologies",
  department: "Product Engineering",
  job_title: "Software Associate",
  target_role: "Senior Full-Stack Engineer",
  share_token: "alex-passport-public-token-2026",
  is_public: true,
  headline: "Aspiring Senior Full-Stack Engineer • Specializing in High-Availability Backends & Resilient Distributed Systems",
  summary_bio: "Software associate with verified, practical competencies in PostgreSQL concurrency triage, async FastAPI microservices, and live incident commander protocols. Demonstrating 78% role-readiness backed by cryptographically verifiable mission artifacts.",
  verified_badge: true,
  verification_authority: "SkillBridge AI Enterprise Attestation Engine",
  created_at: "2026-01-15T00:00:00Z",
  updated_at: "2026-03-12T10:35:00Z",
  evidence_items: MOCK_PASSPORT_EVIDENCE,
  assessed_skills_count: 6,
  projects_verified_count: 3,
  readiness_score: 78
};

export const MOCK_CORPORATE_OVERVIEW = {
  organization_name: "Acme Global Technologies",
  total_employees: 142,
  active_learners: 128,
  average_readiness_pct: 76.4,
  critical_spof_count: 1,
  missions_completed_this_month: 84,
  skill_health_distribution: [
    { department: "Product Engineering", readiness: 81, count: 52 },
    { department: "Platform & Infrastructure", readiness: 88, count: 34 },
    { department: "Data Analytics", readiness: 72, count: 26 },
    { department: "Cybersecurity & IT", readiness: 65, count: 16 }
  ],
  top_risk_skills: [
    { skill: "Threat Modeling & SecOps", gap_severity: "High", affected_learners: 28 },
    { skill: "PostgreSQL Optimization & Deadlocks", gap_severity: "High", affected_learners: 19 },
    { skill: "Distributed Systems Reliability", gap_severity: "Medium", affected_learners: 14 }
  ]
};

export const MOCK_CORPORATE_AUDIT_LOGS = [
  { id: "log-01", timestamp: "2026-03-12T10:35:00Z", actor: "Alex Rivera", action: "INTERVENTION_COMPLETED", details: "Completed failure prevention micro-drill for Cyclic Lock Contention." },
  { id: "log-02", timestamp: "2026-03-12T10:31:00Z", actor: "Automated Evaluation Engine", action: "MISSION_EVALUATED", details: "Mission LAB-01 evaluated: 92/100 points awarded to Alex Rivera." },
  { id: "log-03", timestamp: "2026-03-10T16:45:00Z", actor: "Alex Rivera", action: "SCENARIO_COMPLETED", details: "Completed Incident Commander simulation with Distinguished rating." },
  { id: "log-04", timestamp: "2026-03-10T14:22:00Z", actor: "Marcus Brody", action: "CROSS_TRAINING_VERIFIED", details: "Verified Alex Rivera on TLS Ingress Key Rotation Runbook." }
];
