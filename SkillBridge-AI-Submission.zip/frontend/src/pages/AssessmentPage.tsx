import React, { useEffect, useState } from "react";
import {
  CheckSquare,
  Clock,
  CheckCircle2,
  XCircle,
  HelpCircle,
  ArrowRight,
  Sparkles,
  ChevronRight,
  RotateCcw,
  Target
} from "lucide-react";
import confetti from "canvas-confetti";
import { api } from "../lib/api";
import { Assessment, AssessmentAttempt } from "../lib/types";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "../components/common/Card";
import { Button } from "../components/common/Button";
import { Badge } from "../components/common/Badge";

export const AssessmentPage: React.FC = () => {
  const [assessments, setAssessments] = useState<Assessment[]>([]);
  const [activeAssessment, setActiveAssessment] = useState<Assessment | null>(null);
  const [answers, setAnswers] = useState<Record<string, string>>({});
  const [attemptResult, setAttemptResult] = useState<AssessmentAttempt | null>(null);
  const [submitting, setSubmitting] = useState(false);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchAssessments = async () => {
      try {
        const list = await api.getAssessments();
        setAssessments(list);
        if (list.length > 0) {
          // Fetch full assessment with questions
          const full = await api.getAssessment(list[0].id);
          setActiveAssessment(full);
        }
      } catch (err) {
        console.error("Failed to load assessments:", err);
      } finally {
        setLoading(false);
      }
    };
    fetchAssessments();
  }, []);

  const handleSelectAssessment = async (id: string) => {
    setLoading(true);
    setAttemptResult(null);
    setAnswers({});
    try {
      const full = await api.getAssessment(id);
      setActiveAssessment(full);
    } catch (err) {
      console.error("Error loading assessment:", err);
    } finally {
      setLoading(false);
    }
  };

  const handleSelectOption = (questionId: string, option: string) => {
    setAnswers((prev) => ({ ...prev, [questionId]: option }));
  };

  const handleSubmit = async () => {
    if (!activeAssessment) return;
    setSubmitting(true);
    try {
      const res = await api.submitAssessment(activeAssessment.id, answers);
      setAttemptResult(res);
      if (res.passed) {
        confetti({
          particleCount: 80,
          spread: 70,
          origin: { y: 0.6 },
        });
      }
    } catch (err) {
      console.error("Submission failed:", err);
    } finally {
      setSubmitting(false);
    }
  };

  const handleRetake = () => {
    setAttemptResult(null);
    setAnswers({});
  };

  return (
    <div className="space-y-6">
      {/* Page Title */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-200 dark:border-slate-800">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-2xl font-bold tracking-tight text-slate-900 dark:text-white">
              Diagnostic Assessment Labs
            </h1>
            <Badge variant="teal">Diagnostic</Badge>
          </div>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
            Objective evaluations testing core competencies, edge-case discernment, and system architecture.
          </p>
        </div>
      </div>

      {loading ? (
        <div className="h-64 flex items-center justify-center text-xs text-slate-400">
          Loading diagnostic assessment questions...
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Assessment Picker Sidebar */}
          <div className="lg:col-span-4 space-y-3">
            <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider block">
              Available Diagnostics
            </span>
            {assessments.map((a) => (
              <div
                key={a.id}
                onClick={() => handleSelectAssessment(a.id)}
                className={`p-3.5 rounded-xl border cursor-pointer transition-all ${
                  activeAssessment?.id === a.id
                    ? "border-brand-500 bg-brand-500/10 dark:bg-brand-950/40 text-slate-900 dark:text-white shadow-sm"
                    : "border-slate-200 dark:border-slate-800 bg-white dark:bg-navy-900 text-slate-700 dark:text-slate-300 hover:border-slate-300 dark:hover:border-slate-700"
                }`}
              >
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold truncate">{a.title}</span>
                  <Badge variant="brand">{a.difficulty}</Badge>
                </div>
                <div className="flex items-center gap-3 text-[11px] text-slate-400 mt-2">
                  <span className="flex items-center gap-1">
                    <Clock className="h-3 w-3" /> {a.time_limit_minutes}m
                  </span>
                  <span>•</span>
                  <span>Pass: {a.passing_score}%</span>
                  <span>•</span>
                  <span>{a.question_count} Questions</span>
                </div>
              </div>
            ))}
          </div>

          {/* Active Assessment Interactive Runner */}
          <div className="lg:col-span-8">
            {activeAssessment && (
              <Card>
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <div>
                      <CardTitle>{activeAssessment.title}</CardTitle>
                      <CardDescription>{activeAssessment.description}</CardDescription>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-semibold text-teal-500 flex items-center gap-1">
                        <Clock className="h-3.5 w-3.5" /> {activeAssessment.time_limit_minutes} Mins
                      </span>
                    </div>
                  </div>
                </CardHeader>

                <CardContent className="space-y-6">
                  {/* If results already submitted */}
                  {attemptResult ? (
                    <div className="space-y-6">
                      {/* Score Result Card */}
                      <div
                        className={`p-5 rounded-xl border flex flex-col sm:flex-row items-center justify-between gap-4 ${
                          attemptResult.passed
                            ? "bg-emerald-500/10 border-emerald-500/30 text-emerald-950 dark:text-emerald-200"
                            : "bg-amber-500/10 border-amber-500/30 text-amber-950 dark:text-amber-200"
                        }`}
                      >
                        <div className="space-y-1 text-center sm:text-left">
                          <span className="text-xs font-semibold uppercase tracking-wider block">
                            Diagnostic Assessment Completed
                          </span>
                          <div className="text-2xl font-extrabold flex items-center gap-2 justify-center sm:justify-start">
                            <span>Score: {attemptResult.score}%</span>
                            <Badge variant={attemptResult.passed ? "success" : "warning"}>
                              {attemptResult.passed ? "Benchmark Passed" : "Needs Review"}
                            </Badge>
                          </div>
                          <p className="text-xs max-w-lg mt-1">{attemptResult.feedback_notes}</p>
                        </div>

                        <Button variant="secondary" size="sm" onClick={handleRetake} className="text-xs gap-1.5 shrink-0">
                          <RotateCcw className="h-3.5 w-3.5" />
                          <span>Retake Assessment</span>
                        </Button>
                      </div>

                      {/* Updated skills */}
                      {attemptResult.skill_updates && attemptResult.skill_updates.length > 0 && (
                        <div className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-900/60 space-y-2">
                          <span className="text-xs font-bold text-slate-800 dark:text-slate-200 block">
                            Skill Scores Updated in Skill Passport:
                          </span>
                          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                            {attemptResult.skill_updates.map((su: any, i: number) => (
                              <div key={i} className="p-2 bg-white dark:bg-navy-950 rounded-lg text-xs flex justify-between items-center">
                                <span className="font-medium text-slate-700 dark:text-slate-300">{su.skill_name}</span>
                                <Badge variant="brand">{su.new_level}/5.0 • {su.status}</Badge>
                              </div>
                            ))}
                          </div>
                        </div>
                      )}

                      {/* Question review with explanations */}
                      <div className="space-y-4">
                        <span className="text-xs font-bold uppercase tracking-wider text-slate-400 block">
                          Question Review & Explanations
                        </span>
                        {attemptResult.evaluation_detail?.questions?.map((q: any, idx: number) => (
                          <div
                            key={q.question_id}
                            className={`p-4 rounded-xl border space-y-2 ${
                              q.is_correct
                                ? "border-emerald-500/30 bg-emerald-500/5"
                                : "border-rose-500/30 bg-rose-500/5"
                            }`}
                          >
                            <div className="flex items-start justify-between gap-2">
                              <span className="text-xs font-semibold text-slate-900 dark:text-white">
                                {idx + 1}. {q.question_text}
                              </span>
                              {q.is_correct ? (
                                <Badge variant="success">+{q.points_awarded} pts</Badge>
                              ) : (
                                <Badge variant="danger">0 / {q.max_points} pts</Badge>
                              )}
                            </div>

                            <div className="text-xs space-y-1">
                              <div>
                                <span className="text-slate-400">Your Answer: </span>
                                <span className={q.is_correct ? "text-emerald-500 font-medium" : "text-rose-500 font-medium"}>
                                  {q.user_answer || "No answer submitted"}
                                </span>
                              </div>
                              {!q.is_correct && (
                                <div>
                                  <span className="text-slate-400">Correct Answer: </span>
                                  <span className="text-emerald-500 font-medium">{q.correct_answer}</span>
                                </div>
                              )}
                            </div>

                            <div className="p-2.5 rounded-lg bg-white/60 dark:bg-navy-950/60 border border-slate-200 dark:border-slate-800 text-[11px] text-slate-600 dark:text-slate-300 leading-relaxed">
                              <span className="font-semibold block text-brand-500">Explanation:</span>
                              {q.explanation}
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  ) : (
                    /* Live Questions Form */
                    <div className="space-y-6">
                      {activeAssessment.questions?.map((q, idx) => (
                        <div
                          key={q.id}
                          className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-900/40 space-y-3"
                        >
                          <div className="flex items-start justify-between gap-3">
                            <span className="text-xs font-bold text-slate-900 dark:text-white leading-relaxed">
                              {idx + 1}. {q.question_text}
                            </span>
                            <Badge variant="outline">{q.points} pts</Badge>
                          </div>

                          {/* Options */}
                          <div className="space-y-2 pt-1">
                            {q.options?.map((opt, optIdx) => {
                              const isSelected = answers[q.id] === opt;
                              return (
                                <label
                                  key={optIdx}
                                  onClick={() => handleSelectOption(q.id, opt)}
                                  className={`flex items-center gap-3 p-2.5 rounded-lg border text-xs cursor-pointer transition-colors ${
                                    isSelected
                                      ? "border-brand-500 bg-brand-50 dark:bg-brand-950/40 text-brand-900 dark:text-brand-200 font-medium"
                                      : "border-slate-200 dark:border-slate-800 hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-700 dark:text-slate-300"
                                  }`}
                                >
                                  <input
                                    type="radio"
                                    name={`q_${q.id}`}
                                    checked={isSelected}
                                    onChange={() => handleSelectOption(q.id, opt)}
                                    className="text-brand-600 focus:ring-brand-500"
                                  />
                                  <span>{opt}</span>
                                </label>
                              );
                            })}
                          </div>
                        </div>
                      ))}

                      {/* Submit Bar */}
                      <div className="pt-4 border-t border-slate-200 dark:border-slate-800 flex items-center justify-between">
                        <span className="text-xs text-slate-400">
                          {Object.keys(answers).length} of {activeAssessment.questions?.length} answered
                        </span>

                        <Button
                          variant="primary"
                          size="md"
                          onClick={handleSubmit}
                          isLoading={submitting}
                          disabled={Object.keys(answers).length === 0}
                          className="text-xs"
                        >
                          <span>Submit Diagnostic Assessment</span>
                          <ArrowRight className="h-4 w-4 ml-1.5" />
                        </Button>
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
