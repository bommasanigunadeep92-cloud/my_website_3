import React, { useEffect, useState } from "react";
import { useParams, Link } from "react-router-dom";
import {
  PlayCircle,
  Clock,
  ArrowLeft,
  RotateCcw,
  CheckCircle2,
  AlertTriangle,
  ShieldCheck,
  TrendingUp,
  Activity,
  HeartHandshake
} from "lucide-react";
import confetti from "canvas-confetti";
import { api } from "../lib/api";
import { Scenario, ScenarioStep, ScenarioChoice, ScenarioAttempt } from "../lib/types";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "../components/common/Card";
import { Button } from "../components/common/Button";
import { Badge } from "../components/common/Badge";

export const ScenarioPlayerPage: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const [scenario, setScenario] = useState<Scenario | null>(null);
  const [currentStep, setCurrentStep] = useState<ScenarioStep | null>(null);
  const [metrics, setMetrics] = useState<Record<string, number>>({
    trust: 60,
    risk: 30,
    speed: 50,
  });
  const [history, setHistory] = useState<any[]>([]);
  const [isFinished, setIsFinished] = useState(false);
  const [finalAttempt, setFinalAttempt] = useState<ScenarioAttempt | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchScenario = async () => {
      if (!id) return;
      try {
        const sc = await api.getScenario(id);
        setScenario(sc);
        if (sc.steps && sc.steps.length > 0) {
          const initStep = sc.steps.find((s) => s.step_key === sc.initial_step_key) || sc.steps[0];
          setCurrentStep(initStep);
        }
      } catch (err) {
        console.error("Failed to load scenario simulation:", err);
      } finally {
        setLoading(false);
      }
    };
    fetchScenario();
  }, [id]);

  const handleMakeChoice = async (choice: ScenarioChoice) => {
    if (!scenario || !currentStep) return;

    // Apply metrics delta
    const newMetrics = { ...metrics };
    Object.entries(choice.metrics_delta || {}).forEach(([k, delta]) => {
      newMetrics[k] = Math.max(0, Math.min(100, (newMetrics[k] || 50) + delta));
    });
    setMetrics(newMetrics);

    const stepRecord = {
      step_key: currentStep.step_key,
      choice_id: choice.id,
      choice_text: choice.choice_text,
      consequence: choice.consequences_narrative,
      score_points: choice.score_points,
      rationale: choice.rationale,
      resulting_metrics: newMetrics,
    };
    const updatedHistory = [...history, stepRecord];
    setHistory(updatedHistory);

    // Check if branching to next step or finalizing
    if (choice.next_step_key && scenario.steps) {
      const next = scenario.steps.find((s) => s.step_key === choice.next_step_key);
      if (next) {
        setCurrentStep(next);
        return;
      }
    }

    // Finished simulation: finalize attempt
    setIsFinished(true);
    const totalPoints = updatedHistory.reduce((acc, h) => acc + (h.score_points || 20), 0);
    const scorePct = Math.min(100, Math.round((totalPoints / (updatedHistory.length * 35)) * 100));

    try {
      const attemptRes = await api.submitScenarioAttempt(scenario.id, {
        steps_history: updatedHistory,
        final_metrics: newMetrics,
        total_score: Math.max(40, scorePct),
      });
      setFinalAttempt(attemptRes);

      if (attemptRes.total_score >= 70.0) {
        confetti({
          particleCount: 75,
          spread: 60,
          origin: { y: 0.6 },
        });
      }
    } catch (err) {
      console.error("Failed to record scenario outcome:", err);
    }
  };

  const handleRestart = () => {
    if (!scenario || !scenario.steps) return;
    const initStep = scenario.steps.find((s) => s.step_key === scenario.initial_step_key) || scenario.steps[0];
    setCurrentStep(initStep);
    setMetrics({ trust: 60, risk: 30, speed: 50 });
    setHistory([]);
    setIsFinished(false);
    setFinalAttempt(null);
  };

  if (loading || !scenario) {
    return (
      <div className="h-64 flex items-center justify-center text-xs text-slate-400">
        Loading interactive consequence scenario...
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Navigation Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-200 dark:border-slate-800">
        <div className="flex items-center gap-3">
          <Link
            to="/simulator"
            className="p-2 rounded-lg border border-slate-200 dark:border-slate-800 hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-500 hover:text-slate-900 dark:hover:text-white transition-colors"
          >
            <ArrowLeft className="h-4 w-4" />
          </Link>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-xl font-bold tracking-tight text-slate-900 dark:text-white">
                {scenario.title}
              </h1>
              <Badge variant="success">{scenario.category}</Badge>
            </div>
            <p className="text-xs text-slate-400 mt-0.5">
              Live Workplace Decision Simulator • Decisions directly impact stakeholder trust and operational risk
            </p>
          </div>
        </div>

        <Button variant="outline" size="sm" onClick={handleRestart} className="text-xs gap-1.5 shrink-0">
          <RotateCcw className="h-3.5 w-3.5" />
          <span>Reset Simulation</span>
        </Button>
      </div>

      {/* Real-time Metric Gauges Bar */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        {/* Stakeholder Trust */}
        <Card className="p-4">
          <div className="flex items-center justify-between text-xs font-semibold">
            <span className="flex items-center gap-1.5 text-slate-700 dark:text-slate-300">
              <HeartHandshake className="h-4 w-4 text-emerald-500" /> Stakeholder Trust
            </span>
            <span className="font-mono text-emerald-500">{metrics.trust}%</span>
          </div>
          <div className="h-2 w-full bg-slate-100 dark:bg-slate-800 rounded-full mt-2 overflow-hidden">
            <div
              className="h-full bg-emerald-500 rounded-full transition-all duration-300"
              style={{ width: `${metrics.trust}%` }}
            />
          </div>
        </Card>

        {/* Operational Risk */}
        <Card className="p-4">
          <div className="flex items-center justify-between text-xs font-semibold">
            <span className="flex items-center gap-1.5 text-slate-700 dark:text-slate-300">
              <AlertTriangle className="h-4 w-4 text-rose-500" /> Operational Risk
            </span>
            <span className="font-mono text-rose-500">{metrics.risk}%</span>
          </div>
          <div className="h-2 w-full bg-slate-100 dark:bg-slate-800 rounded-full mt-2 overflow-hidden">
            <div
              className="h-full bg-rose-500 rounded-full transition-all duration-300"
              style={{ width: `${metrics.risk}%` }}
            />
          </div>
        </Card>

        {/* Resolution Speed */}
        <Card className="p-4">
          <div className="flex items-center justify-between text-xs font-semibold">
            <span className="flex items-center gap-1.5 text-slate-700 dark:text-slate-300">
              <Activity className="h-4 w-4 text-teal-500" /> Resolution Efficiency
            </span>
            <span className="font-mono text-teal-500">{metrics.speed}%</span>
          </div>
          <div className="h-2 w-full bg-slate-100 dark:bg-slate-800 rounded-full mt-2 overflow-hidden">
            <div
              className="h-full bg-teal-500 rounded-full transition-all duration-300"
              style={{ width: `${metrics.speed}%` }}
            />
          </div>
        </Card>
      </div>

      {/* Main Simulation View */}
      {isFinished && finalAttempt ? (
        /* Debrief Screen */
        <Card className="border-teal-500/30 bg-gradient-to-br from-teal-500/5 to-transparent">
          <CardHeader>
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div className="flex items-center gap-2">
                <CheckCircle2 className="h-6 w-6 text-teal-400" />
                <div>
                  <CardTitle className="text-lg">Simulation Debrief & Strategic Rating</CardTitle>
                  <CardDescription>Comprehensive consequence evaluation of your decisions</CardDescription>
                </div>
              </div>
              <div className="text-right">
                <div className="text-2xl font-bold text-teal-400 font-mono">
                  {finalAttempt.total_score}%
                </div>
                <Badge variant={finalAttempt.total_score >= 80 ? "success" : "brand"}>
                  {finalAttempt.performance_rating}
                </Badge>
              </div>
            </div>
          </CardHeader>

          <CardContent className="space-y-6">
            <div className="p-4 rounded-xl bg-white dark:bg-navy-950 border border-slate-200 dark:border-slate-800 text-xs text-slate-700 dark:text-slate-300 space-y-2 leading-relaxed">
              <span className="font-semibold block text-slate-900 dark:text-white">Strategic Analysis:</span>
              <p>{finalAttempt.debrief_notes}</p>
            </div>

            {/* Decision Trail Timeline */}
            <div className="space-y-3">
              <span className="text-xs font-bold uppercase tracking-wider text-slate-400 block">
                Your Decision Path & Consequences
              </span>
              <div className="space-y-2">
                {history.map((h, idx) => (
                  <div
                    key={idx}
                    className="p-3.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-white/60 dark:bg-navy-900 text-xs space-y-1.5"
                  >
                    <div className="flex items-center justify-between font-semibold text-slate-900 dark:text-white">
                      <span>Step {idx + 1}: {h.choice_text}</span>
                      <span className="text-emerald-500 font-mono">+{h.score_points} pts</span>
                    </div>
                    <p className="text-[11px] text-slate-600 dark:text-slate-300">
                      <strong>Consequence: </strong>{h.consequence}
                    </p>
                    <div className="text-[10px] text-slate-400 bg-slate-100 dark:bg-slate-950 p-2 rounded">
                      <strong>Rationale: </strong>{h.rationale}
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Passport notice */}
            {finalAttempt.total_score >= 70 && (
              <div className="p-3 rounded-lg bg-brand-500/10 border border-brand-500/20 text-xs text-brand-600 dark:text-brand-300 flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <ShieldCheck className="h-4 w-4 text-brand-500" />
                  <span>Verified simulator artifact added to your Evidence-Based Skill Passport!</span>
                </div>
                <Link to="/passport">
                  <Button variant="outline" size="sm" className="text-xs h-7">
                    View Passport
                  </Button>
                </Link>
              </div>
            )}

            <div className="pt-2 flex justify-end gap-3">
              <Button variant="secondary" size="sm" onClick={handleRestart} className="text-xs gap-1.5">
                <RotateCcw className="h-3.5 w-3.5" />
                <span>Replay Scenario</span>
              </Button>
              <Link to="/simulator">
                <Button variant="primary" size="sm" className="text-xs">
                  <span>Browse More Scenarios</span>
                </Button>
              </Link>
            </div>
          </CardContent>
        </Card>
      ) : currentStep ? (
        /* Active Branching Step */
        <Card className="border-slate-200 dark:border-slate-800">
          <CardHeader>
            <div className="flex items-center justify-between">
              <span className="text-xs font-mono text-emerald-500 uppercase tracking-wider">
                Simulation Active • Step {history.length + 1}
              </span>
              <span className="text-xs text-slate-400">Choose your response</span>
            </div>
            <CardTitle className="text-base sm:text-lg mt-1">
              {currentStep.prompt}
            </CardTitle>
            {currentStep.situation_update && (
              <CardDescription className="text-slate-600 dark:text-slate-300 bg-slate-50 dark:bg-slate-900/60 p-3 rounded-lg border border-slate-200 dark:border-slate-800 mt-2">
                <strong>Situation Context: </strong>{currentStep.situation_update}
              </CardDescription>
            )}
          </CardHeader>

          <CardContent className="space-y-4">
            <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider block">
              Available Workplace Decisions
            </span>

            <div className="grid grid-cols-1 gap-3">
              {currentStep.choices.map((choice) => (
                <button
                  key={choice.id}
                  onClick={() => handleMakeChoice(choice)}
                  className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-navy-900 hover:border-emerald-500/50 hover:bg-emerald-500/5 text-left transition-all duration-200 space-y-2 group"
                >
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-slate-900 dark:text-white group-hover:text-emerald-400 transition-colors">
                      {choice.choice_text}
                    </span>
                    <div className="flex items-center gap-2 text-[10px] font-mono">
                      {Object.entries(choice.metrics_delta || {}).map(([k, v]) => (
                        <span
                          key={k}
                          className={v >= 0 ? "text-emerald-500" : "text-rose-500"}
                        >
                          {k}: {v >= 0 ? `+${v}` : v}
                        </span>
                      ))}
                    </div>
                  </div>
                  <p className="text-[11px] text-slate-500 dark:text-slate-400 leading-relaxed">
                    <strong>Anticipated Consequence: </strong>{choice.consequences_narrative}
                  </p>
                </button>
              ))}
            </div>
          </CardContent>
        </Card>
      ) : null}
    </div>
  );
};
