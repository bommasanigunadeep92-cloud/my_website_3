import React, { useEffect, useState } from "react";
import { useParams, Link } from "react-router-dom";
import {
  Briefcase,
  Play,
  CheckCircle2,
  XCircle,
  Clock,
  ArrowLeft,
  Terminal,
  ShieldCheck,
  Cpu,
  Code2,
  FileText,
  RotateCcw,
  Sparkles
} from "lucide-react";
import confetti from "canvas-confetti";
import { api } from "../lib/api";
import { Mission, MissionSubmission } from "../lib/types";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "../components/common/Card";
import { Button } from "../components/common/Button";
import { Badge } from "../components/common/Badge";

export const MissionWorkspacePage: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const [mission, setMission] = useState<Mission | null>(null);
  const [code, setCode] = useState("");
  const [submissionResult, setSubmissionResult] = useState<MissionSubmission | null>(null);
  const [submitting, setSubmitting] = useState(false);
  const [activeTab, setActiveTab] = useState<"instructions" | "sample_data" | "rubric">("instructions");
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchMission = async () => {
      if (!id) return;
      try {
        const m = await api.getMission(id);
        setMission(m);

        // Prepopulate starter template based on mission
        if (m.submission_type === "SQL") {
          setCode(`-- Write your optimized query below:
SELECT 
    -- your select columns
FROM subscriptions s
INNER JOIN transactions t ON s.id = t.subscription_id
WHERE t.status != 'refunded'
-- Add window function and grouping logic
;`);
        } else if (m.submission_type === "CODE") {
          setCode(`// Token refresh race condition solution
async function handleRefreshToken(refreshToken: string) {
  // Implement atomic locking or grace period window here
  return { access_token: "new_token", refresh_token: "new_refresh" };
}`);
        } else {
          setCode(`## 1. Executive Incident Summary
Duration: 42 minutes | Affected Services: Checkout Pipeline

## 2. Root Cause Analysis
Statement lock on migration without timeout exhaustion...

## 3. Preventive Corrective Safeguards
- Configure statement_timeout = 5000ms
- Automate pre-deployment lock dry-runs`);
        }
      } catch (err) {
        console.error("Failed to load mission details:", err);
      } finally {
        setLoading(false);
      }
    };

    fetchMission();
  }, [id]);

  const handleSubmit = async () => {
    if (!id || !code.trim()) return;
    setSubmitting(true);
    try {
      const res = await api.submitMission(id, code);
      setSubmissionResult(res);

      if (res.score >= 70.0) {
        confetti({
          particleCount: 100,
          spread: 80,
          origin: { y: 0.6 },
        });
      }
    } catch (err) {
      console.error("Submission failed:", err);
    } finally {
      setSubmitting(false);
    }
  };

  if (loading || !mission) {
    return (
      <div className="h-64 flex items-center justify-center text-xs text-slate-400">
        Loading mission workspace...
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Top Breadcrumb & Actions */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-200 dark:border-slate-800">
        <div className="flex items-center gap-3">
          <Link
            to="/missions"
            className="p-2 rounded-lg border border-slate-200 dark:border-slate-800 hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-500 hover:text-slate-900 dark:hover:text-white transition-colors"
          >
            <ArrowLeft className="h-4 w-4" />
          </Link>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-xl font-bold tracking-tight text-slate-900 dark:text-white">
                {mission.title}
              </h1>
              <Badge variant={mission.difficulty === "ADVANCED" ? "danger" : "info"}>
                {mission.difficulty}
              </Badge>
            </div>
            <div className="flex items-center gap-3 text-xs text-slate-400 mt-0.5">
              <span>{mission.category}</span>
              <span>•</span>
              <span className="flex items-center gap-1">
                <Clock className="h-3 w-3" /> {mission.estimated_time_minutes} Mins
              </span>
              <span>•</span>
              <span className="font-mono text-teal-400">{mission.submission_type} Submission</span>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <Button
            variant="primary"
            size="md"
            onClick={handleSubmit}
            isLoading={submitting}
            className="text-xs gap-1.5 shadow-md shadow-brand-500/20"
          >
            <Play className="h-3.5 w-3.5" />
            <span>Run Automated Tests & Evaluate</span>
          </Button>
        </div>
      </div>

      {/* Main Workspace Layout: 2 Columns */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: Briefing, Sample Data, Rubric */}
        <div className="lg:col-span-5 space-y-4">
          <div className="flex items-center gap-1 p-1 bg-slate-100 dark:bg-slate-900 rounded-lg text-xs">
            <button
              onClick={() => setActiveTab("instructions")}
              className={`flex-1 py-1.5 font-medium rounded-md transition-colors ${
                activeTab === "instructions"
                  ? "bg-white dark:bg-navy-950 text-slate-900 dark:text-white shadow-sm"
                  : "text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white"
              }`}
            >
              Task Briefing
            </button>
            <button
              onClick={() => setActiveTab("sample_data")}
              className={`flex-1 py-1.5 font-medium rounded-md transition-colors ${
                activeTab === "sample_data"
                  ? "bg-white dark:bg-navy-950 text-slate-900 dark:text-white shadow-sm"
                  : "text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white"
              }`}
            >
              Sample Data
            </button>
            <button
              onClick={() => setActiveTab("rubric")}
              className={`flex-1 py-1.5 font-medium rounded-md transition-colors ${
                activeTab === "rubric"
                  ? "bg-white dark:bg-navy-950 text-slate-900 dark:text-white shadow-sm"
                  : "text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white"
              }`}
            >
              Evaluation Rubric
            </button>
          </div>

          <Card className="h-[520px] overflow-y-auto">
            <CardContent className="p-4 text-xs space-y-4 leading-relaxed">
              {activeTab === "instructions" && (
                <div className="space-y-4">
                  <div>
                    <span className="text-[11px] font-semibold text-brand-500 uppercase tracking-wider block mb-1">
                      Scenario Premise
                    </span>
                    <p className="text-slate-600 dark:text-slate-300 bg-slate-50 dark:bg-slate-900/60 p-3 rounded-lg border border-slate-200 dark:border-slate-800">
                      {mission.scenario_context}
                    </p>
                  </div>

                  <div>
                    <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider block mb-1">
                      Instructions & Deliverables
                    </span>
                    <div className="whitespace-pre-line text-slate-700 dark:text-slate-300 space-y-2">
                      {mission.instructions}
                    </div>
                  </div>
                </div>
              )}

              {activeTab === "sample_data" && (
                <div className="space-y-3">
                  <span className="text-[11px] font-semibold text-teal-400 uppercase tracking-wider block">
                    Dataset Schema & Mock Records
                  </span>
                  <pre className="p-3 bg-slate-950 text-slate-200 rounded-lg font-mono text-[11px] overflow-x-auto border border-slate-800">
                    {JSON.stringify(mission.sample_data, null, 2)}
                  </pre>
                </div>
              )}

              {activeTab === "rubric" && (
                <div className="space-y-3">
                  <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider block">
                    Scoring Rubric Breakdown
                  </span>
                  {mission.evaluation_rubric?.map((item, idx) => (
                    <div
                      key={idx}
                      className="p-3 rounded-lg border border-slate-200 dark:border-slate-800 bg-white dark:bg-navy-900 space-y-1"
                    >
                      <div className="flex items-center justify-between font-semibold text-slate-900 dark:text-white">
                        <span>{item.criterion}</span>
                        <span className="text-brand-500 font-mono">Max: {item.max_points} pts</span>
                      </div>
                      <p className="text-[11px] text-slate-500 dark:text-slate-400">
                        {item.description}
                      </p>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Right Column: Code Editor + Live Evaluation Panel */}
        <div className="lg:col-span-7 space-y-4">
          <Card className="flex flex-col">
            <CardHeader className="py-3 px-4 flex flex-row items-center justify-between">
              <div className="flex items-center gap-2">
                <Terminal className="h-4 w-4 text-brand-400" />
                <span className="text-xs font-semibold text-slate-900 dark:text-white">
                  Solution Workspace ({mission.submission_type})
                </span>
              </div>
              <span className="text-[10px] text-slate-400 font-mono">
                {code.split("\n").length} lines • {code.length} chars
              </span>
            </CardHeader>

            <CardContent className="p-0">
              <textarea
                value={code}
                onChange={(e) => setCode(e.target.value)}
                className="w-full h-72 p-4 font-mono text-xs bg-slate-950 text-emerald-400 rounded-b-xl border-t border-slate-800 focus:outline-none resize-none leading-relaxed"
                spellCheck={false}
              />
            </CardContent>
          </Card>

          {/* Results Panel */}
          {submissionResult && (
            <Card
              className={`border-2 animate-in fade-in ${
                submissionResult.score >= 70.0
                  ? "border-emerald-500/40 bg-emerald-500/5"
                  : "border-amber-500/40 bg-amber-500/5"
              }`}
            >
              <CardHeader className="pb-3">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                  <div className="flex items-center gap-2">
                    {submissionResult.score >= 70.0 ? (
                      <CheckCircle2 className="h-5 w-5 text-emerald-500" />
                    ) : (
                      <XCircle className="h-5 w-5 text-amber-500" />
                    )}
                    <span className="text-sm font-bold text-slate-900 dark:text-white">
                      Evaluation Outcome: {submissionResult.score}%
                    </span>
                    <Badge variant={submissionResult.score >= 70.0 ? "success" : "warning"}>
                      {submissionResult.status}
                    </Badge>
                  </div>

                  {/* Engine Badge */}
                  <div className="flex items-center gap-1.5 text-[10px] font-mono px-2 py-0.5 rounded bg-slate-200 dark:bg-slate-800 text-slate-600 dark:text-slate-300">
                    <Cpu className="h-3 w-3 text-brand-500" />
                    <span>Engine: {submissionResult.evaluation_engine}</span>
                  </div>
                </div>
                <CardDescription className="mt-1 text-slate-600 dark:text-slate-300">
                  {submissionResult.feedback}
                </CardDescription>
              </CardHeader>

              <CardContent className="space-y-4 pt-0">
                {/* Test results assertions */}
                {submissionResult.test_results && submissionResult.test_results.length > 0 && (
                  <div className="space-y-2">
                    <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block">
                      Automated Test Assertions
                    </span>
                    <div className="grid grid-cols-1 gap-2">
                      {submissionResult.test_results.map((tr, idx) => (
                        <div
                          key={idx}
                          className={`p-2.5 rounded-lg border text-xs flex items-center justify-between ${
                            tr.passed
                              ? "bg-emerald-500/10 border-emerald-500/30 text-emerald-950 dark:text-emerald-200"
                              : "bg-rose-500/10 border-rose-500/30 text-rose-950 dark:text-rose-200"
                          }`}
                        >
                          <div className="flex items-center gap-2">
                            {tr.passed ? (
                              <CheckCircle2 className="h-4 w-4 text-emerald-500 shrink-0" />
                            ) : (
                              <XCircle className="h-4 w-4 text-rose-500 shrink-0" />
                            )}
                            <div>
                              <span className="font-semibold block">{tr.test_name}</span>
                              <span className="text-[10px] text-slate-500 dark:text-slate-400">{tr.feedback}</span>
                            </div>
                          </div>
                          <span className="text-[10px] font-mono font-bold uppercase">
                            {tr.passed ? "Passed" : "Failed"}
                          </span>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* Rubric Breakdown */}
                {submissionResult.rubric_breakdown && (
                  <div className="space-y-2">
                    <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block">
                      Rubric Scoring Details
                    </span>
                    <div className="space-y-1.5">
                      {submissionResult.rubric_breakdown.map((rb, idx) => (
                        <div
                          key={idx}
                          className="p-2 rounded-lg bg-white/60 dark:bg-navy-950/60 border border-slate-200 dark:border-slate-800 text-xs flex items-center justify-between"
                        >
                          <div>
                            <span className="font-semibold text-slate-800 dark:text-slate-200">{rb.criterion}</span>
                            <span className="text-[11px] text-slate-400 block">{rb.notes}</span>
                          </div>
                          <span className="font-mono font-bold text-brand-500">
                            {rb.points_awarded} / {rb.max_points}
                          </span>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* Passport Notification if passed */}
                {submissionResult.score >= 70.0 && (
                  <div className="p-3 rounded-lg bg-brand-500/10 border border-brand-500/20 text-xs text-brand-600 dark:text-brand-300 flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <ShieldCheck className="h-4 w-4 text-brand-500" />
                      <span>Verified mission artifact minted to your Evidence-Based Skill Passport!</span>
                    </div>
                    <Link to="/passport">
                      <Button variant="outline" size="sm" className="text-[11px] h-7">
                        View in Passport
                      </Button>
                    </Link>
                  </div>
                )}
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </div>
  );
};
