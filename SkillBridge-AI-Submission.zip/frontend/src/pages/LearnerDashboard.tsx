import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import {
  Target,
  Briefcase,
  AlertTriangle,
  PlayCircle,
  Award,
  ArrowRight,
  Sparkles,
  TrendingUp,
  CheckCircle2,
  Clock,
  ShieldCheck,
  ChevronRight,
  BookOpen,
  Zap,
  Activity,
  Layers
} from "lucide-react";
import {
  ResponsiveContainer,
  RadarChart,
  PolarGrid,
  PolarAngleAxis,
  PolarRadiusAxis,
  Radar,
  AreaChart,
  Area,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid
} from "recharts";
import { useAuth } from "../context/AuthContext";
import { api } from "../lib/api";
import {
  SkillGapAnalysis,
  Mission,
  InterventionTracking,
  ScenarioAttempt,
  SkillPassport
} from "../lib/types";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "../components/common/Card";
import { Button } from "../components/common/Button";
import { Badge } from "../components/common/Badge";

export const LearnerDashboard: React.FC = () => {
  const { user } = useAuth();
  const [gapData, setGapData] = useState<SkillGapAnalysis | null>(null);
  const [missions, setMissions] = useState<Mission[]>([]);
  const [interventions, setInterventions] = useState<InterventionTracking[]>([]);
  const [passport, setPassport] = useState<SkillPassport | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const loadDashboardData = async () => {
      try {
        const [gapRes, missionsRes, intRes, passRes] = await Promise.all([
          api.getSkillGapAnalysis(),
          api.getMissions(),
          api.getMyInterventions(),
          api.getMyPassport()
        ]);
        setGapData(gapRes);
        setMissions(missionsRes);
        setInterventions(intRes);
        setPassport(passRes);
      } catch (err) {
        console.error("Dashboard data load error:", err);
      } finally {
        setLoading(false);
      }
    };

    loadDashboardData();
  }, [user]);

  // Seeded mock progress trend for visualization
  const trendData = [
    { date: "Oct 1", score: 62 },
    { date: "Oct 5", score: 68 },
    { date: "Oct 10", score: 71 },
    { date: "Oct 15", score: 79 },
    { date: "Oct 18", score: 86 },
    { date: "Today", score: 94.5 },
  ];

  if (loading) {
    return (
      <div className="space-y-6 animate-pulse">
        <div className="h-28 bg-slate-200 dark:bg-slate-800 rounded-2xl" />
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="h-64 bg-slate-200 dark:bg-slate-800 rounded-xl" />
          <div className="h-64 bg-slate-200 dark:bg-slate-800 rounded-xl" />
          <div className="h-64 bg-slate-200 dark:bg-slate-800 rounded-xl" />
        </div>
      </div>
    );
  }

  const readiness = gapData?.overall_readiness_pct || 76.4;

  return (
    <div className="space-y-6">
      {/* Welcome Banner */}
      <div className="relative overflow-hidden rounded-2xl bg-gradient-to-r from-brand-900/90 via-navy-900 to-indigo-950 p-6 sm:p-8 border border-brand-500/20 shadow-lg">
        <div className="absolute right-0 top-0 bottom-0 w-1/3 bg-gradient-to-l from-brand-500/10 to-transparent pointer-events-none" />
        <div className="relative z-10 flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
          <div className="space-y-2 max-w-2xl">
            <div className="inline-flex items-center gap-2 px-2.5 py-1 rounded-full bg-brand-500/20 text-brand-300 text-xs font-medium">
              <Sparkles className="h-3.5 w-3.5" />
              <span>Target Role: {user?.target_role || "Senior Full-Stack Engineer"}</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
              Welcome back, {user?.full_name?.split(" ")[0]}!
            </h1>
            <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
              You are currently demonstrating <span className="text-teal-400 font-semibold">{readiness}% readiness</span> against your target role benchmarks. You have 1 active remediation recommendation and 3 verified project artifacts.
            </p>
          </div>

          <div className="flex flex-col sm:flex-row gap-3 w-full md:w-auto">
            <Link to="/skills">
              <Button variant="teal" size="sm" className="w-full sm:w-auto gap-1.5 text-xs">
                <Target className="h-3.5 w-3.5" />
                <span>View Skill Gaps</span>
              </Button>
            </Link>
            <Link to="/missions">
              <Button variant="primary" size="sm" className="w-full sm:w-auto gap-1.5 text-xs">
                <Briefcase className="h-3.5 w-3.5" />
                <span>Browse Mission Lab</span>
              </Button>
            </Link>
          </div>
        </div>
      </div>

      {/* Top Metric Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Readiness Meter */}
        <Card className="p-4 flex flex-col justify-between">
          <div className="flex items-center justify-between text-xs text-slate-500 dark:text-slate-400">
            <span>Overall Role Readiness</span>
            <Target className="h-4 w-4 text-brand-500" />
          </div>
          <div className="my-2">
            <div className="text-2xl font-bold text-slate-900 dark:text-white flex items-baseline gap-2">
              <span>{readiness}%</span>
              <span className="text-xs font-semibold text-emerald-500">+12% this month</span>
            </div>
            <div className="h-2 w-full bg-slate-100 dark:bg-slate-800 rounded-full mt-2 overflow-hidden">
              <div
                className="h-full bg-gradient-to-r from-brand-500 to-teal-400 rounded-full transition-all duration-500"
                style={{ width: `${readiness}%` }}
              />
            </div>
          </div>
          <span className="text-[11px] text-slate-400">Target Benchmark: 4.0 / 5.0 scale</span>
        </Card>

        {/* Practical Proofs */}
        <Card className="p-4 flex flex-col justify-between">
          <div className="flex items-center justify-between text-xs text-slate-500 dark:text-slate-400">
            <span>Practical Missions</span>
            <Briefcase className="h-4 w-4 text-indigo-500" />
          </div>
          <div className="my-2">
            <div className="text-2xl font-bold text-slate-900 dark:text-white">
              {missions.filter((m) => m.user_status === "PASSED").length} / {missions.length}
            </div>
            <span className="text-xs text-slate-400">Completed with verified test rubrics</span>
          </div>
          <Link to="/missions" className="text-[11px] text-brand-500 font-medium hover:underline flex items-center gap-1">
            <span>Open mission catalogue</span>
            <ArrowRight className="h-3 w-3" />
          </Link>
        </Card>

        {/* Prevention Loop */}
        <Card className="p-4 flex flex-col justify-between">
          <div className="flex items-center justify-between text-xs text-slate-500 dark:text-slate-400">
            <span>Failure Loop Delta</span>
            <AlertTriangle className="h-4 w-4 text-amber-500" />
          </div>
          <div className="my-2">
            <div className="text-2xl font-bold text-teal-400 flex items-baseline gap-1.5">
              <span>+46.5%</span>
              <span className="text-xs font-normal text-slate-400">measured delta</span>
            </div>
            <span className="text-xs text-slate-400">Pre: 48% → Post: 94.5% in SQL</span>
          </div>
          <Link to="/failure-prevention" className="text-[11px] text-teal-500 font-medium hover:underline flex items-center gap-1">
            <span>Review intervention progress</span>
            <ArrowRight className="h-3 w-3" />
          </Link>
        </Card>

        {/* Verified Passport */}
        <Card className="p-4 flex flex-col justify-between border-brand-500/20 bg-gradient-to-b from-brand-500/5 to-transparent">
          <div className="flex items-center justify-between text-xs text-slate-500 dark:text-slate-400">
            <span>Skill Passport</span>
            <ShieldCheck className="h-4 w-4 text-teal-400" />
          </div>
          <div className="my-2">
            <div className="text-2xl font-bold text-slate-900 dark:text-white flex items-center gap-1.5">
              <span>{passport?.evidence_items?.length || 4}</span>
              <span className="text-xs font-normal text-slate-400">Verified Badges</span>
            </div>
            <span className="text-xs text-emerald-500 flex items-center gap-1">
              <CheckCircle2 className="h-3 w-3" /> Credential Authority Active
            </span>
          </div>
          <Link to="/passport" className="text-[11px] text-brand-500 font-medium hover:underline flex items-center gap-1">
            <span>View portable passport</span>
            <ArrowRight className="h-3 w-3" />
          </Link>
        </Card>
      </div>

      {/* Main Grid: Radar Chart + Skill Gap Bars */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Radar Chart: Module 1 Visualization */}
        <Card className="lg:col-span-5 flex flex-col">
          <CardHeader>
            <div className="flex items-center justify-between">
              <div>
                <CardTitle>Demonstrated Skill Radar</CardTitle>
                <CardDescription>Target role benchmark vs demonstrated proficiency</CardDescription>
              </div>
              <Badge variant="brand">Module 1</Badge>
            </div>
          </CardHeader>
          <CardContent className="flex-1 flex flex-col items-center justify-center p-2">
            {gapData && gapData.radar_data.length > 0 ? (
              <div className="w-full h-72">
                <ResponsiveContainer width="100%" height="100%">
                  <RadarChart cx="50%" cy="50%" outerRadius="75%" data={gapData.radar_data}>
                    <PolarGrid stroke="#334155" opacity={0.3} />
                    <PolarAngleAxis dataKey="skill" tick={{ fill: "#94a3b8", fontSize: 11 }} />
                    <PolarRadiusAxis angle={30} domain={[0, 5]} tick={{ fill: "#64748b", fontSize: 9 }} />
                    <Radar
                      name="Demonstrated"
                      dataKey="demonstrated"
                      stroke="#8b5cf6"
                      fill="#8b5cf6"
                      fillOpacity={0.4}
                    />
                    <Radar
                      name="Benchmark"
                      dataKey="required"
                      stroke="#14b8a6"
                      fill="#14b8a6"
                      fillOpacity={0.15}
                    />
                    <Tooltip
                      contentStyle={{
                        backgroundColor: "#0f172a",
                        borderColor: "#334155",
                        borderRadius: "8px",
                        fontSize: "12px",
                      }}
                    />
                  </RadarChart>
                </ResponsiveContainer>
              </div>
            ) : (
              <div className="h-64 flex items-center justify-center text-xs text-slate-400">
                Take an assessment to generate your radar chart.
              </div>
            )}
            <div className="flex items-center gap-6 text-xs text-slate-400 mt-2">
              <span className="flex items-center gap-2">
                <span className="h-2.5 w-2.5 rounded-full bg-brand-500" />
                Demonstrated Capability
              </span>
              <span className="flex items-center gap-2">
                <span className="h-2.5 w-2.5 rounded-full bg-teal-500" />
                Role Requirement
              </span>
            </div>
          </CardContent>
        </Card>

        {/* Skill Gap Comparison Breakdown */}
        <Card className="lg:col-span-7 flex flex-col">
          <CardHeader>
            <div className="flex items-center justify-between">
              <div>
                <CardTitle>Skill Gap Diagnostic Summary</CardTitle>
                <CardDescription>Top priorities to close before role progression</CardDescription>
              </div>
              <Link to="/skills">
                <Button variant="outline" size="sm" className="text-xs">
                  Full Analysis
                </Button>
              </Link>
            </div>
          </CardHeader>
          <CardContent className="space-y-4">
            {gapData?.improvement_areas.slice(0, 3).map((item) => (
              <div
                key={item.skill_id}
                className="p-3.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-900/40 space-y-2"
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-semibold text-slate-900 dark:text-white">
                      {item.skill_name}
                    </span>
                    <Badge variant={item.gap >= 1.5 ? "danger" : "warning"}>
                      Gap: -{item.gap.toFixed(1)}
                    </Badge>
                  </div>
                  <span className="text-xs font-mono text-slate-400">
                    {item.demonstrated_level.toFixed(1)} / {item.required_level.toFixed(1)}
                  </span>
                </div>

                <div className="h-2 w-full bg-slate-200 dark:bg-slate-800 rounded-full overflow-hidden">
                  <div
                    className="h-full bg-gradient-to-r from-amber-500 to-rose-500 rounded-full"
                    style={{ width: `${(item.demonstrated_level / item.required_level) * 100}%` }}
                  />
                </div>

                <p className="text-[11px] text-slate-500 dark:text-slate-400 leading-tight">
                  {item.reason}
                </p>
              </div>
            ))}

            {/* Strengths highlight */}
            {gapData?.strengths && gapData.strengths.length > 0 && (
              <div className="p-3 rounded-lg bg-emerald-500/10 border border-emerald-500/20 text-xs text-emerald-600 dark:text-emerald-400 flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="h-4 w-4" />
                  <span className="font-semibold">Demonstrated Strength:</span>
                  <span>{gapData.strengths[0].skill_name} ({gapData.strengths[0].demonstrated_level}/5.0)</span>
                </div>
                <Badge variant="success">Proficient</Badge>
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Row 2: Active Missions & Score Improvement Trend */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Real-World Missions Preview */}
        <Card className="lg:col-span-6">
          <CardHeader>
            <div className="flex items-center justify-between">
              <div>
                <CardTitle>Practical Mission Lab</CardTitle>
                <CardDescription>Hands-on workplace tasks evaluated by test suites</CardDescription>
              </div>
              <Badge variant="brand">Module 2</Badge>
            </div>
          </CardHeader>
          <CardContent className="space-y-3">
            {missions.slice(0, 3).map((m) => (
              <div
                key={m.id}
                className="p-3.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-navy-900/60 hover:border-brand-500/40 transition-colors flex items-center justify-between gap-4"
              >
                <div className="space-y-1 min-w-0">
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-semibold text-slate-900 dark:text-white truncate">
                      {m.title}
                    </span>
                    <Badge variant={m.difficulty === "ADVANCED" ? "danger" : "info"}>
                      {m.difficulty}
                    </Badge>
                  </div>
                  <div className="flex items-center gap-3 text-[11px] text-slate-400">
                    <span className="flex items-center gap-1">
                      <Clock className="h-3 w-3" /> {m.estimated_time_minutes} mins
                    </span>
                    <span>•</span>
                    <span>{m.submission_type}</span>
                  </div>
                </div>

                <div className="shrink-0 flex items-center gap-2">
                  {m.user_best_score ? (
                    <div className="text-right">
                      <span className="text-xs font-bold text-teal-400 block">{m.user_best_score}%</span>
                      <span className="text-[10px] text-slate-400">Best Score</span>
                    </div>
                  ) : null}
                  <Link to={`/missions/${m.id}`}>
                    <Button variant="secondary" size="sm" className="text-xs">
                      {m.user_status === "PASSED" ? "Review" : "Launch"}
                    </Button>
                  </Link>
                </div>
              </div>
            ))}
          </CardContent>
        </Card>

        {/* Evidence Improvement Trend Chart */}
        <Card className="lg:col-span-6 flex flex-col">
          <CardHeader>
            <div className="flex items-center justify-between">
              <div>
                <CardTitle>Demonstrated Improvement Trend</CardTitle>
                <CardDescription>Measured progress from diagnostic to mission execution</CardDescription>
              </div>
              <div className="flex items-center gap-1.5 text-xs text-teal-400 font-semibold">
                <TrendingUp className="h-3.5 w-3.5" />
                <span>+32.5% Gain</span>
              </div>
            </div>
          </CardHeader>
          <CardContent className="flex-1 flex flex-col justify-center">
            <div className="h-56 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={trendData}>
                  <defs>
                    <linearGradient id="scoreGrad" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#14b8a6" stopOpacity={0.4} />
                      <stop offset="95%" stopColor="#14b8a6" stopOpacity={0.0} />
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="#334155" opacity={0.3} />
                  <XAxis dataKey="date" stroke="#94a3b8" fontSize={11} />
                  <YAxis domain={[50, 100]} stroke="#94a3b8" fontSize={11} />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: "#0f172a",
                      borderColor: "#334155",
                      borderRadius: "8px",
                      fontSize: "12px",
                    }}
                  />
                  <Area
                    type="monotone"
                    dataKey="score"
                    stroke="#14b8a6"
                    strokeWidth={2}
                    fillOpacity={1}
                    fill="url(#scoreGrad)"
                  />
                </AreaChart>
              </ResponsiveContainer>
            </div>
            <p className="text-[11px] text-slate-400 text-center mt-2">
              Performance history reflects actual diagnostic attempts and evaluated practical submissions.
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Row 3: Active Failure Prevention & Consequence Simulator Quick Jump */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Remedial Loop Alert */}
        <Card className="border-amber-500/20 bg-gradient-to-br from-amber-500/5 to-transparent">
          <CardHeader>
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <AlertTriangle className="h-4 w-4 text-amber-500" />
                <CardTitle className="text-sm">Skill Failure Prevention Loop</CardTitle>
              </div>
              <Badge variant="warning">Remediation</Badge>
            </div>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="p-3 rounded-lg bg-white dark:bg-navy-900 border border-slate-200 dark:border-slate-800 space-y-1.5">
              <div className="flex items-center justify-between">
                <span className="text-xs font-semibold text-slate-900 dark:text-white">
                  Targeted Micro-Intervention Completed
                </span>
                <Badge variant="success">+46.5% Delta</Badge>
              </div>
              <p className="text-[11px] text-slate-500 dark:text-slate-400">
                You successfully closed the recurring conceptual difficulty in <strong>SQL Window Frame Boundaries</strong>.
              </p>
            </div>
            <Link to="/failure-prevention">
              <Button variant="outline" size="sm" className="w-full text-xs">
                <span>Submit Difficulty Report or View Patterns</span>
                <ChevronRight className="h-3.5 w-3.5 ml-1" />
              </Button>
            </Link>
          </CardContent>
        </Card>

        {/* Consequence Simulator Jump */}
        <Card className="border-emerald-500/20 bg-gradient-to-br from-emerald-500/5 to-transparent">
          <CardHeader>
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <PlayCircle className="h-4 w-4 text-emerald-500" />
                <CardTitle className="text-sm">Consequence-Based Simulator</CardTitle>
              </div>
              <Badge variant="success">Decisions</Badge>
            </div>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="p-3 rounded-lg bg-white dark:bg-navy-900 border border-slate-200 dark:border-slate-800 space-y-1.5">
              <div className="flex items-center justify-between">
                <span className="text-xs font-semibold text-slate-900 dark:text-white">
                  Customer Outage Crisis Simulation
                </span>
                <Badge variant="brand">Interactive</Badge>
              </div>
              <p className="text-[11px] text-slate-500 dark:text-slate-400">
                Practice high-stakes incident triage, stakeholder trust preservation, and de-escalation in safe simulations.
              </p>
            </div>
            <Link to="/simulator">
              <Button variant="outline" size="sm" className="w-full text-xs">
                <span>Enter Scenario Simulator</span>
                <ChevronRight className="h-3.5 w-3.5 ml-1" />
              </Button>
            </Link>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};
