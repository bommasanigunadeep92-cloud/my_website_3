import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { Compass, Lock, Mail, ArrowRight, ShieldCheck, UserCheck } from "lucide-react";
import { useAuth } from "../context/AuthContext";
import { Button } from "../components/common/Button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "../components/common/Card";

export const LoginPage: React.FC = () => {
  const { login } = useAuth();
  const navigate = useNavigate();

  const [email, setEmail] = useState("alex@acme.com");
  const [password, setPassword] = useState("LearnerPass123!");
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setLoading(true);

    try {
      await login(email, password);
      navigate("/dashboard");
    } catch (err: any) {
      setError(err.message || "Failed to log in. Please verify your credentials.");
    } finally {
      setLoading(false);
    }
  };

  const setDemoCredentials = (e: string, p: string) => {
    setEmail(e);
    setPassword(p);
  };

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-navy-950 flex flex-col justify-center py-12 sm:px-6 lg:px-8">
      <div className="sm:mx-auto sm:w-full sm:max-w-md text-center">
        <Link to="/" className="inline-flex items-center gap-2 mb-4">
          <div className="h-10 w-10 rounded-xl bg-gradient-to-br from-brand-600 to-teal-500 p-0.5 flex items-center justify-center shadow-md">
            <div className="h-full w-full bg-navy-950 rounded-[10px] flex items-center justify-center">
              <Compass className="h-5 w-5 text-brand-400" />
            </div>
          </div>
          <span className="text-xl font-bold tracking-tight text-slate-900 dark:text-white">
            SkillBridge <span className="text-transparent bg-clip-text bg-gradient-to-r from-brand-400 to-teal-400">AI</span>
          </span>
        </Link>
        <h2 className="text-2xl font-bold tracking-tight text-slate-900 dark:text-white">
          Sign in to your account
        </h2>
        <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">
          Enter your organization credentials or use a demonstration profile.
        </p>
      </div>

      <div className="mt-8 sm:mx-auto sm:w-full sm:max-w-md px-4 sm:px-0">
        <Card className="border-slate-200 dark:border-slate-800 shadow-xl bg-white dark:bg-navy-900">
          <CardContent className="pt-6">
            {error && (
              <div className="mb-4 p-3 rounded-lg bg-rose-500/10 border border-rose-500/20 text-rose-600 dark:text-rose-400 text-xs flex items-center gap-2">
                <span>{error}</span>
              </div>
            )}

            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                  Email address
                </label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400">
                    <Mail className="h-4 w-4" />
                  </div>
                  <input
                    type="email"
                    required
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="block w-full pl-9 pr-3 py-2 text-xs rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-navy-950 text-slate-900 dark:text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-brand-500"
                    placeholder="name@company.com"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                  Password
                </label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400">
                    <Lock className="h-4 w-4" />
                  </div>
                  <input
                    type="password"
                    required
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className="block w-full pl-9 pr-3 py-2 text-xs rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-navy-950 text-slate-900 dark:text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-brand-500"
                    placeholder="••••••••"
                  />
                </div>
              </div>

              <Button type="submit" variant="primary" className="w-full text-xs h-10" isLoading={loading}>
                <span>Sign In to SkillBridge</span>
                <ArrowRight className="h-4 w-4 ml-2" />
              </Button>
            </form>

            {/* Quick Demo Logins */}
            <div className="mt-6 pt-6 border-t border-slate-200 dark:border-slate-800 space-y-2">
              <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider block text-center">
                One-Click Demonstration Logins
              </span>
              <div className="grid grid-cols-1 gap-2">
                <button
                  type="button"
                  onClick={() => setDemoCredentials("alex@acme.com", "LearnerPass123!")}
                  className="p-2 text-left text-xs rounded-lg border border-slate-200 dark:border-slate-800 hover:border-brand-500/40 hover:bg-slate-50 dark:hover:bg-slate-800 flex items-center justify-between transition-colors"
                >
                  <div>
                    <span className="font-semibold text-slate-800 dark:text-slate-200 block">Alex Rivera (Learner)</span>
                    <span className="text-[10px] text-slate-400">Software Associate • Engineering</span>
                  </div>
                  <span className="text-[10px] px-1.5 py-0.5 rounded bg-brand-500/10 text-brand-500 font-medium">Use</span>
                </button>

                <button
                  type="button"
                  onClick={() => setDemoCredentials("manager@acme.com", "ManagerPass123!")}
                  className="p-2 text-left text-xs rounded-lg border border-slate-200 dark:border-slate-800 hover:border-indigo-500/40 hover:bg-slate-50 dark:hover:bg-slate-800 flex items-center justify-between transition-colors"
                >
                  <div>
                    <span className="font-semibold text-slate-800 dark:text-slate-200 block">Marcus Brody (Manager)</span>
                    <span className="text-[10px] text-slate-400">Engineering Director • Platform</span>
                  </div>
                  <span className="text-[10px] px-1.5 py-0.5 rounded bg-indigo-500/10 text-indigo-500 font-medium">Use</span>
                </button>

                <button
                  type="button"
                  onClick={() => setDemoCredentials("admin@acme.com", "AdminPass123!")}
                  className="p-2 text-left text-xs rounded-lg border border-slate-200 dark:border-slate-800 hover:border-purple-500/40 hover:bg-slate-50 dark:hover:bg-slate-800 flex items-center justify-between transition-colors"
                >
                  <div>
                    <span className="font-semibold text-slate-800 dark:text-slate-200 block">Sarah Chen (Admin)</span>
                    <span className="text-[10px] text-slate-400">VP Talent Architecture</span>
                  </div>
                  <span className="text-[10px] px-1.5 py-0.5 rounded bg-purple-500/10 text-purple-500 font-medium">Use</span>
                </button>
              </div>
            </div>

            <div className="mt-4 text-center">
              <Link to="/register" className="text-xs text-brand-600 dark:text-brand-400 hover:underline">
                Don't have an account? Register here
              </Link>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};
