import React, { useState } from "react";
import { Link } from "react-router-dom";
import {
  Compass,
  ArrowRight,
  ShieldCheck,
  Target,
  Briefcase,
  AlertTriangle,
  PlayCircle,
  BookOpen,
  Award,
  CheckCircle2,
  Lock,
  ChevronDown,
  Sparkles,
  BarChart2,
  Users,
  Terminal,
  Activity
} from "lucide-react";
import { Button } from "../components/common/Button";
import { Badge } from "../components/common/Badge";

export const LandingPage: React.FC = () => {
  const [activeFaq, setActiveFaq] = useState<number | null>(null);

  const innovations = [
    {
      num: "01",
      title: "Smart Skill Gap Detector",
      icon: Target,
      desc: "Benchmark your demonstrated capability against specific workplace roles. Multi-dimensional diagnostic assessments identify exact proficiency tiers (1–5) and formulate personalized roadmaps.",
      highlight: "Evidence-Based Benchmarking",
      color: "from-violet-500/20 to-purple-500/20 text-violet-500"
    },
    {
      num: "02",
      title: "Real-World Mission Lab",
      icon: Briefcase,
      desc: "Beyond passive quizzes: solve real operational challenges. Write performant SQL, refactor race conditions, and draft incident post-mortems against automated test suites and transparent rubrics.",
      highlight: "Practical Demonstrations",
      color: "from-blue-500/20 to-indigo-500/20 text-indigo-500"
    },
    {
      num: "03",
      title: "Skill Failure Prevention Loop",
      icon: AlertTriangle,
      desc: "Detect recurring conceptual roadblocks across your organization before they manifest as production incidents. Clusters aggregated problem patterns to deploy targeted micro-interventions.",
      highlight: "Pre & Post Metric Delta",
      color: "from-amber-500/20 to-orange-500/20 text-amber-500"
    },
    {
      num: "04",
      title: "Consequence-Based Simulator",
      icon: PlayCircle,
      desc: "Navigate high-stakes workplace decision trees. Experience real-time stakeholder trust, operational risk, and resolution efficiency consequences in safe simulated branching environments.",
      highlight: "Dynamic Branching Decisions",
      color: "from-emerald-500/20 to-teal-500/20 text-emerald-500"
    },
    {
      num: "05",
      title: "Knowledge Continuity Radar",
      icon: BookOpen,
      desc: "Safeguard institutional memory. Surface Single-Points-of-Failure (SPOFs) where mission-critical procedures rely on a lone expert, and automate cross-training shadow rotations.",
      highlight: "SPOF Risk Heatmaps",
      color: "from-cyan-500/20 to-sky-500/20 text-cyan-500"
    },
    {
      num: "06",
      title: "Evidence-Based Skill Passport",
      icon: Award,
      desc: "A cryptographically verifiable record of proven capability. Explicitly distinguishes self-reported credentials from platform-assessed diagnostics and practical mission artifacts with revocable share tokens.",
      highlight: "Portable Verified Credentials",
      color: "from-rose-500/20 to-pink-500/20 text-rose-500"
    }
  ];

  const faqs = [
    {
      q: "How does SkillBridge AI differ from generic LMS platforms?",
      a: "Generic LMS platforms measure passive video completion and simplistic multiple-choice quizzes. SkillBridge AI measures demonstrated competence through practical mission labs (refactoring queries, resolving race conditions), consequence-based decision simulators, and cross-training evidence."
    },
    {
      q: "Can the platform operate if external AI providers are offline?",
      a: "Yes. SkillBridge AI is engineered with provider-independent interfaces and deterministic evaluation engines. When LLM APIs are unavailable, the platform automatically utilizes deterministic rule-based rubrics and automated test assertions. Feedback states are explicitly labelled as deterministic or AI-generated."
    },
    {
      q: "How does the Skill Failure Prevention Loop preserve learner privacy?",
      a: "Failure reports support optional anonymous submission. Organizational analytics apply strict minimum group thresholds (minimum 3 reports) before clustering patterns for managers, ensuring remedial support is provided without individual finger-pointing or punitive rankings."
    },
    {
      q: "What is the Organizational Knowledge Continuity Radar?",
      a: "It detects institutional knowledge risks by auditing standard operating procedures (SOPs). If a critical procedure relies on a single subject-matter expert or has not been reviewed within its compliance cadence, the system flags a Single Point of Failure (SPOF) and recommends structured cross-training."
    },
    {
      q: "Are Skill Passport achievements publicly shareable?",
      a: "Yes. Each learner maintains a Skill Passport with revocable sharing tokens. External stakeholders or recruiters can verify assessment dates, rubric criteria, and project evidence without creating an account, while learners retain full privacy controls."
    }
  ];

  return (
    <div className="min-h-screen bg-slate-900 text-white selection:bg-brand-500 selection:text-white">
      {/* Public Navbar */}
      <nav className="border-b border-slate-800 bg-slate-950/80 backdrop-blur-md sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-6 h-16 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="h-9 w-9 rounded-lg bg-gradient-to-br from-brand-500 to-teal-400 p-0.5 flex items-center justify-center">
              <div className="h-full w-full bg-slate-950 rounded-[7px] flex items-center justify-center">
                <Compass className="h-5 w-5 text-brand-400" />
              </div>
            </div>
            <span className="text-lg font-bold tracking-tight text-white flex items-center gap-1">
              SkillBridge <span className="text-transparent bg-clip-text bg-gradient-to-r from-brand-400 to-teal-400">AI</span>
            </span>
          </div>

          <div className="hidden md:flex items-center gap-8 text-sm text-slate-300">
            <a href="#innovations" className="hover:text-white transition-colors">Innovations</a>
            <a href="#how-it-works" className="hover:text-white transition-colors">How It Works</a>
            <a href="#preview" className="hover:text-white transition-colors">Product Preview</a>
            <a href="#security" className="hover:text-white transition-colors">Privacy & Governance</a>
            <a href="#faq" className="hover:text-white transition-colors">FAQ</a>
          </div>

          <div className="flex items-center gap-3">
            <Link
              to="/login"
              className="px-3.5 py-1.5 text-xs font-medium text-slate-300 hover:text-white transition-colors"
            >
              Sign In
            </Link>
            <Link
              to="/dashboard"
              className="px-4 py-2 text-xs font-semibold rounded-lg bg-gradient-to-r from-brand-600 to-indigo-600 hover:from-brand-500 hover:to-indigo-500 text-white shadow-lg shadow-brand-500/20 transition-all"
            >
              Launch Live Platform
            </Link>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="relative pt-24 pb-20 px-6 overflow-hidden">
        {/* Glow backdrop */}
        <div className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[350px] bg-brand-600/20 blur-[130px] rounded-full pointer-events-none" />
        <div className="absolute top-1/3 right-1/4 w-[400px] h-[300px] bg-teal-500/10 blur-[120px] rounded-full pointer-events-none" />

        <div className="max-w-4xl mx-auto text-center space-y-6 relative z-10">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-brand-500/10 border border-brand-500/20 text-brand-400 text-xs font-medium">
            <Sparkles className="h-3.5 w-3.5" />
            <span>Next-Generation Corporate Learning & Skill Development</span>
          </div>

          <h1 className="text-4xl sm:text-6xl font-extrabold tracking-tight text-white leading-tight sm:leading-none">
            Turn Learning Into <br />
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-brand-400 via-indigo-300 to-teal-300">
              Demonstrated Workplace Capability
            </span>
          </h1>

          <p className="text-base sm:text-lg text-slate-400 max-w-2xl mx-auto leading-relaxed">
            Move beyond course completion percentages. SkillBridge AI combines diagnostic gap detection, real-world practical mission labs, consequence simulators, and organizational knowledge continuity into one verifiable ecosystem.
          </p>

          <div className="flex flex-col sm:flex-row items-center justify-center gap-4 pt-4">
            <Link
              to="/dashboard"
              className="w-full sm:w-auto px-6 py-3.5 rounded-xl bg-gradient-to-r from-brand-600 via-indigo-600 to-teal-500 hover:opacity-95 text-white font-semibold text-sm shadow-xl shadow-brand-500/25 flex items-center justify-center gap-2 group transition-all"
            >
              <span>Explore Platform Experience</span>
              <ArrowRight className="h-4 w-4 group-hover:translate-x-1 transition-transform" />
            </Link>

            <Link
              to="/passport/share/alex-rivera-verified-2026"
              className="w-full sm:w-auto px-6 py-3.5 rounded-xl border border-slate-700 bg-slate-800/60 hover:bg-slate-800 text-slate-200 font-medium text-sm flex items-center justify-center gap-2 transition-colors"
            >
              <Award className="h-4 w-4 text-brand-400" />
              <span>Inspect Verified Skill Passport</span>
            </Link>
          </div>

          {/* Quick Metrics */}
          <div className="pt-12 grid grid-cols-2 sm:grid-cols-4 gap-4 max-w-3xl mx-auto border-t border-slate-800/80">
            <div className="p-3">
              <div className="text-2xl font-bold text-white">6</div>
              <div className="text-xs text-slate-400">Integrated Innovations</div>
            </div>
            <div className="p-3">
              <div className="text-2xl font-bold text-teal-400">94.5%</div>
              <div className="text-xs text-slate-400">Practical Mission Proof</div>
            </div>
            <div className="p-3">
              <div className="text-2xl font-bold text-brand-400">+46.5%</div>
              <div className="text-xs text-slate-400">Remedial Score Delta</div>
            </div>
            <div className="p-3">
              <div className="text-2xl font-bold text-indigo-400">100%</div>
              <div className="text-xs text-slate-400">Deterministic Reliability</div>
            </div>
          </div>
        </div>
      </section>

      {/* The 6 Innovations */}
      <section id="innovations" className="py-20 px-6 border-t border-slate-800 bg-slate-950">
        <div className="max-w-7xl mx-auto space-y-12">
          <div className="text-center space-y-3 max-w-2xl mx-auto">
            <Badge variant="brand" size="md">Architecture & Modules</Badge>
            <h2 className="text-3xl sm:text-4xl font-bold tracking-tight text-white">
              The Six Core Innovations
            </h2>
            <p className="text-sm text-slate-400">
              Each module functions as a specialized, interconnected subsystem addressing real enterprise talent challenges.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {innovations.map((item) => (
              <div
                key={item.num}
                className="rounded-2xl border border-slate-800 bg-slate-900/60 p-6 flex flex-col justify-between hover:border-brand-500/40 hover:bg-slate-900/90 transition-all group"
              >
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div className={`h-10 w-10 rounded-xl bg-gradient-to-br ${item.color} p-2 flex items-center justify-center`}>
                      <item.icon className="h-5 w-5" />
                    </div>
                    <span className="font-mono text-xs text-slate-500 group-hover:text-brand-400 transition-colors">
                      {item.num}
                    </span>
                  </div>

                  <h3 className="text-lg font-semibold text-white group-hover:text-brand-300 transition-colors">
                    {item.title}
                  </h3>

                  <p className="text-xs text-slate-400 leading-relaxed">
                    {item.desc}
                  </p>
                </div>

                <div className="pt-6 mt-6 border-t border-slate-800/80 flex items-center justify-between">
                  <span className="text-[11px] font-medium text-teal-400">
                    {item.highlight}
                  </span>
                  <Link
                    to="/dashboard"
                    className="text-xs text-slate-400 hover:text-white flex items-center gap-1 group-hover:translate-x-1 transition-all"
                  >
                    <span>Inspect</span>
                    <ArrowRight className="h-3 w-3" />
                  </Link>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* How the Platform Works */}
      <section id="how-it-works" className="py-20 px-6 border-t border-slate-800 bg-slate-900/50">
        <div className="max-w-5xl mx-auto space-y-12">
          <div className="text-center space-y-3">
            <h2 className="text-3xl font-bold tracking-tight text-white">How SkillBridge AI Works</h2>
            <p className="text-sm text-slate-400">
              An evidence-driven continuous development cycle from diagnostic baseline to verified portfolio.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
            <div className="p-5 rounded-xl border border-slate-800 bg-slate-900 text-center space-y-3">
              <div className="h-8 w-8 rounded-full bg-brand-500/20 text-brand-400 font-bold text-sm mx-auto flex items-center justify-center">1</div>
              <h4 className="font-semibold text-white text-sm">Diagnostic Assessment</h4>
              <p className="text-xs text-slate-400">Evaluate baseline proficiency against target role benchmarks without artificial score inflation.</p>
            </div>

            <div className="p-5 rounded-xl border border-slate-800 bg-slate-900 text-center space-y-3">
              <div className="h-8 w-8 rounded-full bg-indigo-500/20 text-indigo-400 font-bold text-sm mx-auto flex items-center justify-center">2</div>
              <h4 className="font-semibold text-white text-sm">Practical Mission Labs</h4>
              <p className="text-xs text-slate-400">Submit working code, optimized queries, and incident post-mortems evaluated by deterministic rubrics.</p>
            </div>

            <div className="p-5 rounded-xl border border-slate-800 bg-slate-900 text-center space-y-3">
              <div className="h-8 w-8 rounded-full bg-amber-500/20 text-amber-400 font-bold text-sm mx-auto flex items-center justify-center">3</div>
              <h4 className="font-semibold text-white text-sm">Remedial Prevention</h4>
              <p className="text-xs text-slate-400">Address recurring difficulties via clustered micro-interventions, proving measurable score improvement.</p>
            </div>

            <div className="p-5 rounded-xl border border-slate-800 bg-slate-900 text-center space-y-3">
              <div className="h-8 w-8 rounded-full bg-teal-500/20 text-teal-400 font-bold text-sm mx-auto flex items-center justify-center">4</div>
              <h4 className="font-semibold text-white text-sm">Verified Skill Passport</h4>
              <p className="text-xs text-slate-400">Compile verifiable project artifacts into a revocable public portfolio backed by transparent criteria.</p>
            </div>
          </div>
        </div>
      </section>

      {/* Interactive Product Preview */}
      <section id="preview" className="py-20 px-6 border-t border-slate-800 bg-slate-950">
        <div className="max-w-6xl mx-auto space-y-8">
          <div className="text-center space-y-2">
            <Badge variant="brand">Interactive Showcase</Badge>
            <h2 className="text-3xl font-bold tracking-tight text-white">Live Platform Interface Preview</h2>
            <p className="text-sm text-slate-400">Experience actual UI components with live data.</p>
          </div>

          <div className="rounded-2xl border border-slate-800 bg-slate-900 shadow-2xl p-6 sm:p-8 space-y-6">
            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 pb-6 border-b border-slate-800">
              <div>
                <span className="text-xs font-mono text-brand-400">LIVE PREVIEW • SEEDED DATA</span>
                <h3 className="text-xl font-bold text-white">Alex Rivera — Software Associate</h3>
                <p className="text-xs text-slate-400">Target Role: Senior Full-Stack Engineer • Acme Global Technologies</p>
              </div>
              <div className="flex items-center gap-3">
                <Link to="/skills">
                  <Button variant="outline" size="sm">Open Gap Detector</Button>
                </Link>
                <Link to="/missions">
                  <Button variant="primary" size="sm">Launch Mission Lab</Button>
                </Link>
              </div>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              {/* Gap bar preview */}
              <div className="lg:col-span-2 rounded-xl border border-slate-800/80 bg-slate-950/60 p-4 space-y-4">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-semibold text-slate-200">Demonstrated vs Target Benchmark</span>
                  <span className="text-xs text-brand-400 font-medium">Readiness: 76.4%</span>
                </div>
                <div className="space-y-3">
                  <div>
                    <div className="flex justify-between text-xs mb-1">
                      <span className="text-slate-300">Frontend Architecture & TypeScript</span>
                      <span className="text-emerald-400 font-mono">4.2 / 4.5 (Proficient)</span>
                    </div>
                    <div className="h-2 w-full bg-slate-800 rounded-full overflow-hidden">
                      <div className="h-full bg-emerald-500 rounded-full" style={{ width: "93%" }} />
                    </div>
                  </div>

                  <div>
                    <div className="flex justify-between text-xs mb-1">
                      <span className="text-slate-300">API Security & Access Control</span>
                      <span className="text-indigo-400 font-mono">3.8 / 4.2 (Developing)</span>
                    </div>
                    <div className="h-2 w-full bg-slate-800 rounded-full overflow-hidden">
                      <div className="h-full bg-indigo-500 rounded-full" style={{ width: "90%" }} />
                    </div>
                  </div>

                  <div>
                    <div className="flex justify-between text-xs mb-1">
                      <span className="text-slate-300">SQL & Query Optimization</span>
                      <span className="text-amber-400 font-mono">2.8 / 4.0 (Developing • Gap -1.2)</span>
                    </div>
                    <div className="h-2 w-full bg-slate-800 rounded-full overflow-hidden">
                      <div className="h-full bg-amber-500 rounded-full" style={{ width: "70%" }} />
                    </div>
                  </div>

                  <div>
                    <div className="flex justify-between text-xs mb-1">
                      <span className="text-slate-300">Cloud Infrastructure & Containers</span>
                      <span className="text-rose-400 font-mono">2.2 / 3.5 (Insufficient Evidence)</span>
                    </div>
                    <div className="h-2 w-full bg-slate-800 rounded-full overflow-hidden">
                      <div className="h-full bg-rose-500 rounded-full" style={{ width: "62%" }} />
                    </div>
                  </div>
                </div>
              </div>

              {/* Verified passport badge preview */}
              <div className="rounded-xl border border-brand-500/20 bg-gradient-to-b from-brand-950/40 to-slate-950/60 p-4 flex flex-col justify-between">
                <div className="space-y-3">
                  <div className="flex items-center gap-2">
                    <ShieldCheck className="h-5 w-5 text-teal-400" />
                    <span className="text-xs font-bold text-white uppercase tracking-wider">Skill Passport Verified</span>
                  </div>
                  <p className="text-xs text-slate-300">
                    3 Practical Artifacts verified by automated criteria & peer mentors.
                  </p>
                  <div className="p-2.5 rounded-lg bg-slate-900 border border-slate-800 text-[11px] font-mono text-slate-400 space-y-1">
                    <div>• Mission: SQL Window Analytics (94.5%)</div>
                    <div>• Diagnostic: Full-Stack Arch (92.0%)</div>
                    <div>• Cross-Training: K8s Upgrade (100%)</div>
                  </div>
                </div>

                <div className="pt-4 mt-4 border-t border-slate-800 flex justify-between items-center text-xs">
                  <span className="text-slate-400">Share Token</span>
                  <span className="font-mono text-brand-400 text-[11px]">alex-rivera-verified-2026</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Privacy, Security & Governance */}
      <section id="security" className="py-20 px-6 border-t border-slate-800 bg-slate-900/60">
        <div className="max-w-5xl mx-auto space-y-10">
          <div className="text-center space-y-3">
            <div className="inline-flex items-center gap-2 text-teal-400 text-xs font-semibold uppercase tracking-wider">
              <Lock className="h-4 w-4" /> Governance & Ethics
            </div>
            <h2 className="text-3xl font-bold tracking-tight text-white">Ethical Architecture & Security Commitments</h2>
            <p className="text-sm text-slate-400 max-w-2xl mx-auto">
              SkillBridge AI adheres strictly to workplace fairness, tenant data isolation, and ethical AI standards.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="p-5 rounded-xl border border-slate-800 bg-slate-900 space-y-2">
              <h4 className="font-semibold text-white text-sm flex items-center gap-2">
                <ShieldCheck className="h-4 w-4 text-brand-400" /> No Algorithmic Firing
              </h4>
              <p className="text-xs text-slate-400 leading-relaxed">
                AI and assessment scores never make consequential employment, ranking, or termination decisions. Scores represent developmental opportunities.
              </p>
            </div>

            <div className="p-5 rounded-xl border border-slate-800 bg-slate-900 space-y-2">
              <h4 className="font-semibold text-white text-sm flex items-center gap-2">
                <Users className="h-4 w-4 text-teal-400" /> Anonymity Thresholds
              </h4>
              <p className="text-xs text-slate-400 leading-relaxed">
                Failure prevention reports enforce minimum aggregation thresholds (3+ learners) so managers cannot identify individual struggles punitively.
              </p>
            </div>

            <div className="p-5 rounded-xl border border-slate-800 bg-slate-900 space-y-2">
              <h4 className="font-semibold text-white text-sm flex items-center gap-2">
                <CheckCircle2 className="h-4 w-4 text-indigo-400" /> Isolated Tenant Boundaries
              </h4>
              <p className="text-xs text-slate-400 leading-relaxed">
                Multi-tenant organizations are strictly scoped at database and API layers. No company documentation or metrics are ever shared across tenants.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section id="faq" className="py-20 px-6 border-t border-slate-800 bg-slate-950">
        <div className="max-w-3xl mx-auto space-y-8">
          <div className="text-center space-y-2">
            <h2 className="text-3xl font-bold tracking-tight text-white">Frequently Asked Questions</h2>
            <p className="text-xs text-slate-400">Everything you need to know about SkillBridge AI.</p>
          </div>

          <div className="space-y-3">
            {faqs.map((f, idx) => (
              <div
                key={idx}
                className="rounded-xl border border-slate-800 bg-slate-900/60 overflow-hidden transition-colors"
              >
                <button
                  onClick={() => setActiveFaq(activeFaq === idx ? null : idx)}
                  className="w-full p-4 text-left flex items-center justify-between text-sm font-semibold text-slate-200 hover:text-white"
                >
                  <span>{f.q}</span>
                  <ChevronDown
                    className={`h-4 w-4 text-slate-400 transition-transform ${
                      activeFaq === idx ? "rotate-180" : ""
                    }`}
                  />
                </button>
                {activeFaq === idx && (
                  <div className="px-4 pb-4 text-xs text-slate-400 leading-relaxed border-t border-slate-800/60 pt-3">
                    {f.a}
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Footer Section */}
      <footer className="border-t border-slate-800 bg-slate-950 py-12 px-6">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="flex items-center gap-3">
            <div className="h-8 w-8 rounded-lg bg-brand-600 flex items-center justify-center">
              <Compass className="h-5 w-5 text-white" />
            </div>
            <div>
              <span className="font-bold text-sm text-white">SkillBridge AI</span>
              <span className="text-xs text-slate-500 block">Corporate Learning & Skill Development Platform</span>
            </div>
          </div>

          <div className="flex items-center gap-6 text-xs text-slate-400">
            <Link to="/dashboard" className="hover:text-white transition-colors">Learner App</Link>
            <Link to="/corporate" className="hover:text-white transition-colors">Corporate Hub</Link>
            <Link to="/passport/share/alex-rivera-verified-2026" className="hover:text-white transition-colors">Sample Passport</Link>
            <Link to="/login" className="hover:text-white transition-colors">Login</Link>
          </div>

          <div className="text-xs text-slate-500">
            © 2026 SkillBridge AI. Enterprise Production Grade.
          </div>
        </div>
      </footer>
    </div>
  );
};
