import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import {
  PlayCircle,
  Clock,
  CheckCircle2,
  AlertTriangle,
  ArrowRight,
  ShieldAlert,
  Users,
  TrendingUp,
  RotateCcw
} from "lucide-react";
import { api } from "../lib/api";
import { Scenario, ScenarioAttempt } from "../lib/types";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "../components/common/Card";
import { Button } from "../components/common/Button";
import { Badge } from "../components/common/Badge";

export const ScenarioSimulatorPage: React.FC = () => {
  const [scenarios, setScenarios] = useState<Scenario[]>([]);
  const [history, setHistory] = useState<ScenarioAttempt[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const [scRes, histRes] = await Promise.all([
          api.getScenarios(),
          api.getScenarioHistory()
        ]);
        setScenarios(scRes);
        setHistory(histRes);
      } catch (err) {
        console.error("Error loading simulator data:", err);
      } finally {
        setLoading(false);
      }
    };
    fetchData();
  }, []);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-200 dark:border-slate-800">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-2xl font-bold tracking-tight text-slate-900 dark:text-white">
              Consequence-Based Learning Simulator
            </h1>
            <Badge variant="success">Module 4</Badge>
          </div>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
            Practice workplace decisions in safe simulated branching environments. Experience stakeholder consequences without real-world risk.
          </p>
        </div>
      </div>

      {loading ? (
        <div className="h-64 flex items-center justify-center text-xs text-slate-400">
          Loading scenario simulations...
        </div>
      ) : (
        <div className="space-y-8">
          {/* Scenarios Grid */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {scenarios.map((sc) => (
              <Card key={sc.id} className="flex flex-col justify-between hover:border-emerald-500/40 transition-all group">
                <CardHeader>
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-[11px] font-semibold text-emerald-500 uppercase tracking-wider">
                      {sc.category}
                    </span>
                    <Badge variant={sc.difficulty === "ADVANCED" ? "danger" : "info"}>
                      {sc.difficulty}
                    </Badge>
                  </div>
                  <CardTitle className="text-base group-hover:text-emerald-400 transition-colors">
                    {sc.title}
                  </CardTitle>
                  <CardDescription className="line-clamp-2 mt-1">
                    {sc.description}
                  </CardDescription>
                </CardHeader>

                <CardContent className="space-y-4">
                  {/* Learning Objectives */}
                  <div className="space-y-1.5 p-3 rounded-lg bg-slate-50 dark:bg-slate-900/60 border border-slate-200 dark:border-slate-800 text-[11px] text-slate-600 dark:text-slate-300">
                    <span className="font-semibold block text-slate-900 dark:text-white">Focus Objectives:</span>
                    {sc.learning_objectives?.slice(0, 2).map((obj, i) => (
                      <div key={i} className="truncate">• {obj}</div>
                    ))}
                  </div>

                  <div className="pt-2 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between text-xs text-slate-400">
                    <span className="flex items-center gap-1">
                      <Clock className="h-3.5 w-3.5" /> {sc.estimated_minutes} mins
                    </span>
                    {sc.user_best_score ? (
                      <span className="text-teal-400 font-bold">Best: {sc.user_best_score}%</span>
                    ) : (
                      <span>Unattempted</span>
                    )}
                  </div>

                  <Link to={`/simulator/${sc.id}`} className="block">
                    <Button variant="teal" size="sm" className="w-full text-xs gap-1.5">
                      <PlayCircle className="h-3.5 w-3.5" />
                      <span>{sc.user_attempts_count ? "Replay Scenario" : "Start Simulation"}</span>
                    </Button>
                  </Link>
                </CardContent>
              </Card>
            ))}
          </div>

          {/* Past Simulation History */}
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle>Decision History & Debrief Records</CardTitle>
                  <CardDescription>Review consequences and strategic performance ratings from past attempts</CardDescription>
                </div>
                <Badge variant="brand">Attempt Log</Badge>
              </div>
            </CardHeader>
            <CardContent>
              {history.length === 0 ? (
                <div className="text-center py-6 text-xs text-slate-400">
                  No simulation runs recorded yet. Start a scenario above to record your decisions.
                </div>
              ) : (
                <div className="divide-y divide-slate-100 dark:divide-slate-800">
                  {history.map((h) => (
                    <div key={h.id} className="py-4 space-y-2">
                      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                        <div className="flex items-center gap-2">
                          <span className="font-semibold text-xs text-slate-900 dark:text-white">
                            {h.scenario_title}
                          </span>
                          <Badge variant={h.total_score >= 80 ? "success" : "warning"}>
                            {h.performance_rating}
                          </Badge>
                        </div>
                        <div className="flex items-center gap-4 text-xs font-mono">
                          <span className="text-teal-400 font-bold">Score: {h.total_score}%</span>
                          <span className="text-slate-400">{new Date(h.completed_at).toLocaleDateString()}</span>
                        </div>
                      </div>

                      <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed bg-slate-50 dark:bg-slate-900/60 p-3 rounded-lg border border-slate-200 dark:border-slate-800">
                        {h.debrief_notes}
                      </p>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  );
};
