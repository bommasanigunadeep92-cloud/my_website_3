import React from "react";
import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import { AuthProvider, useAuth } from "./context/AuthContext";
import { ThemeProvider } from "./context/ThemeContext";
import { AppLayout } from "./components/layout/AppLayout";

import { LandingPage } from "./pages/LandingPage";
import { LoginPage } from "./pages/LoginPage";
import { RegisterPage } from "./pages/RegisterPage";
import { LearnerDashboard } from "./pages/LearnerDashboard";
import { SkillGapPage } from "./pages/SkillGapPage";
import { AssessmentPage } from "./pages/AssessmentPage";
import { MissionLabPage } from "./pages/MissionLabPage";
import { MissionWorkspacePage } from "./pages/MissionWorkspacePage";
import { FailurePreventionPage } from "./pages/FailurePreventionPage";
import { ScenarioSimulatorPage } from "./pages/ScenarioSimulatorPage";
import { ScenarioPlayerPage } from "./pages/ScenarioPlayerPage";
import { KnowledgeRadarPage } from "./pages/KnowledgeRadarPage";
import { SkillPassportPage } from "./pages/SkillPassportPage";
import { SharedPassportPage } from "./pages/SharedPassportPage";
import { CorporateDashboard } from "./pages/CorporateDashboard";

// Protected Route wrapper with fallback to login
const ProtectedRoute: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { user, loading } = useAuth();

  if (loading) {
    return (
      <div className="min-h-screen bg-slate-900 text-white flex items-center justify-center text-xs">
        Authenticating session...
      </div>
    );
  }

  // If unauthenticated, redirect to login
  if (!user) {
    return <Navigate to="/login" replace />;
  }

  return <>{children}</>;
};

export const App: React.FC = () => {
  return (
    <ThemeProvider>
      <AuthProvider>
        <BrowserRouter>
          <Routes>
            {/* Public routes */}
            <Route path="/" element={<LandingPage />} />
            <Route path="/login" element={<LoginPage />} />
            <Route path="/register" element={<RegisterPage />} />
            <Route path="/passport/share/:token" element={<SharedPassportPage />} />

            {/* Authenticated application shell */}
            <Route
              element={
                <ProtectedRoute>
                  <AppLayout />
                </ProtectedRoute>
              }
            >
              <Route path="/dashboard" element={<LearnerDashboard />} />
              <Route path="/skills" element={<SkillGapPage />} />
              <Route path="/assessments" element={<AssessmentPage />} />
              <Route path="/missions" element={<MissionLabPage />} />
              <Route path="/missions/:id" element={<MissionWorkspacePage />} />
              <Route path="/failure-prevention" element={<FailurePreventionPage />} />
              <Route path="/simulator" element={<ScenarioSimulatorPage />} />
              <Route path="/simulator/:id" element={<ScenarioPlayerPage />} />
              <Route path="/knowledge" element={<KnowledgeRadarPage />} />
              <Route path="/passport" element={<SkillPassportPage />} />
              <Route path="/corporate" element={<CorporateDashboard />} />
              <Route path="/corporate/audit" element={<CorporateDashboard />} />
            </Route>

            {/* Catch-all */}
            <Route path="*" element={<Navigate to="/" replace />} />
          </Routes>
        </BrowserRouter>
      </AuthProvider>
    </ThemeProvider>
  );
};

export default App;
